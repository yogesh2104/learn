
import React, { useEffect, useRef, useState } from 'react'
import { useSelector } from 'react-redux'
import { useLocation } from 'react-router-dom'

import axios from 'axios'
import 'react-toastify/dist/ReactToastify.css'
import { BASE_URL, GetAPIUrl } from '../API/APIUrl'
import { ShowErrorMessage } from '../module/Tostify'
import InfiniteScroll from 'react-infinite-scroll-component'
import { BASENAME, utf8_to_b64 } from '../helpers/Utility'
import LoadingSpinner from '../module/LoadingSpinner'

const style = {
    height: 30,
    border: "1px solid green",
    margin: 6,
    padding: 8
};

const SearchData = () => {
    const location = useLocation();

    const type = new URLSearchParams(location.search).get("type");
    const searchitem = new URLSearchParams(location.search).get("searchitem");


    console.log("type", type, searchitem);
    const [List, setList] = useState([]);
    const [filterList, setFilterList] = useState([]);
    const [filterCount, setFilterCount] = useState();
    const [Currentpage, setCurrentpage] = useState(1);
    const [length, setLength] = useState(28);
    const [Loading, setLoading] = useState(false)
    const [isLoading, seIstLoading] = useState(false)

    const [category, setCategory] = useState([])
    const [diamond, setDiamond] = useState([])
    const [jewelry, setJewelry] = useState([])

    const PER_PAGE = length;
    const count = Math.ceil(filterCount / PER_PAGE);
    const timeout = useRef()

    const token = useSelector((state) => state?.user?.token)

    useEffect(() => {
        // if (params?.slug != undefined) {
        //     console.log("state", decodeURIComponent(escape(window.atob(params.slug))));
        //     let categoryId = decodeURIComponent(escape(window.atob(params.slug)))

        // }
        // CallFiltersApi()
        CallSearchAPI()

    }, [])

    const CallSearchAPI = async () => {

        const controller = new AbortController();
        var form = new FormData();

        form.append("search", searchitem);
        form.append("page", Currentpage);
        form.append("type", type);

        // console.log("fff", [...form]);
        if (searchitem.length > 2) {
            setLoading(true)

            await axios.post(BASE_URL + GetAPIUrl.SEARCH_URL, form, {
                headers: {
                    'Accept': 'application/json',
                }
            })
                .then(response => {
                    if (response.data.success == true) {


                        setCategory(response?.data?.data?.category)
                        if (diamond?.length <= response?.data?.data?.diamond_count) {
                            setDiamond([...diamond, ...response?.data?.data?.diamond])
                            setCurrentpage(pre => pre + 1);
                        }
                        // setJewelry(response?.data?.data?.jewelry)
                        console.log("jewelry?.length", response?.data?.data?.diamond_count);

                        if (jewelry?.length <= response?.data?.data?.jewelry_count) {
                            setJewelry([...jewelry, ...response?.data?.data?.jewelry])
                            setCurrentpage(pre => pre + 1);
                        }

                    } else {
                        ShowErrorMessage(response.data.message)
                    }
                }).catch(error => {
                    ShowErrorMessage(error.message)

                }).finally(() => {
                    setLoading(false)
                })
        }

        controller.abort()
    }

    const removeStorageShopAllData = () => {
        localStorage.removeItem('Subcategory')
        localStorage.removeItem('Shape');
        localStorage.removeItem('MetalType')
        localStorage.removeItem('JewelryId')
        localStorage.removeItem('DiamondId')
        localStorage.removeItem('Category')
        localStorage.setItem('All', 'true');
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '', SelectedringSize: '', diamondData: '' }]));
    }

    return (
        <section className="jumbotron pt-3" >


            {
                type == 'jewellery' &&
                // jewelry.map((item, index) => {
                //     return (
                //         <div key={index} className="product-div find-img">
                //             <div className="product-div-div">
                //                 <div className="product-div-box">
                //                     {/* <span className="heart-span hand">
                //                     <svg width="24" height="21" viewBox="0 0 24 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                //                         <path d="M6.5 1C3.4629 1 1 3.36095 1 6.27377C1 8.62513 1.9625 14.2057 11.4368 19.8471C11.6065 19.9471 11.8013 20 12 20C12.1987 20 12.3935 19.9471 12.5632 19.8471C22.0375 14.2057 23 8.62513 23 6.27377C23 3.36095 20.5371 1 17.5 1C14.4629 1 12 4.19623 12 4.19623C12 4.19623 9.5371 1 6.5 1Z" stroke="#3AB591" stroke-opacity="0.65" strokeWidth="2" strokeLinecap="round" stroke-linejoin="round"></path>
                //                     </svg>
                //                 </span> */}
                //                     <div className="product-div-list">
                //                         <img src={item?.default?.path} className="inner-img-product change-image" />
                //                     </div>
                //                     <div className="text-center show-viewbtn">

                //                         <h5 className="product-title pt-3 line1-doted-3">
                //                             Petite Twist Diamond Eternity Ring in 18K White Gold
                //                         </h5>
                //                         <p className="product-title-price mb-0">
                //                             $ 1099
                //                         </p>
                //                         <div className="pt-3 hide-view-btn">
                //                             <a className="view-details-btn" href="product-details.html">
                //                                 <span className="span-link">
                //                                     View Details
                //                                 </span>
                //                                 <span>&nbsp;
                //                                     <svg width="8" height="11" viewBox="0 0 8 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 10L6 5.5L1 1" stroke="#23282D" strokeWidth="1.5" strokeLinecap="round" /></svg>
                //                                 </span>
                //                             </a>
                //                         </div>
                //                     </div>
                //                 </div>
                //             </div>


                //         </div>
                //     )
                // })
                <InfiniteScroll
                    dataLength={jewelry.length}
                    loader={Loading && <center><img width='100px' src={process.env.PUBLIC_URL + "../assets/images/loader5.gif"} alt="loading..." /></center>}
                    next={CallSearchAPI}
                    hasMore={true}
                    endMessage={
                        <p style={{ textAlign: "center" }}>
                            <b>Yay! You have seen it all</b>
                        </p>
                    }
                >
                    <div className="container container-main" >
                        <div className="product-page-div">
                            <div className='row'>
                                {jewelry.map((item, index) => {
                                    return (

                                        <div key={index} className="product-div find-img" onClick={() => { removeStorageShopAllData(); window.location.pathname = BASENAME + `JDetails/${utf8_to_b64(item?.id)}/${item?.slug}` }}>
                                            <div className="product-div-div">
                                                <div className="product-div-box">
                                                    {/* <span className="heart-span hand">
                                            <svg width="24" height="21" viewBox="0 0 24 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M6.5 1C3.4629 1 1 3.36095 1 6.27377C1 8.62513 1.9625 14.2057 11.4368 19.8471C11.6065 19.9471 11.8013 20 12 20C12.1987 20 12.3935 19.9471 12.5632 19.8471C22.0375 14.2057 23 8.62513 23 6.27377C23 3.36095 20.5371 1 17.5 1C14.4629 1 12 4.19623 12 4.19623C12 4.19623 9.5371 1 6.5 1Z" stroke="#3AB591" stroke-opacity="0.65" strokeWidth="2" strokeLinecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                        </span> */}
                                                    <div className="product-div-list">
                                                        <img src={item?.default?.path} className="inner-img-product change-image" />
                                                    </div>
                                                    <div className="text-center show-viewbtn">

                                                        <h5 className="product-title pt-3 line1-doted-3">
                                                            {item?.title}
                                                        </h5>
                                                        <p className="product-title-price mb-0">
                                                            $ {item?.setting_price}
                                                        </p>
                                                        <div className="pt-3 hide-view-btn">
                                                            <a className="view-details-btn" href="product-details.html">
                                                                <span className="span-link">
                                                                    View Details
                                                                </span>
                                                                <span>&nbsp;
                                                                    <svg width="8" height="11" viewBox="0 0 8 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 10L6 5.5L1 1" stroke="#23282D" strokeWidth="1.5" strokeLinecap="round" /></svg>
                                                                </span>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                        </div>

                                    )
                                })}
                            </div>
                        </div>
                    </div>
                </InfiniteScroll>
            }
            {type == 'diamond' &&
                // diamond.map((item, index) => {
                //     return (
                //         <div key={index} className="product-div find-img">
                //             <div className="product-div-div">
                //                 <div className="product-div-box">
                //                     {/* <span className="heart-span hand">
                //                             <svg width="24" height="21" viewBox="0 0 24 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                //                                 <path d="M6.5 1C3.4629 1 1 3.36095 1 6.27377C1 8.62513 1.9625 14.2057 11.4368 19.8471C11.6065 19.9471 11.8013 20 12 20C12.1987 20 12.3935 19.9471 12.5632 19.8471C22.0375 14.2057 23 8.62513 23 6.27377C23 3.36095 20.5371 1 17.5 1C14.4629 1 12 4.19623 12 4.19623C12 4.19623 9.5371 1 6.5 1Z" stroke="#3AB591" stroke-opacity="0.65" strokeWidth="2" strokeLinecap="round" stroke-linejoin="round"></path>
                //                             </svg>
                //                         </span> */}
                //                     <div className="product-div-list">
                //                         <img src={item?.image} className="inner-img-product change-image" />
                //                     </div>
                //                     <div className="text-center show-viewbtn">

                //                         <h5 className="product-title pt-3 line1-doted-3">
                //                             Petite Twist Diamond Eternity Ring in 18K White Gold
                //                         </h5>
                //                         <p className="product-title-price mb-0">
                //                             $ 1099
                //                         </p>
                //                         <div className="pt-3 hide-view-btn">
                //                             <a className="view-details-btn" href="product-details.html">
                //                                 <span className="span-link">
                //                                     View Details
                //                                 </span>
                //                                 <span>&nbsp;
                //                                     <svg width="8" height="11" viewBox="0 0 8 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 10L6 5.5L1 1" stroke="#23282D" strokeWidth="1.5" strokeLinecap="round" /></svg>
                //                                 </span>
                //                             </a>
                //                         </div>
                //                     </div>
                //                 </div>
                //             </div>


                //         </div>
                //     )
                // })
                <div
                    id="scrollableDiv"
                    style={{
                        height: 300,
                        overflow: 'auto',
                        display: 'flex',
                        flexDirection: 'column-reverse',
                    }}
                >
                    <InfiniteScroll
                        dataLength={diamond.length}
                        loader={Loading && <h3><center> Loading...</center></h3>}
                        next={CallSearchAPI}
                        hasMore={true}
                        endMessage={
                            <p style={{ textAlign: "center" }}>
                                <b>Yay! You have seen it all</b>
                            </p>
                        }
                    >
                        <div className="container container-main" >
                            <div className="product-page-div">
                                <div className='row'>
                                    {diamond.map((item, index) => {
                                        return (

                                            <div key={index} className="product-div find-img" onClick={() => { removeStorageShopAllData(); window.location.pathname = BASENAME + `DiamondDetails/${utf8_to_b64(item?.id)}/${item?.carat}-Carat-${item?.ShapeName} Diamond, ${item?.ColorName}-${item?.ClarityName}}` }}>
                                                <div className="product-div-div">
                                                    <div className="product-div-box">
                                                        {/* <span className="heart-span hand">
                                            <svg width="24" height="21" viewBox="0 0 24 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M6.5 1C3.4629 1 1 3.36095 1 6.27377C1 8.62513 1.9625 14.2057 11.4368 19.8471C11.6065 19.9471 11.8013 20 12 20C12.1987 20 12.3935 19.9471 12.5632 19.8471C22.0375 14.2057 23 8.62513 23 6.27377C23 3.36095 20.5371 1 17.5 1C14.4629 1 12 4.19623 12 4.19623C12 4.19623 9.5371 1 6.5 1Z" stroke="#3AB591" stroke-opacity="0.65" strokeWidth="2" strokeLinecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                        </span> */}
                                                        <div className="product-div-list">
                                                            <img src={item?.image} className="inner-img-product change-image" />
                                                        </div>
                                                        <div className="text-center show-viewbtn">

                                                            <h5 className="product-title pt-3 line1-doted-3">
                                                                {item?.title}
                                                            </h5>
                                                            <p className="product-title-price mb-0">
                                                                $ {item?.amount}
                                                            </p>
                                                            <div className="pt-3 hide-view-btn">
                                                                <a className="view-details-btn" href="product-details.html">
                                                                    <span className="span-link">
                                                                        View Details
                                                                    </span>
                                                                    <span>&nbsp;
                                                                        <svg width="8" height="11" viewBox="0 0 8 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 10L6 5.5L1 1" stroke="#23282D" strokeWidth="1.5" strokeLinecap="round" /></svg>
                                                                    </span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>

                                        )
                                    })}
                                </div>
                            </div>
                        </div>
                    </InfiniteScroll>
                </div>
            }


        </section >

    )
}

export default SearchData