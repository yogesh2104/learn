import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { BASE_URL, GetAPIUrl } from '../API/APIUrl';
import noimage from "../assets/images/product-details/noimage.jpg";
import LoadingSpinner from '../module/LoadingSpinner';
import { confirmRemove, ShowErrorMessage, ShowMessage } from '../module/Tostify';
import logo from "../assets/images/logo-img.svg"
import { CallCartCountApi } from '../reducers/userReducers';
import { Colors } from '../constant/Constant';

const Wishlist = () => {
    const token = localStorage.getItem('token')

    const [Wishlist, setWishlist] = useState([]);
    const [IsWishlistLoading, setIsWishlistLoading] = useState(false)
    const FromSetting = JSON.parse(localStorage.getItem('FromSetting'))
    const [ringSize, setRingSize] = useState([])
    const [SelectedringSize, setSelectedRingSize] = useState('')
    const [message, setmessage] = useState(false)
    const [WishlistId, setWishlistId] = useState(-1);

    useEffect(() => {
        CallFetchListApi()
    }, [])

    const CallFetchListApi = async () => {
        setIsWishlistLoading(true)
        // await axios.get(BASE_URL + GetAPIUrl.WISHLIST_URL, {
        //     headers: {
        //         'Accept': 'application/json',
        //         'Content-Type': 'application/json',
        //         'Authorization': 'Bearer ' + token
        //     }
        // })
        await axios({
            method: "GET",
            url: BASE_URL + GetAPIUrl.WISHLIST_URL,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response?.data?.success == true) {
                    CallCartCountApi(token)
                    setWishlistId(-1)
                    setWishlist(response?.data?.wishlists)
                    response?.data?.wishlists?.map((item, index) => {
                        setRingSize(item?.WishlistJewelryData?.ringSize)
                    })


                } else {
                    ShowErrorMessage(response?.data?.message)
                }
            })
            .catch(error => {
                ShowErrorMessage(error?.message)


            }).finally(() => {
                setIsWishlistLoading(false)
            })
    }

    const confirmRemoveAddress = (item) => {

        confirmRemove().then((result) => {
            if (result == true) {
                CallDeletejewelry(item)
            }
        }

        )
    }

    const CallDeletejewelry = async (item) => {
        console.log("item", item);
        const controller = new AbortController();
        var form = new FormData();

        form.append("id", item?.id);
        form.append("jewelryid", item?.WishlistJewelryData?.id);
        form.append("diamondid", "");

        // console.log("fff", [...form]);
        await axios.post(BASE_URL + GetAPIUrl.DELETEWISHLIST_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.success == true) {

                    ShowMessage(response.data.message)

                    CallFetchListApi()
                } else {

                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                ShowErrorMessage(error.message)

            });
        controller.abort()
    }
    const CallDeleteDiamond = async (item) => {
        const controller = new AbortController();
        var form = new FormData();

        form.append("id", item?.id);
        form.append("jewelryid", "");
        form.append("diamondid", item?.WishlistDiamondData?.id);

        // console.log("fff", [...form]);
        await axios.post(BASE_URL + GetAPIUrl.DELETEWISHLIST_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.success == true) {

                    ShowMessage(response.data.message)
                    CallCartCountApi(token)
                    CallFetchListApi()
                } else {

                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                ShowErrorMessage(error.message)

            });
        controller.abort()
    }

    const updateRingData = async (id, ringsize) => {
        // setSelectedRingSize(ringsize)

        const controller = new AbortController();
        var form = new FormData();

        form.append("id", id == null ? "" : id);
        form.append("ringsize", ringsize)

        await axios.post(BASE_URL + GetAPIUrl.UPDATEWISHLIST_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.success == true) {
                    CallFetchListApi()
                    // window.location.pathname = 'Wishlist'
                } else {
                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                ShowErrorMessage(error.message)
            })
        controller.abort()
    }

    const validation = (item, index) => {
        console.log("item.WishlistJewelryData.id", WishlistId, index);
        if (item.wishlistRingData == null) {
            setWishlistId(index)
        } else {
            setWishlistId('')
            CallAddtoCartApi(item)
        }

        // if (SelectedringSize == '') {
        //     setmessage(true)

        // } else {
        //     setmessage(false)
        // }
        // if (item.WishlistJewelryData.id != '') {
        //     CallAddtoCartApi(item)
        // }
    }

    // const selecteRingSize = (value) => {
    //     let findIndex = ''
    //     let array = [...Wishlist]

    //     array.map((item) => {
    //         console.log("item", item);
    //         if (item?.WishlistJewelryData !== null) {
    //             findIndex = ringSize.findIndex(o1 => o1.ringsize == value)
    //             if (findIndex > -1) {
    //                 item.WishlistJewelryData = ringSize.find(o1 => o1.ringsize == value)
    //             }
    //         }
    //     })
    //     console.log("array", array);
    //     setWishlist([...array])

    //     // let findIndex = ''
    //     // let array = [...Wishlist]
    //     // array.map((item) => {
    //     //     if (item?.WishlistJewelryData !== null) {
    //     //         findIndex = item?.WishlistJewelryData?.ringSize.findIndex(o1 => o1.ringsize == value)
    //     //         if (findIndex > -1) {
    //     //             item.WishlistJewelryData = item.WishlistJewelryData?.ringSize[findIndex]
    //     //         }
    //     //     }
    //     // })
    //     // console.log("array", array);
    //     // setWishlist([...array])


    //     // item.WishlistJewelryData = {...item.WishlistJewelryData,}
    //     //item?.WishlistJewelryData?.ringSize[findIndex]?.ringsize
    //     // let ringData = Wishlist.filter(tag => tag?.WishlistJewelryData?.ringSize?.find(x => x?.ringsize==value ))

    //     // console.log("ringData", ringData);
    //     // FromSetting?.map(tag => {
    //     //     localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: ringData, diamondData: tag?.diamondData }]))
    //     // })
    //     // if (ringData !== '' || ringData != undefined) {
    //     // let selectedRing = Wishlist.filter(tag => tag?.WishlistJewelryData?.ringSize?.findIndex(x => { return x?.id == '2' }))

    //     // let selectedRing = ringData.map(tag => console.log( tag.WishlistJewelryData ))
    //     // console.log("ringData",ringData);
    //     // setWishlist(selectedRing)

    //     // }

    // }
    const CallAddtoCartApi = async (item) => {
        const controller = new AbortController();
        // setIsWishlistLoading(true)

        var form = new FormData();

        form.append("id", item?.id == null ? "" : item?.id);

        await axios.post(BASE_URL + GetAPIUrl.MOVETOCARTLIST_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.success == true) {

                    ShowMessage(response.data.message)
                    CallFetchListApi()
                    CallCartCountApi(token)
                    // window.location.pathname = 'Wishlist'
                } else {
                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                console.error('There was an error!', error);
                ShowErrorMessage(error.message)
            }).finally(() => {

            })
        controller.abort()

    }

    return (

        <>
            <div>
                <div className="container container-main">
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item">
                                <Link
                                    className=""
                                    aria-current="page"
                                    to={'/'}
                                >
                                    <i className="fa fa-home" aria-hidden="true"></i>
                                </Link>
                            </li>
                            <li className="breadcrumb-item active" aria-current="page">Wishlist</li>
                        </ol>
                    </nav>
                </div>
            </div>

            <section className="pb-3">
                <div className="container">
                    <div className="text-center max-80per">
                        <h5 className="title-1 mb-2">
                            Wishlist
                        </h5>
                        <p style={{ fontSize: "13px", color: "#7a7a7a" }}>
                            Choose a diamond to complement the jewellery you wish to create. Our extensive selection of gems feature ten different shapes as well as a range of carat sizes to suit every preference. Each diamond featured in our catalogue is responsibly sourced and comes with certification from a leading grading organisation.
                        </p>
                    </div>
                </div>
            </section>

            <section className="jumbotron pt-2">
                <div className="container container-main">
                    <div>
                        <div className="row">
                            <div className="col-md-12 col-xl-12">
                                <div className="table-responsive mar-bot-25px">
                                    <table id="dia-table" className="table table-striped1" style={{ width: "100%" }}>
                                        <thead className="tbl-header-acc">
                                            <tr className="">
                                                <th className="text-center" style={{ width: "15%" }}>
                                                    Image
                                                </th>
                                                <th className="min-200th" style={{ width: "41%" }}>
                                                    Product Details
                                                </th>
                                                <th className="text-center" style={{ minWidth: "110px" }}>
                                                    Price
                                                </th>
                                                <th className="text-center" style={{ minWidth: "110px" }}>
                                                    Status
                                                </th>
                                                <th className="text-center" style={{ minWidth: "110px" }}>
                                                    Action
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody className="tr-unhov-hand table-ver-midl">

                                            {IsWishlistLoading == true ?
                                                <LoadingSpinner />
                                                : Wishlist?.length > 0 ?
                                                    <>
                                                        {
                                                            Wishlist?.map((item, index) => {
                                                                return (
                                                                    <>
                                                                        {item?.WishlistJewelryData != null &&
                                                                            <tr class="trtd-13" key={index}>
                                                                                <td className="text-center">
                                                                                    <img src={item?.WishlistJewelryData?.default?.path == null ? noimage : item?.WishlistJewelryData?.default?.path} className="wish-img" />
                                                                                </td>
                                                                                <td>
                                                                                    <h6 className="heading">
                                                                                        {item?.WishlistJewelryData?.title}
                                                                                    </h6>
                                                                                    <div className="descList m-w-220">
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Metal</span>
                                                                                            <span style={{ padding: "0 8px 0 8px" }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.WishlistJewelryData?.metal_stamp?.paraname} {item?.WishlistJewelryData?.metal_type?.paraname}</span>
                                                                                        </div>
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">SKU</span>
                                                                                            <span style={{ padding: "0 8px 0 8px" }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.WishlistJewelryData?.itemcode}</span>
                                                                                        </div>
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Ring Size</span>
                                                                                            <span style={{ padding: "0 8px 0 8px" }}>:</span>
                                                                                            {/* <span className="wishlist_prd_right">{item?.WishlistJewelryData?.ringsize}</span> */}
                                                                                            <div className="wishlist_prd_right">
                                                                                                <select className="form-control1" onChange={(e) => updateRingData(item?.id, e.target.value)}>
                                                                                                    {/* <option value="none" defaultValue={item?.WishlistJewelryData?.ringsize} >{item?.WishlistJewelryData?.ringsize}</option> */}
                                                                                                    <option disabled={true} selected value={item?.wishlistRingData == null ? '' : item?.wishlistRingData?.paraname}>
                                                                                                        {item?.wishlistRingData == null ? "Choose" : item?.wishlistRingData?.paraname}
                                                                                                    </option>
                                                                                                    {ringSize?.map((item, index) => {
                                                                                                        return (
                                                                                                            <option id={item?.id} value={item?.id} key={index}>
                                                                                                                {item?.paraname}
                                                                                                            </option>
                                                                                                        )
                                                                                                    })}
                                                                                                </select>
                                                                                                <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                                                    {WishlistId == index && "Please Choose Ringsize"}
                                                                                                </p>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </td>
                                                                                <td className="text-center">
                                                                                    <b>${item?.WishlistJewelryData?.setting_price.toFixed(2)}</b>
                                                                                </td>
                                                                                <td className="text-center">
                                                                                    <b className="inn-stock">{item?.WishlistJewelryData?.status}</b>
                                                                                </td>
                                                                                <td className="text-center">
                                                                                    <label className="edit-cart" title="Edit" onClick={() => validation(item, index)}>
                                                                                        <i className="fa fa-shopping-cart" aria-hidden="true"></i>
                                                                                    </label>
                                                                                    <label className="delete-cart" title="Delete" onClick={() => confirmRemoveAddress(item)}>
                                                                                        <i className="fa fa-trash"></i>
                                                                                    </label>
                                                                                </td>
                                                                            </tr>
                                                                        }
                                                                        {item?.WishlistDiamondData != null && item?.WishlistJewelryData != null ?
                                                                            <tr class="trtd-13">
                                                                                <td colspan="6">
                                                                                    <hr class="hr-border" />
                                                                                </td>
                                                                            </tr>
                                                                            :
                                                                            <tr className="trtd-13 bor-trlast" ></tr>
                                                                        }


                                                                        {item?.WishlistDiamondData != null &&
                                                                            <tr className="trtd-13 bor-trlast" key={index}>
                                                                                <td className="text-center">
                                                                                    <img src={item?.WishlistDiamondData?.image == null ? noimage : item?.WishlistDiamondData?.image} className="wish-img" />
                                                                                </td>
                                                                                <td>
                                                                                    <h6 className="heading">
                                                                                        {item?.WishlistDiamondData?.carat} Carat {item?.WishlistDiamondData?.shape_name?.paraname} Diamond, {item?.WishlistDiamondData?.color_name?.paraname}-{item?.WishlistDiamondData?.clarity_name?.clarityname}
                                                                                    </h6>
                                                                                    <div className="descList m-w-220">
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Carat</span>
                                                                                            <span style={{ padding: "0 8px 0 8px" }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.WishlistDiamondData?.carat}</span>
                                                                                        </div>
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Shape</span>
                                                                                            <span style={{ padding: "0 8px 0 8px" }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.WishlistDiamondData?.shape_name?.paraname}</span>
                                                                                        </div>
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">SKU</span>
                                                                                            <span style={{ padding: "0 8px 0 8px" }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.WishlistDiamondData?.loatno}</span>
                                                                                        </div>

                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Clarity</span>
                                                                                            <span style={{ padding: "0 8px 0 8px" }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.WishlistDiamondData?.clarity_name?.clarityname}</span>
                                                                                        </div>
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Color</span>
                                                                                            <span style={{ padding: "0 8px 0 8px" }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.WishlistDiamondData?.color_name?.paraname}</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </td>
                                                                                <td className="text-center">
                                                                                    <b>${item?.WishlistDiamondData?.amount.toFixed(2)}</b>
                                                                                </td>
                                                                                <td className="text-center">
                                                                                    <b className="inn-stock">{item?.WishlistDiamondData?.status}</b>
                                                                                </td>

                                                                                <td className="text-center">
                                                                                    {item?.WishlistJewelryData == null &&
                                                                                        <label className="edit-cart" title="Edit" onClick={() => validation(item)}>
                                                                                            <i className="fa fa-shopping-cart" aria-hidden="true"></i>
                                                                                        </label>
                                                                                    }
                                                                                    <label className="delete-cart" title="Delete" onClick={() => CallDeleteDiamond(item)}>
                                                                                        <i className="fa fa-trash"></i>
                                                                                    </label>
                                                                                </td>
                                                                            </tr>
                                                                        }
                                                                    </>
                                                                )
                                                            })
                                                        }

                                                    </>
                                                    :
                                                    <tr>
                                                        <td colSpan={5}>
                                                            <div
                                                                style={{ display: "grid", flex: 1, justifyContent: "center", alignItems: 'center', backgroundColor: '#f1ecf0' }}
                                                            >
                                                                <img
                                                                    src={logo}
                                                                    alt="loading..."
                                                                    style={{ width: 150, height: 150 }}
                                                                />
                                                                <h4>No data Found</h4>
                                                            </div>
                                                        </td>
                                                    </tr>
                                            }



                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default Wishlist