import axios from 'axios';
import Multiselect from 'multiselect-react-dropdown';
import React, { memo, useEffect, useRef, useState } from 'react'
import { Navigate } from 'react-router-dom';
import Swal from 'sweetalert2';
import { BASE_URL, GetAPIUrl } from '../API/APIUrl';
import { Colors, regx } from '../constant/Constant';
import { fetch2 } from '../helpers/fetch';
import { ShowErrorMessage, ShowMessage } from '../module/Tostify';
import { CallCartCountApi } from '../reducers/userReducers';
import Payment from '../module/Payment';
import { Messages } from '../constant/Messages';

const $ = window.$;

const Checkout = () => {
    const token = localStorage.getItem('token')

    const [addressListLoading, setAddressListLoading] = useState(false)
    const [addressList, setAddressList] = useState([])
    const [SelectedAddress, setSelectedAddress] = useState('');
    const [SelectedBillingAddress, setSelectedBillingAddress] = useState({
        "billing_firstname": '',
        "billing_lastname": '',
        "billing_email": '',
        "billing_companyname": '',
        "billing_address": '',
        "billing_city": '',
        "billing_country": '',
        "billing_state": '',
        "billing_mobileno": '',
        "billing_zip": '',
    });

    const [Cartlist, setCartlist] = useState([]);
    const [Count, setCount] = useState('');
    const [TotalAmount, setTotalAmount] = useState('');
    const [IsCartLoading, setIsCartLoading] = useState(false)
    const [IsLoading, setLoading] = useState(false)


    const [saveAddress, setSaveAddress] = useState({});
    const [ErrorsData, setErrorsData] = useState('')


    const publicIp = require("react-public-ip");

    const [CountryList, setCountryList] = useState([])
    const [stateList, setStateList] = useState([])

    const [country, setCountry] = useState('')
    const [Addstate, setAddstate] = useState('')

    const [ShippingCountry, setShippingCountry] = useState('')
    const [Shippingstate, setShippingstate] = useState('')

    const [changePass, setChangePass] = useState(true)
    const [errorResponse, setErrorResponse] = useState(true)

    const [oldPassShow, setOldPassShow] = useState(false)
    const [newPassShow, setNewPassShow] = useState(false)
    const [cPassShow, setCPassShow] = useState(false)
    const [showDetail, setShowDetail] = useState(false)

    const [isdefault, setisdefault] = useState(true)

    const [isDisable, setIsDisable] = useState(true)
    const [braintree_customer_id, setbraintree_customer_id] = useState('')
    const [values, setValues] = useState({
        clientToken: null,
        success: '',
        error: '',
        instance: ''
    })

    useEffect(() => {
        CallFetchCartListApi()
        fetchMyAddress()
        CallCountryApi()
        fetchClientToken()
    }, [])
    const fetchClientToken = async () => {
                setLoading(true)
                await axios.get(BASE_URL + GetAPIUrl.CLIENTTOKEN_URL, {
                    headers: {
                        'Accept': 'application/json',
                        'Authorization': "Bearer " + localStorage.getItem('token')
                    }
                })
                    .then(response => {
                        console.log("response?.data", response?.data);
                        if (response?.data?.success == true) {
                            setValues({ ...values, clientToken: response.data.token })
        
                            setbraintree_customer_id(response?.data?.braintree_customer_id)
                        } else {
                        }
                    }).catch((error) => {
                        ShowErrorMessage(error)
                    }).finally(() => {
                        setLoading(false)
                    })
            }
    const CallStateApi = async (countryid) => {
        let data = {
            "countryid": countryid,
        }
        const result = await fetch2(BASE_URL + GetAPIUrl.STATE, data)
        if (result.success == true) {
            setStateList(result.data)
        }
        // console.log("result", result);
    }

    const fetchMyAddress = async () => {
        setAddressListLoading(true)
        await axios.get(BASE_URL + GetAPIUrl.ADDRESS_URL, {
            headers: {
                'Accept': 'application/json',
                'Authorization': "Bearer " + localStorage.getItem('token')
            }
        })
            .then(response => {

                if (response?.data?.success == true) {
                    setAddressList(response?.data?.userAdddress)
                    let address = ''
                    response?.data?.userAdddress.filter((item, index) => {
                        if (item?.isdefault == 1) {
                            address = item
                            CallStateApi(item?.country)
                        }
                    })
                    setSelectedAddress(address)

                } else {
                }
            }).catch((error) => {
                ShowErrorMessage(error)
            }).finally(() => {
                setAddressListLoading(false)
            })
    }



    const CallFetchCartListApi = async () => {
        const controller = new AbortController();
        setIsCartLoading(true)
        await axios.get(BASE_URL + GetAPIUrl.CARTLIST_URL, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {

                if (response.data.success == true) {
                    setCartlist(response?.data?.carts)
                    setCount(response?.data?.count)
                    setTotalAmount(response?.data?.cart_total)

                    CallCartCountApi(token)

                } else {
                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                ShowErrorMessage(error.message)

            }).finally(() => {
                setIsCartLoading(false)
            })
        controller.abort()
    }

    const handleAddressChange = e => {
        let { name, value } = e.target;
        setSaveAddress({ ...saveAddress, [name]: value });
    }
    const handleShippingAddressChange = e => {
        let { name, value } = e.target;
        setSelectedAddress({ ...SelectedAddress, [name]: value });
    }
    const handleBillingAddressChange = e => {
        let { name, value } = e.target;
        setSelectedBillingAddress({ ...SelectedBillingAddress, [name]: value });
    }
    const CallCountryApi = async () => {
        const result = await axios.get(BASE_URL + GetAPIUrl.COUNTRY)
        if (result.data.success == true) {
            setCountryList(result.data.data)
            setAddstate('')
        }
    }
    const SaveAddress = async () => {
        setLoading(true)
        const ipv4 = await publicIp.v4() || "";
        const ipv6 = await publicIp.v6() || "";
        let data = {
            "id": SelectedAddress?.id,
            "firstname": SelectedAddress?.firstname,
            "lastname": SelectedAddress?.lastname,
            "email": SelectedAddress?.email,
            "address": SelectedAddress?.address,
            "city": SelectedAddress?.city,
            "state": SelectedAddress?.state,
            "country": SelectedAddress?.country,
            "zip": SelectedAddress?.pincode,
            "mobileno": SelectedAddress?.mobileno,
            "ip_address": ipv4 == undefined ? '' : ipv4,
            "isdefault": SelectedAddress?.isdefault,
        }
        await axios.post(BASE_URL + GetAPIUrl.ADDADDRESS_URL, data, {
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.code == 200) {
                    if (isdefault == false) {
                        validation()
                    } else {
                        gotoPayment();
                        fetchMyAddress()
                    }
                    $('#address-modal').modal('hide');

                    // $(".show-payment-method").click(function () {
                    //     $(".shopping-main-div").hide();
                    //     $(".payment-method").show();
                    // });
                    ShowMessage(response.data.message)
                    // resetAll()

                    setErrorsData('')
                    setIsDisable(true)


                } else {
                    ShowErrorMessage(response.errors.message)
                }
            }).catch((error) => {
                setErrorsData(error.response.data.errors)
                if (!isdefault) {
                    validation()
                }
            }).finally(() => {
                setLoading(false)
            })

    }
    const gotoPayment = () => {
        $(".shopping-main-div").hide();
        $(".payment-method").show();
    }
    const resetAll = () => {
        setCountry('')
        setAddstate('')
        setSaveAddress({
            "Addressid": '',
            "userid": '',
            "Addfirstname": '',
            "Addlastname": '',
            "Addemail": '',
            "Addmobileno": '',
            "Addaddress": '',
            "Addcity": '',
            "pincode": '',
        })
        setisdefault(false)
        setErrorsData('')

    }
    const AddresselectRef = useRef()

    const [IsFilterLoading, setIsFilterLoading] = useState(false);

    const handleAddressValues = (selectedList, selectedItem) => {
        setSelectedAddress(selectedItem)
        setIsDisable(true)
        setErrorsData('')

    };
    const handleRemoveAddressValues = (selectedList, selectedItem) => {
        AddresselectRef.current.resetSelectedValues();
        setSelectedAddress('')
    };

    const [errorFirstname, setErrorFirst] = useState('')
    const [errorLastname, setErrorLastname] = useState('')

    const [errorEmail, setErrorEmail] = useState('')
    const [errorMobile, setErrorMobile] = useState('')
    const [errorAddress, setErrorAddress] = useState('')
    const [errorCountry, setErrorCountry] = useState('')
    const [errorState, setErrorState] = useState('')
    const [errorCity, setErrorCity] = useState('')
    const [errorZip, setErrorZip] = useState('')


    const validation = () => {
        let message = "";

        if (SelectedBillingAddress.billing_firstname == "") {
            message = Messages.FIRSTNAME_REQUIRED;
            setErrorFirst(message)
            // setErrorSelectedBillingAddress({ ...ErrorSelectedBillingAddress, billing_firstname: message })
        }
        else {
            setErrorFirst('')
        }

        if (SelectedBillingAddress.billing_lastname == "") {
            message = Messages.LASTNAME_REQUIRED;
            setErrorLastname(message)
            // setErrorSelectedBillingAddress({ ...ErrorSelectedBillingAddress, billing_lastname: message })
        }
        else {
            setErrorLastname('')
        }

        if (SelectedBillingAddress?.billing_email == "") {
            message = Messages.EMAIL_REQUIRED;
            setErrorEmail(message)
        }
        else if (regx.EMAIL.test(SelectedBillingAddress?.billing_email) == false) {
            message = Messages.EMAIL_INVALID;
            setErrorEmail(message)
        }
        else {
            setErrorEmail('')
            // setErrorSelectedBillingAddress({ ...ErrorSelectedBillingAddress, billing_email: message })
        }
        if (SelectedBillingAddress.billing_mobileno == "") {
            message = Messages.MOBILE_REQUIRED;
            setErrorMobile(message)
        }
        else {
            setErrorMobile('')
        }
        if (SelectedBillingAddress.billing_address == "") {
            message = Messages.ADDRESS_REQUIRED;
            setErrorAddress(message)
        }
        else {
            setErrorAddress('')
        }
        if (SelectedBillingAddress.billing_country == "") {
            message = Messages.COUNTRY_REQUIRED;
            setErrorCountry(message)
        }
        else {
            setErrorCountry('')
        }
        if (SelectedBillingAddress.billing_state == "") {
            message = Messages.STATE_REQUIRED;
            setErrorState(message)
        }
        else {
            setErrorState('')
        }
        if (SelectedBillingAddress.billing_city == "") {
            message = Messages.CITY_REQUIRED;
            setErrorCity(message)
        }
        else {
            setErrorCity('')
        }
        if (SelectedBillingAddress.billing_zip == "") {
            message = Messages.ZIP_REQUIRED;
            setErrorZip(message)
        } else if (regx.ZIP.test(SelectedBillingAddress.billing_zip) == false) {
            message = Messages.ZIP_INVALID;
            setErrorZip(message)
        }
        else {
            setErrorZip('')
        }



        if (message == '') {
            gotoPayment();
            fetchMyAddress()
        }
    }

    $(function () {

        $(".show-ship-address").click(function () {
            $(".payment-method").hide();
            $(".shopping-main-div").show();
        });

        $(".show-payment-method").click(function () {
            $(".shopping-main-div").hide();
            $(".payment-method").show();
        });
        $('#BillingAddress').on('change', function () {
            if ($(this).is(':checked')) {
                $('.billing-address').css('display', 'none');
            } else {
                $('.billing-address').css('display', 'block');
            }
        });
        $(".active-payment").click(function () {
            $(".payment-method-box").removeClass('payment-method-box-active');
            $(this).toggleClass('payment-method-box-active');
        });
    })

    return (
        <>
            <div>
                <div className="container container-main">
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fa fa-home" aria-hidden="true"></i></a></li>
                            <li className="breadcrumb-item active" aria-current="page">Checkout</li>
                        </ol>
                    </nav>
                </div>
            </div>

            <section className="jumbotron pt-3">
                <div className="container container-main">
                    <div>
                        <div className="row">
                            <div className="col-lg-7 order-2 order-lg-1 mb-4">
                                <div style={{ boxShadow: "0 2px 7px 3px #e9e9e9", padding: "15px" }}>
                                    <div className="shopping-main-div">
                                        <div className="shipping-address">
                                            <div className="row" style={{ justifyContent: 'space-between', paddingLeft: 20, paddingRight: 20 }}>
                                                <h4 className="title-1">
                                                    <i className="fa fa-home" style={{ paddingRight: "7px" }}></i> Shipping Address

                                                </h4>
                                                <a className="start-with-btn mobile-1rem-bot mr-0"
                                                    // data-toggle="modal"
                                                    //  data-target="#address-modal"
                                                    onClick={() => { setSelectedAddress(''); setIsDisable(false) }}
                                                >
                                                    Add New Address
                                                </a>
                                            </div>
                                            <br />
                                            {/* {addressList?.map((item, index) => {
                                                return (
                                                    <div className="radio-btn">

                                                        <label key={index}>
                                                            <input type="radio" name="address" value={item?.id} />
                                                            {item?.address},{item?.city}-{item?.pincode}
                                                        </label>
                                                    </div>
                                                   
                                                )
                                            })} */}
                                            {addressList.length > 0 &&
                                                <div className="dropdown bootstrap-select show-tick" style={{ marginRight: 10, width: '-webkit-fill-available' }}>
                                                    <label className="lblmy">Select Your Existing Address:</label>

                                                    <Multiselect singleSelect
                                                        disablePreSelectedValues={SelectedAddress != '' ? true : false}
                                                        placeholder=''
                                                        style={{
                                                            chips: { background: 'white', color: Colors.brown, fontSize: 14 },
                                                            searchBox: { "borderRadius": "0px" },

                                                        }}
                                                        ref={AddresselectRef}

                                                        showArrow
                                                        loading={IsFilterLoading ? true : false}
                                                        onSelect={handleAddressValues}
                                                        onRemove={handleRemoveAddressValues}
                                                        options={addressList}
                                                        selectedValues={SelectedAddress != '' ? [SelectedAddress] : []}
                                                        // selectedValues={[addressList?.map((item) => { if (item?.isdefault == 1) { return item } })]}
                                                        displayValue="name" />
                                                    {/* <Multiselect placeholder='Select Weight type' showArrow options={settingType} displayValue="name" /> */}
                                                </div>
                                            }
                                            <div className="row">
                                                <div className="col-lg-6">
                                                    <div className="form-group">
                                                        <label className="lblmy">First Name<sup>*</sup>:</label>
                                                        <input type="text"
                                                            className="form-control my-textbox"
                                                            name='firstname'
                                                            id="firstname"
                                                            disabled={isDisable ? true : false}
                                                            placeholder={SelectedAddress?.firstname == '' || SelectedAddress?.firstname == undefined && 'Enter Firstname'}
                                                            value={SelectedAddress?.firstname || ""}
                                                            onChange={handleShippingAddressChange}
                                                        />
                                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                            {ErrorsData.firstname != undefined && ErrorsData?.firstname?.map((key, i) => key)}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="col-lg-6">
                                                    <div className="form-group">
                                                        <label className="lblmy">Last Name<sup>*</sup>:</label>
                                                        <input type="text"
                                                            disabled={isDisable ? true : false}

                                                            placeholder={SelectedAddress?.lastname == '' || SelectedAddress?.lastname == undefined && 'Enter Lastname'}
                                                            className="form-control my-textbox" id="lastname" name='lastname'
                                                            value={SelectedAddress?.lastname || ""}
                                                            onChange={handleShippingAddressChange}
                                                        />
                                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                            {ErrorsData.lastname != undefined && ErrorsData?.lastname?.map((key, i) => key)}
                                                        </p>
                                                    </div>
                                                </div>
                                                {/* <div className="col-lg-6">
                                                    <div className="form-group">
                                                        <label className="lblmy">Company Name:</label>
                                                        <input type="text" className="form-control my-textbox" id="cname"
                                                            value={SelectedAddress?.lastname || ""}
                                                            onChange={handleShippingAddressChange}
                                                        />
                                                    </div>
                                                </div> */}
                                                <div className="col-lg-6">
                                                    <div className="form-group">
                                                        <label className="lblmy">Email Id<sup>*</sup>:</label>
                                                        <input type="email"
                                                            disabled={isDisable ? true : false}

                                                            placeholder={SelectedAddress?.email == '' || SelectedAddress?.email == undefined && 'Enter Email'}
                                                            className="form-control my-textbox" id="email" name='email'
                                                            value={SelectedAddress?.email || ""}
                                                            onChange={handleShippingAddressChange}
                                                        />
                                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                            {ErrorsData.email != undefined && ErrorsData?.email?.map((key, i) => key)}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="col-lg-6">
                                                    <div className="form-group">
                                                        <label className="lblmy">Mobile No.<sup>*</sup>:</label>
                                                        <input type="text"
                                                            disabled={isDisable ? true : false}

                                                            placeholder={SelectedAddress?.mobileno == '' || SelectedAddress?.mobileno == undefined && 'Enter Mobile No'}
                                                            className="form-control my-textbox" id="mobileno" name='mobileno'
                                                            value={SelectedAddress?.mobileno || ""}
                                                            onChange={handleShippingAddressChange} />
                                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                            {ErrorsData.mobileno != undefined && ErrorsData?.mobileno?.map((key, i) => key)}
                                                        </p>
                                                    </div>
                                                </div>

                                                <div className="col-lg-12">
                                                    <div className="form-group">
                                                        <label className="lblmy">Address<sup>*</sup>:</label>
                                                        <textarea className="form-control my-textbox"
                                                            disabled={isDisable ? true : false}

                                                            placeholder={SelectedAddress?.address == '' || SelectedAddress?.address == undefined && 'Enter Address'}
                                                            rows="2" id="address" name='address'
                                                            style={{ minHeight: "auto" }}
                                                            value={SelectedAddress?.address || ""}
                                                            onChange={handleShippingAddressChange}>
                                                        </textarea>
                                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                            {ErrorsData.address != undefined && ErrorsData?.address?.map((key, i) => key)}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="col-lg-6">
                                                    <div className="form-group">
                                                        <label className="lblmy">Country<sup>*</sup> :</label>
                                                        <select
                                                            disabled={isDisable ? true : false}

                                                            value={SelectedAddress?.country || ""}
                                                            name="country"
                                                            id="country"
                                                            className="form-control my-textbox selectarrow-none"
                                                            data-parsley-trigger="change"
                                                            data-parsley-errors-container="#Country_msg"
                                                            required=""
                                                            onChange={(e) => { CallStateApi(e.target.value); handleShippingAddressChange(e) }}
                                                        >
                                                            <option value="" disabled="">Select Country <sup>*</sup></option>
                                                            {CountryList?.map((item, index) => {
                                                                return (
                                                                    <option key={index} value={item?.id} data-value={item?.id}>{item?.name}</option>
                                                                )
                                                            })}

                                                        </select>
                                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                            {ErrorsData.country != undefined && ErrorsData?.country?.map((key, i) => key)}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="col-lg-6">

                                                    <div className="form-group">
                                                        <label className="lblmy">State<sup>*</sup>:</label>

                                                        <select disabled={isDisable == true || SelectedAddress?.country == '' || SelectedAddress?.country == undefined ? true : false}

                                                            value={SelectedAddress?.state || ""}
                                                            name="state"
                                                            id="state"
                                                            className="form-control my-textbox"
                                                            data-parsley-trigger="change"
                                                            data-parsley-errors-container="#State_msg"
                                                            onChange={(e) => { handleShippingAddressChange(e) }}
                                                        >
                                                            <option value="" disabled="" >Select State *</option>
                                                            {stateList?.map((item, index) => {
                                                                return (
                                                                    <option key={index} value={item?.id} data-value={item?.id}>{item?.name}</option>
                                                                )
                                                            })}
                                                        </select>
                                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                            {ErrorsData.state != undefined && ErrorsData?.state?.map((key, i) => key)}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="col-lg-6">
                                                    <div className="form-group">
                                                        <label className="lblmy">Town/City<sup>*</sup>:</label>
                                                        <input type="text" disabled={isDisable ? true : false}
                                                            placeholder={SelectedAddress?.city == '' || SelectedAddress?.city == undefined && 'Enter Town/City'}

                                                            className="form-control my-textbox" id="city" name="city"
                                                            value={SelectedAddress?.city || ""}
                                                            onChange={handleShippingAddressChange}
                                                        />
                                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                            {ErrorsData.city != undefined && ErrorsData?.city?.map((key, i) => key)}
                                                        </p>
                                                    </div>
                                                </div>

                                                <div className="col-lg-6">
                                                    <div className="form-group">
                                                        <label className="lblmy">Zip<sup>*</sup>:</label>
                                                        <input disabled={isDisable ? true : false}
                                                            placeholder={SelectedAddress?.pincode == '' || SelectedAddress?.pincode == undefined && 'Enter Zip Code'}
                                                            type="text" className="form-control my-textbox" id="zip" name="pincode"
                                                            value={SelectedAddress?.pincode || ""}
                                                            onChange={handleShippingAddressChange} />
                                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                            {ErrorsData.zip != undefined && ErrorsData?.zip?.map((key, i) => key)}
                                                        </p>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <br />
                                        <div className="row">
                                            <div className="col-lg-12">
                                                {/* <div className="form-group mar-b-14">
                                                    <label className="chk-sign mar-top-10 color-80">Use this address for Billing
                                                        <input type="checkbox" id="BillingAddress" name="BillingAddress" value="1"
                                                         defaultChecked data-parsley-multiple="BillingAddress"
                                                          data-parsley-id="46" />
                                                        <span className="checkmark-chk"></span>
                                                    </label>
                                                </div> */}
                                                <div className="form-group checkbox-wrapper">
                                                    <label className="checkboxs mar-top-10 color-80"> Use as my default billing address
                                                        <input type="checkbox"
                                                            id="isdefault"
                                                            name="isdefault"
                                                            value="isdefault"
                                                            checked={isdefault}
                                                            onChange={() => setisdefault(!isdefault)} />
                                                        <span className="checkmark"></span>
                                                    </label>

                                                </div>
                                            </div>
                                        </div>
                                        {!isdefault &&
                                            <div className="billing-address" >
                                                <h4 className="title-1">
                                                    <i className="fa fa-home" style={{ paddingRight: "7px" }}></i> Billing Address
                                                </h4>
                                                <br />
                                                <div className="row">
                                                    <div className="col-lg-6">
                                                        <div className="form-group">
                                                            <label className="lblmy">First Name*:</label>
                                                            <input type="text" className="form-control my-textbox" name='billing_firstname' id="billing_firstname"
                                                                value={SelectedBillingAddress?.billing_firstname || ""}
                                                                onChange={handleBillingAddressChange}
                                                            />
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorFirstname != '' && errorFirstname}
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <div className="form-group">
                                                            <label className="lblmy">Last Name*:</label>
                                                            <input type="text" className="form-control my-textbox" name='billing_lastname' id="billing_lastname"
                                                                value={SelectedBillingAddress?.billing_lastname || ""}
                                                                onChange={handleBillingAddressChange} />
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorLastname != '' && errorLastname}
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <div className="form-group">
                                                            <label className="lblmy">Email Id*:</label>
                                                            <input type="email" className="form-control my-textbox" name='billing_email' id="billing_email"
                                                                value={SelectedBillingAddress?.billing_email || ""}
                                                                onChange={handleBillingAddressChange} />
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorEmail != '' && errorEmail}
                                                            </p>
                                                        </div>


                                                    </div>
                                                    <div className="col-lg-6">
                                                        <div className="form-group">
                                                            <label className="lblmy">Mobile No.*:</label>
                                                            <input type="text" maxLength={10} className="form-control my-textbox" name='billing_mobileno' id="billing_mobileno"
                                                                value={SelectedBillingAddress?.billing_mobileno || ""}
                                                                onChange={handleBillingAddressChange}
                                                            />
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorMobile != '' && errorMobile}
                                                            </p>
                                                        </div>
                                                    </div>
                                                    {/* <div className="col-lg-6">
                                                        <div className="form-group">
                                                            <label className="lblmy">Company Name:</label>
                                                            <input type="text" className="form-control my-textbox" id="cname" />
                                                        </div>
                                                    </div> */}

                                                    <div className="col-lg-12">
                                                        <div className="form-group">
                                                            <label className="lblmy">Address*:</label>
                                                            <textarea className="form-control my-textbox" rows="2"
                                                                name='billing_address' id="billing_address"
                                                                value={SelectedBillingAddress?.billing_address || ""}
                                                                onChange={handleBillingAddressChange}
                                                                style={{ minHeight: "auto" }}></textarea>
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorAddress != '' && errorAddress}
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <div className="form-group">
                                                            <label className="lblmy">Country / Region*:</label>
                                                            <select

                                                                value={SelectedBillingAddress?.billing_country || ""}
                                                                name="billing_country"
                                                                id="billing_country"
                                                                className="form-control my-textbox selectarrow-none"
                                                                data-parsley-trigger="change"
                                                                data-parsley-errors-container="#Country_msg"
                                                                required=""
                                                                onChange={(e) => { CallStateApi(e.target.value); handleBillingAddressChange(e) }}
                                                            >
                                                                <option value="" disabled="">Select Country <sup>*</sup></option>
                                                                {CountryList?.map((item, index) => {
                                                                    return (
                                                                        <option key={index} value={item?.id} data-value={item?.id}>{item?.name}</option>
                                                                    )
                                                                })}

                                                            </select>
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorCountry != '' && errorCountry}
                                                            </p>
                                                        </div>
                                                    </div>

                                                    <div className="col-lg-6">
                                                        <div className="form-group">
                                                            <label className="lblmy">State*:</label>
                                                            <select disabled={SelectedBillingAddress?.billing_country == '' || SelectedBillingAddress?.billing_country == undefined ? true : false}

                                                                value={SelectedBillingAddress?.billing_state || ""}
                                                                name="billing_state"
                                                                id="billing_state"
                                                                className="form-control my-textbox"
                                                                data-parsley-trigger="change"
                                                                data-parsley-errors-container="#State_msg"
                                                                onChange={(e) => { handleBillingAddressChange(e) }}
                                                            >
                                                                <option value="" disabled="" >Select State *</option>
                                                                {stateList?.map((item, index) => {
                                                                    return (
                                                                        <option key={index} value={item?.id} data-value={item?.id}>{item?.name}</option>
                                                                    )
                                                                })}
                                                            </select>
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorState != '' && errorState}
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <div className="form-group">
                                                            <label className="lblmy">Town/City*:</label>
                                                            <input type="text" className="form-control my-textbox" id="billing_city" name="billing_city"
                                                                value={SelectedBillingAddress?.billing_city || ""}
                                                                onChange={handleBillingAddressChange}
                                                            />
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorCity != '' && errorCity}

                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div className="col-lg-6">
                                                        <div className="form-group">
                                                            <label className="lblmy">Zip*:</label>
                                                            <input type="text" className="form-control my-textbox"
                                                                id="billing_zip" name="billing_zip"
                                                                value={SelectedBillingAddress?.billing_zip || ""}
                                                                onChange={handleBillingAddressChange}
                                                            />
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorZip != '' && errorZip}
                                                            </p>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        }
                                        <br />
                                        <div className="row">
                                            <div className="col-lg-6">
                                                <a className='checkout-nowbtn mb-3'
                                                    onClick={() => {
                                                        isDisable && isdefault && gotoPayment();
                                                        ((!isDisable && isdefault) || (!isDisable && !isdefault)) && SaveAddress();
                                                        isDisable && !isdefault && validation();
                                                        // isDisable && isdefault && SaveAddress();
                                                    }
                                                    }>
                                                    Continue to Payment
                                                </a>
                                            </div>
                                            <div className="col-lg-6">
                                                <a href={process.env.PUBLIC_URL + `/Cart`} className="continue-nowbtn mb-3">
                                                    Back to Cart
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="payment-method" style={{ display: "none" }}>
                                        <h4 className="title-1">
                                            <i className="fa fa-credit-card-alt" style={{ paddingRight: "7px" }}></i> Payment Method
                                        </h4>
                                        {/* <p className="col777">
                                            Choose payment method below
                                        </p>
                                        <br />
                                        <div className="row">
                                            <div className="col-lg-4 col-md-4 mb-2">
                                                <div className="text-center payment-method-box payment-method-box-active active-payment">
                                                    <img src={process.env.PUBLIC_URL + "/assets/images/checkout/paypal.png"} width="110" height="auto" />
                                                    <img src={process.env.PUBLIC_URL + "/assets/images/checkout/selected-reg.png"} className="active-i" />
                                                </div>
                                            </div>
                                            <div className="col-lg-4 col-md-4 mb-2">
                                                <div className="text-center payment-method-box active-payment">
                                                    <img src={process.env.PUBLIC_URL + "/assets/images/checkout/paytm.png"} width="110" height="auto" />
                                                    <img src={process.env.PUBLIC_URL + "/assets/images/checkout/selected-reg.png"} className="active-i" />
                                                </div>
                                            </div>
                                            <div className="col-lg-4 col-md-4 mb-2">
                                                <div className="text-center payment-method-box active-payment">
                                                    <img src={process.env.PUBLIC_URL + "/assets/images/checkout/razorpay.png"} width="110" height="auto" />
                                                    <img src={process.env.PUBLIC_URL + "/assets/images/checkout/selected-reg.png"} className="active-i" />
                                                </div>
                                            </div>                                           
                                        </div> */}
                                        <Payment braintree_customer_id={braintree_customer_id} values={values} CountryList={CountryList} stateList={stateList} Cartlist={Cartlist} TotalAmount={TotalAmount} SelectedAddress={SelectedAddress} isdefault={isdefault} SelectedBillingAddress={SelectedBillingAddress} />

                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-5 order-1 order-lg-2 mb-4">
                                <div>
                                    <div style={{ boxShadow: "0 2px 7px 3px #e9e9e9", padding: "15px", background: "#f6f6f5" }}>
                                        <h4 className="title-1">
                                            <i className="fa fa-check" style={{ paddingRight: "7px" }}></i> Order Review
                                        </h4>
                                        <br />
                                        <div className="table-responsive wishlist-tbl">
                                            <table className="w-100">
                                                <thead className="first-wish-th">
                                                    <tr>
                                                        <th>Img</th>
                                                        <th className="text-left">Product Name</th>
                                                        <th>Price</th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                    {Cartlist?.map((item, index) => {
                                                        return (
                                                            <>
                                                                {item?.CartJewelryData != null &&
                                                                    <tr>
                                                                        <td>
                                                                            <img src={item?.CartJewelryData?.default?.path} width="100" height="auto" className="imgg-box" />
                                                                        </td>
                                                                        <td className="text-left" style={{ verticalAlign: "top" }}>
                                                                            <div className="div-p-table">
                                                                                <h6>
                                                                                    <a href="#" className="cart-prodtitle-color">
                                                                                        {item?.CartJewelryData?.title}
                                                                                    </a>
                                                                                </h6>
                                                                                <p>
                                                                                    <span className="t-color span-b">SKU :</span>
                                                                                    {item?.CartJewelryData?.itemcode}
                                                                                </p>
                                                                                {/* <p>
                                                                            <span className="t-color span-b">Shape :</span>
                                                                            {item?.CartJewelryData?.itemcode}
                                                                        </p> */}
                                                                                <p>
                                                                                    <span className="t-color span-b">Metal :</span>
                                                                                    {item?.CartJewelryData?.metal_stamp?.paraname} {item?.CartJewelryData?.metal_type?.paraname}
                                                                                </p>
                                                                                <p>
                                                                                    <span className="t-color span-b">Ring Size :</span>
                                                                                    {item?.RingSizeData?.paraname}
                                                                                </p>
                                                                            </div>
                                                                        </td>
                                                                        <td className="text-center">
                                                                            <b>
                                                                                ${item?.CartJewelryData?.setting_price}
                                                                            </b>
                                                                        </td>
                                                                    </tr>
                                                                }
                                                                {item?.CartDiamondData != null &&
                                                                    <tr>
                                                                        <td>
                                                                            <img src={item?.CartDiamondData?.image} width="100" height="auto" className="imgg-box" />
                                                                        </td>
                                                                        <td className="text-left" style={{ verticalAlign: "top" }}>
                                                                            <div className="div-p-table">
                                                                                <h6>
                                                                                    <a href="#" className="cart-prodtitle-color">
                                                                                        {item?.CartDiamondData?.title}
                                                                                    </a>
                                                                                </h6>
                                                                                <p>
                                                                                    <span className="t-color span-b">SKU :</span>
                                                                                    {item?.CartDiamondData?.loatno}
                                                                                </p>
                                                                                <p>
                                                                                    <span className="t-color span-b">Shape :</span>
                                                                                    {item?.CartDiamondData?.shape_name?.paraname}
                                                                                </p>
                                                                                <p>
                                                                                    <span className="t-color span-b">Carat :</span>
                                                                                    {item?.CartDiamondData?.carat}
                                                                                </p>
                                                                                <p>
                                                                                    <span className="t-color span-b">Clarity :</span>
                                                                                    {item?.CartDiamondData?.clarity_name?.clarityname}
                                                                                </p>
                                                                                <p>
                                                                                    <span className="t-color span-b">Color :</span>
                                                                                    {item?.CartDiamondData?.color_name?.paraname}
                                                                                </p>
                                                                            </div>
                                                                        </td>
                                                                        <td className="text-center">
                                                                            <b>
                                                                                ${item?.CartDiamondData?.amount.toFixed(2)}
                                                                            </b>
                                                                        </td>
                                                                    </tr>
                                                                }
                                                            </>
                                                        )
                                                    })}
                                                </tbody>
                                            </table>
                                        </div>
                                        <br />
                                        <div>
                                            <dl className="order-summary-me-price pad-10-dd-me dd-even" style={{ marginBottom: "10px", background: "#fff" }}>
                                                <dd>
                                                    Subtotal
                                                    <strong><i className="fa fa-usd"></i><span id="subTotal">{TotalAmount}</span></strong>
                                                </dd>

                                                {/* <dd>
                                                    Shipping
                                                    <strong><span id="ShippingAmt">FREE</span></strong>
                                                </dd>
                                                <dd>
                                                    Sales Tax Estimate
                                                    <strong><i className="fa fa-usd"></i> <span id="TxtAmount">0</span></strong>
                                                </dd> */}
                                                <dd>
                                                    <b>No of Items</b>
                                                    <strong><span id="ShippingAmt">{Count == 0 ? '-' : Count}</span></strong>
                                                </dd>
                                                <dd>
                                                    <b className="color-000 lsp1">Total</b>
                                                    <strong className=""><b><i className="fa fa-usd"></i> <span id="TotalAmt">{TotalAmount}</span></b></strong>
                                                </dd>
                                            </dl>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


        </>
    )
}

export default Checkout