import axios from 'axios'
import { useEffect, useRef, useState } from 'react'
import { Pagination } from '@material-ui/lab'
import moment from 'moment'
import Multiselect from 'multiselect-react-dropdown'
import { AiOutlineClose } from "react-icons/ai"
import { Link, useLocation, useParams } from 'react-router-dom'
import { BASE_URL, GetAPIUrl } from '../API/APIUrl'
import imageErrorSrc from '../assets/images/default.png'
import logo from "../assets/images/logo-img.svg"
import { Colors } from '../constant/Constant'
import { DiamondGridSkeleton } from '../module/Skeletons'
import { ShowErrorMessage, ShowMessage } from '../module/Tostify'
import { ToastContainer } from 'react-toastify'
import { useSelector } from 'react-redux'
import LoadingSpinner from '../module/LoadingSpinner'
import { b64_to_utf8, BASENAME, utf8_to_b64 } from '../helpers/Utility'
import { CallCartCountApi } from '../reducers/userReducers'

const $ = window.$;

export default function Jewelry(props) {
    let { sid, slug } = useParams();
    // console.log("location.search", sid == undefined ? "" : b64_to_utf8(sid), slug);


    // const [metalStamp, setMetalStamp] = useState([
    //     { id: 109, id1: 417, name: '18k', type: 'metal', name1: 'Rose Gold', img: drose1 },
    //     { id: 110, id1: 417, name: '14k', type: 'metal', name1: 'Rose Gold', img: drose2 },
    //     { id: 109, id1: 424, name: '18k', type: 'metal', name1: 'White Gold', img: dwhite1 },
    //     { id: 110, id1: 424, name: '14k', type: 'metal', name1: 'White Gold', img: dwhite2 },
    //     { id: 109, id1: 421, name: '18k', type: 'metal', name1: 'Yellow Gold', img: dyellow1 },
    //     { id: 110, id1: 421, name: '14k', type: 'metal', name1: 'Yellow Gold', img: dyellow2 },
    //     { id: 109, id1: 426, name: '18k', type: 'metal', name1: 'Gold', img: dgold1 },
    //     { id: 110, id1: 426, name: '14k', type: 'metal', name1: 'Gold', img: dgold2 },
    //     { id: 109, id1: 427, name: '18k', type: 'metal', name1: 'Platinum', img: dpla1 },
    //     { id: 110, id1: 427, name: '14k', type: 'metal', name1: 'Platinum', img: dpla2 },
    // ])
    // const [metalStamp, setMetalStamp] = useState([])

    const [settingType, setSettingType] = useState([])
    const [diamondType, setDiamondType] = useState([])
    const [metalType, setMetalType] = useState([])

    const [SelectedMetalType, setSelectedMetalType] = useState(JSON.parse(localStorage.getItem('MetalType')) ? JSON.parse(localStorage.getItem('MetalType')) : [])
    const [SelectedDiamondType, setSelectedDiamondType] = useState(JSON.parse(
        localStorage.getItem('Shape')) ? JSON.parse(localStorage.getItem('Shape')) : []
        // sid == undefined ? [] : b64_to_utf8([sid])
    )
    // const [SelectedDiamondType, setSelectedDiamondType] = useState( sid == undefined ? [] : b64_to_utf8([sid]))
    const [getAllData, setGetAllData] = useState(JSON.parse(localStorage.getItem('All')) == null ? '' : JSON.parse(localStorage.getItem('All')))
    const [SelectedSettingType, setSelecteSettingType] = useState([])
    const [SelectedWeight, setSelectedWeight] = useState('')
    const [SelectedPrice, setSelectedPrice] = useState('')
    const [SelectedSort, setSelectedSort] = useState({ name: 'Newest', order_column: 'created_at', sort: 'DESC', type: 'sorting' })
    const [Category, setCategory] = useState(JSON.parse(localStorage.getItem('Category')) ? JSON.parse(localStorage.getItem('Category')) : '')
    const [Subcategory, setSubcategory] = useState(JSON.parse(localStorage.getItem('Subcategory')) ? JSON.parse(localStorage.getItem('Subcategory')) : '')


    const FromSetting = JSON.parse(localStorage.getItem('FromSetting'))
    const multiselectRef = useRef()
    const weightselectRef = useRef()
    const priceselectRef = useRef()
    const sortselectRef = useRef()


    const [weight, setWeight] = useState([
        { name: 'Less Than 2 Grams', min: '', max: '2', type: 'weight' },
        { name: '2 Grams To 4 Grams', min: '2', max: '4', type: 'weight' },
        { name: '4 Grams To 6 Grams', min: '4', max: '6', type: 'weight' },
        { name: '6 Grams And Above', min: '6', max: '', type: 'weight' },
    ])
    const [sorting, setSorting] = useState([
        { name: 'Low To High', order_column: 'setting_price', sort: 'ASC', type: 'sorting' },
        { name: 'High To Low', order_column: 'setting_price', sort: 'DESC', type: 'sorting' },
        { name: 'Newest', order_column: 'created_at', sort: 'DESC', type: 'sorting' },
    ])

    const [price, setPrice] = useState([
        { name: 'Under $100', min: '', max: '100', type: 'price' },
        { name: '$100 To $200', min: '100', max: '200', type: 'price' },
        { name: '$200 To $300', min: '200', max: '300', type: 'price' },
        { name: '$300 To $400', min: '300', max: '400', type: 'price' },
        { name: '$400 To $500', min: '400', max: '500', type: 'price' },
        { name: '$500 And Above', min: '500', max: '', type: 'price' },
    ])

    const [jewellryData, setJewellryData] = useState([])
    const [IsWishlistLoading, setIsWishlistLoading] = useState(false)
    const [isLoading, setIsLoading] = useState(true);
    const [List, setList] = useState([]);
    const [filterList, setFilterList] = useState([]);
    const [filterCount, setFilterCount] = useState();
    const [Currentpage, setCurrentpage] = useState(1);
    const [length, setLength] = useState(28);
    const [IsFilterLoading, setIsFilterLoading] = useState(false);

    const PER_PAGE = length;
    const count = Math.ceil(filterCount / PER_PAGE);
    const timeout = useRef()

    const token = useSelector((state) => state?.user?.token)

    useEffect(() => {
        // if (params?.slug != undefined) {
        //     console.log("state", decodeURIComponent(escape(window.atob(params.slug))));
        //     let categoryId = decodeURIComponent(escape(window.atob(params.slug)))

        // }
        getJewellryData(SelectedMetalType, SelectedDiamondType, SelectedSettingType, SelectedWeight, SelectedPrice, SelectedSort)
        CallFiltersApi()

    }, [Currentpage])



    const handleChange = (e, p) => {
        setCurrentpage(p);
        setIsLoading(true)
    };

    // let debouncedData = useDebounced(SelectedMetalType,500)

    // function useDebounced ( value , timeout ) {
    //     let [ debouncedValue , setDebouncedValue ] = useState ( value )      
    //     useEffect (() => {
    //       let timeoutId = setTimeout (() => {
    //         setDebouncedValue( value )
    //       } , timeout)
    //       return ()=> {
    //         clearTimeout(timeoutId)
    //      }
    //    } , [ value , timeout ] )
    //    console.log("debouncedValue",debouncedValue);
    //     return debouncedValue
    // }


    const handleMetalValues = (selectedList, selectedItem) => {

        let array = [...SelectedMetalType];
        let selectedIndex = array.findIndex((d) => d.id == selectedItem.id)
        if (array?.length > 0 && selectedIndex >= 0) {
            array.splice(selectedIndex, 1);
        } else {
            array.push(selectedItem);
        }
        // useDebounced(array,500)
        localStorage.setItem('MetalType', JSON.stringify(array));
        setSelectedMetalType(array)
        setIsLoading(true)
        getJewellryData(array, SelectedDiamondType, SelectedSettingType, SelectedWeight, SelectedPrice, SelectedSort)

    };

    const handleDiamondValues = (selectedList, selectedItem) => {
        let array = [...SelectedDiamondType];
        let selectedIndex = array.findIndex((d) => d.id == selectedItem.id)
        if (array?.length > 0 && selectedIndex >= 0) {
            array.splice(selectedIndex, 1);
        } else {
            array.push(selectedItem);
        }
        localStorage.setItem('Shape', JSON.stringify(array));
        setSelectedDiamondType(array)
        setIsLoading(true)
        getJewellryData(SelectedMetalType, array, SelectedSettingType, SelectedWeight, SelectedPrice, SelectedSort)
    };

    const handleSettingValues = (selectedList, selectedItem) => {
        let array = [...SelectedSettingType];
        let selectedIndex = array.findIndex((d) => d.id == selectedItem.id)
        if (array?.length > 0 && selectedIndex >= 0) {
            array.splice(selectedIndex, 1);
        } else {
            array.push(selectedItem);
        }

        setSelecteSettingType(array)
        setIsLoading(true)
        getJewellryData(SelectedMetalType, SelectedDiamondType, array, SelectedWeight, SelectedPrice, SelectedSort)

    };
    const handleWeightValues = (selectedList, selectedItem) => {
        setSelectedWeight(selectedItem)
        getJewellryData(SelectedMetalType, SelectedDiamondType, SelectedSettingType, selectedItem, SelectedPrice, SelectedSort)

    };
    const handleRemoveWeightValues = (selectedList, selectedItem) => {
        weightselectRef.current.resetSelectedValues();
        setSelectedWeight('')
        setIsLoading(true)
        getJewellryData(SelectedMetalType, SelectedDiamondType, SelectedSettingType, '', SelectedPrice, SelectedSort)

    };

    const handlePriceValues = (selectedList, selectedItem) => {
        setSelectedPrice(selectedItem)
        setIsLoading(true)
        getJewellryData(SelectedMetalType, SelectedDiamondType, SelectedSettingType, SelectedWeight, selectedItem, SelectedSort)

    };

    const handleRemovePriceValues = (selectedList, selectedItem) => {
        priceselectRef.current.resetSelectedValues();
        setSelectedPrice('')
        setIsLoading(true)
        getJewellryData(SelectedMetalType, SelectedDiamondType, SelectedSettingType, SelectedWeight, '', SelectedSort)
    };
    const handleSortingValues = (selectedList, selectedItem) => {
        setSelectedSort(selectedItem)
        setIsLoading(true)
        getJewellryData(SelectedMetalType, SelectedDiamondType, SelectedSettingType, SelectedWeight, SelectedPrice, selectedItem)
    };


    const CallFiltersApi = () => {
        setIsFilterLoading(true)
        let List = [];
        axios.get(BASE_URL + GetAPIUrl.JEWELRY_FILTER_URL, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            }
        })
            .then(response => {
                if (response.data.success == true) {
                    setIsFilterLoading(false)
                    // console.log("res = = =>", response.data.data.Metal_type);
                    setDiamondType(response.data.data.Shape);

                    setMetalType(response.data.data.Metal_Type)
                    setSettingType(response.data.data.Setting_Type)
                } else {
                    setIsFilterLoading(false)
                }
            })
    }
    console.log("Subcategory", Subcategory);
    const getJewellryData = async (SelectedMetalType, SelectedDiamondType, SelectedSettingType, SelectedWeight, SelectedPrice, SelectedSort) => {
        const getMetalId = SelectedMetalType?.map(item => item.id).join(',');
        const getDiamondId = SelectedDiamondType?.map(item => item.id).join(',');
        const getSettingId = SelectedSettingType?.map(item => item.id).join(',');

        let minPrice = SelectedPrice.min
        let maxPrice = SelectedPrice.max

        let minWeight = SelectedWeight.min
        let maxWeight = SelectedWeight.max

        let order_column = SelectedSort.order_column
        let sort = SelectedSort.sort
        let count = length * (Currentpage - 1)
        var form = new FormData();
        form.append("draw", Currentpage);
        form.append("start", Currentpage == 1 ? 0 : count);
        form.append("length", length);
        form.append("metal_type", getMetalId === undefined ? '' : getMetalId);
        form.append("metal_stamp", "");
        form.append("diamond_type", getDiamondId === undefined ? '' : getDiamondId);
        form.append("setting_type", getSettingId === undefined ? '' : getSettingId);
        form.append("weight_min", minWeight === undefined ? '' : minWeight);
        form.append("weight_max", maxWeight === undefined ? '' : maxWeight);
        form.append("price_min", minPrice === undefined ? '' : minPrice);
        form.append("price_max", maxPrice === undefined ? '' : maxPrice);
        form.append("order_column", order_column === undefined ? '' : order_column);
        form.append("sort", sort === undefined ? '' : sort);
        form.append("category_id", Category?.categoryId === undefined ? '' : Category?.categoryId);
        form.append("subcategory_id", Subcategory?.id === undefined ? '' : Subcategory?.id);

        form.append("finish_status", getAllData == '' ? 'Semi-Finished' : 'Finished');
        // form.append("center_stone_caret", slug == undefined ? '' : slug);
        // form.append("center_stone_shape", sid == undefined ? '' : b64_to_utf8(sid));

        console.log("getAllData", getAllData);

        await axios.post(BASE_URL + GetAPIUrl.JEWELRYLIST_URL, form)
            .then((json) => {
                console.log("json.status", json);
                console.log("hello", json?.data?.data);
                if (json.status == 200) {
                    setFilterCount(json?.data?.recordsFiltered);
                    setList(json?.data?.data);
                    setFilterList(json?.data?.data);
                } else {
                    ShowErrorMessage(json.data.message)
                }
            })
            .catch(error => {
                console.log("error.messag", error.message);
                setIsLoading(false);
                ShowErrorMessage(error.message)
            }).finally(() => setIsLoading(false));
    }


    const removeAllData = () => {
        multiselectRef.current.resetSelectedValues();
        weightselectRef.current.resetSelectedValues();
        priceselectRef.current.resetSelectedValues();
        sortselectRef.current.resetSelectedValues();
        setSelectedMetalType([])
        if (sid == undefined) {
            setSelectedDiamondType([])
        }
        setSelecteSettingType([])
        setSelectedWeight('')
        setSelectedPrice('')
        setSelectedSort(SelectedSort)
        setIsLoading(true)
        getJewellryData([], [], [], '', '', SelectedSort)

        localStorage.removeItem('Shape')
        localStorage.removeItem('MetalType')
        // setAllNames([])
        // setJewellryData(alljewelleryData)
    }

    const handleScroll = () => {
        // var dropdowns = 
        // document.getElementsByClassName("dropdown-menu");
        // console.log("dropdowns",dropdowns);
        // var i;
        // for (i = 0; i < dropdowns.length; i++) {
        //     var openDropdown = dropdowns[i];
        //     console.log("openDropdown",openDropdown.classList);
        //     if (openDropdown.classList.contains('show')) {
        //        openDropdown.classList.remove('show');
        //     }
        // }
    }

    const CallAddtoWishlistApi = async (item) => {
        setIsWishlistLoading(true)
        const controller = new AbortController();
        console.log("item", item);
        var form = new FormData();

        form.append("jewelryid", item?.id);
        // form.append("ringsize", JewelryId);

        console.log("form", [...form]);

        await axios.post(BASE_URL + GetAPIUrl.WISHLIST_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + localStorage.getItem('token')
            }
        })
            .then(response => {
                console.log("wishlisr resposnes", response);
                if (response.data.success == true) {
                    setIsWishlistLoading(false)
                    ShowMessage(response.data.message)
                    CallCartCountApi(token)
                } else {
                    setIsWishlistLoading(false)
                    ShowErrorMessage(response.data.message)
                }
            })
            // await fetch( GetAPIUrl.WISHLIST_URL, {
            //     method: "POST",
            //     headers: {
            //         "Content-Type": "application/json",
            //         "Accept": "application/json",
            //         "Authorization": 'Bearer' + ' ' + token
            //     },
            //     body: JSON.stringify(data)
            // }).then(response => response.json())
            //     .then(data => {
            //         console.log("wishlisr resposnes", data);
            //         if (data.success == true) {
            //             setIsWishlistLoading(false)
            //             ShowMessage(data.message)
            //         } else {
            //             setIsWishlistLoading(false)
            //             ShowErrorMessage(data.message)
            //         }
            //     })


            .catch(error => {
                console.log("error", error);

                ShowErrorMessage(error.message)
                setIsWishlistLoading(false)
                // window.location.pathname = '/Login'

            });
        controller.abort()
    }

    const addNewKey = (item) => {
        console.log("in");
        FromSetting?.map((tag) => {
            // localStorage.setItem('JewelryId', item.id)
            localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: item, SelectedringSize: tag.SelectedringSize, diamondData: tag.diamondData }]))
            // window.location.reload(false);
            window.location.pathname = BASENAME + `JDetails/${utf8_to_b64(item?.id)}/${item?.slug}`
        })

    }
    $(function () {

        var $cache = $('#getFixed');
        var $head = $('.header-fixscroll');
        function fixDiv() {
            if ($(window).scrollTop() > 100) {

                return (
                    $cache.css({

                        'position': 'fixed',
                        'top': '0px',
                        'width': '100%',
                        'z-index': '1045',
                        'background': '#fff',
                        'box-shadow': '#656565 0px 1px 20px -8px',
                        'padding-bottom': '5px',
                        'padding-top': '5px',
                    }),
                    $head.css({
                        'display': 'none'
                    })
                )
            }
            else {
                return (
                    $cache.css({
                        'position': 'relative',
                        'top': 'auto',
                        'z-index': 'inherit',
                        'box-shadow': 'none',
                        'padding-bottom': 'auto',
                        'background': 'transparent',
                    }),
                    $head.css({
                        'display': 'block'
                    })
                )
            }
        }
        var lastScrollTop = 0;
        $(window).scroll(function () {
            fixDiv();
            var st = $(this).scrollTop();
            if (st > lastScrollTop) {
                $('.header-fixscroll').hide();
                $('#getFixed').show();
            } else {
                $('.header-fixscroll').show();
                $('#getFixed').hide();
            }
            lastScrollTop = st;
            if (st == 0) {
                $('#getFixed').show();
            }
        });


        if ($(window).width() < 991) {
            $('.filterdiv').addClass('f1div');
            $('#filter-modal').addClass('modal fade search-modal modal-bg-fff');
            $('.f2div').addClass('modal-dialog momodel modal-fluid');
            $('.f3div').addClass('modal-content');
            $('.f4div').addClass('modal-body');
            $('.more-fix').addClass('more-filterbtn-div pad-0lf');
            $('.header-set').removeClass('header-set');
        } else {
            $('.filterdiv').removeClass('f1div');
            $('#filter-modal').removeClass('modal fade search-modal modal-bg-fff');
            $('.f2div').removeClass('modal-dialog momodel modal-fluid');
            $('.f3div').removeClass('modal-content');
            $('.f4div').removeClass('modal-body');
            $('label').removeClass('click-shape click-price click-color click-carat click-quality');
            $('.more-fix').removeClass('more-filterbtn-div pad-0lf');
        }

        $(document).ready(function () {
            $('.selectpicker').selectpicker('toggle');
        });

        $('.f-click').on({
            'click': function () {
                // $('.change-image').attr('src','images/product/p1.png');
                $(this).parent().closest('.find-img').find('.change-image').attr('src', $(this).data('src'));
                // $(this).toggleClass('active-1');
                $(this).addClass("active-1").siblings().removeClass("active-1");
            }
        });

    })
    $(function () {
        window.$('.selectpicker').selectpicker('toggle')
        window.addEventListener('scroll', handleScroll, true);

        // Remove the event listener
        return () => {
            window.removeEventListener('scroll', handleScroll, true);
        };
    })
    return (
        <div className="mycontainer" >
            {IsWishlistLoading &&
                < LoadingSpinner />
            }
            <div>
                <div className="container container-main">
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            {/* <li className="breadcrumb-item">
                                <Link
                                    className=""
                                    aria-current="page"
                                    to={'/'}
                                >
                                    <i className="fa fa-home" aria-hidden="true"></i>
                                </Link>
                            </li>
                            {Category != '' &&
                                <li className="breadcrumb-item">{Category == '' ? "" : Category?.categoryId == "21" && "Engagment Ring" || Category?.categoryId == "41" && "Wedding Ring"}</li>
                            }
                            <li className="breadcrumb-item active" aria-current="page">{Category == '' ? "Setting" : Category?.categoryName}</li> */}
                        </ol>
                    </nav>
                </div>
            </div>
            <div>
                {getAllData == '' &&
                    FromSetting?.map((tag, i) => {
                        return (
                            <>
                                <section className="mobile-view-none" key={i}>
                                    <div className="container container-main">
                                        <div className="wizard2-steps mb-3">
                                            <div className="step wizard2-steps-heading">
                                                <div className="node">
                                                    <div className="node-skin">
                                                        <div className="cont">
                                                            <h2 className="nostyle-heading">Build Your Own Ring</h2>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            {tag?.jewelryData == '' ?
                                                <div className="cyo-bar-step step step-item  active-step keep-left">
                                                    <div className="node" >
                                                        <div className="node-skin">
                                                            <div className="pho">
                                                                <img src={process.env.PUBLIC_URL + "/assets/images/steps/setting.svg"} alt="setting" style={{ backgroundColor: "white" }} />
                                                            </div>
                                                            <div className="cont">
                                                                <div className="action help-tips">
                                                                    <a href="#" className="td-u bar-action line1-doted-2"></a>
                                                                </div>
                                                                <div className="heading">
                                                                    <div className="action help-tips">
                                                                        <a href="#" className="td-u bar-action">Choose</a>
                                                                    </div>
                                                                    <h2 className="nostyle-heading">setting</h2>


                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                :
                                                <div className="cyo-bar-step step step-item active-step keep-left">
                                                    <div className="node" >
                                                        <div className="node-skin">
                                                            <div className="pho">
                                                                <img style={{ background: 'rgba(76, 175, 80, 0.1)' }} src={tag?.jewelryData?.default.path} alt="setting" />
                                                            </div>
                                                            <div className="cont">
                                                                <div className="heading"><h2 className="nostyle-heading">Setting</h2>
                                                                    <div className="action help-tips">
                                                                        <div className="td-u bar-action">{tag.jewelryData.title}
                                                                            <aside>Price :${tag.jewelryData.setting_price?.toFixed(2)}</aside></div>
                                                                    </div>
                                                                    <div className="action double-action" style={{ display: 'flex' }}>
                                                                        {/* <div onClick={() => window.location.reload()}>
                                                                            <Link
                                                                                className="td-u bar-action"
                                                                                aria-current="page"
                                                                                style={{ textDecoration: "none", marginRight: 10 }}

                                                                                to={process.env.PUBLIC_URL +`/Jewelry/${tag?.jewelryData?.title}`}
                                                                            >
                                                                                Change
                                                                            </Link>
                                                                        </div>
                                                                        <div onClick={() => window.location.reload()}>
                                                                            <Link
                                                                                className="td-u bar-action"
                                                                                aria-current="page"
                                                                                style={{ textDecoration: "none" }}

                                                                                to={process.env.PUBLIC_URL +`/JDetails/${utf8_to_b64(tag?.jewelryData?.id)}/${tag?.jewelryData?.title}`}
                                                                            >
                                                                                View
                                                                            </Link>
                                                                        </div> */}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            }
                                            {tag?.diamondData == '' ?
                                                <div className="cyo-bar-step step step-item ">
                                                    <div className="node" >
                                                        <div className="node-skin">
                                                            <div className="pho">
                                                                <img src={process.env.PUBLIC_URL + "/assets/images/steps/diamonds.svg"} alt="diamond" />
                                                            </div>
                                                            <div className="cont">
                                                                <div className="action help-tips">
                                                                    <a href="#" className="td-u bar-action line1-doted-2"></a>
                                                                </div>
                                                                <div className="heading">
                                                                    <div className="action help-tips">
                                                                        <a href="#" className="td-u bar-action">Choose</a>
                                                                    </div>
                                                                    <h2 className="nostyle-heading">Diamond</h2>


                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                :
                                                <div className="cyo-bar-step step step-item  active-step keep-left">
                                                    <div className="node" >
                                                        <div className="node-skin">
                                                            <div className="pho">
                                                                <img src={tag?.diamondData?.image} alt="diamond" style={{ backgroundColor: "white" }} />
                                                            </div>
                                                            <div className="cont">
                                                                <div className="action help-tips">
                                                                    <a href="#" className="td-u bar-action line1-doted-2"></a>
                                                                </div>
                                                                <div className="heading">
                                                                    <h2 className="nostyle-heading">Diamond</h2>
                                                                    <div className="action help-tips">
                                                                        <div className="td-u bar-action">{tag?.diamondData?.carat} Carat {tag?.diamondData?.ShapeName} Diamond, {tag?.diamondData?.ColorName}-{tag?.diamondData?.ClarityName}
                                                                            <aside>Price :${tag.diamondData.amount}</aside></div>
                                                                    </div>
                                                                    <div className="action double-action" style={{ display: 'flex' }}>
                                                                        {/* <div onClick={() => window.location.reload()}>
                                                                            <Link
                                                                                className="td-u bar-action"
                                                                                aria-current="page"
                                                                                style={{ textDecoration: "none", marginRight: 10 }}

                                                                                to={process.env.PUBLIC_URL +`/DiamondList/${tag?.diamondData?.carat} Carat ${tag?.diamondData?.ShapeName} Diamond, ${tag?.diamondData?.ColorName}-${tag?.diamondData?.ClarityName}`}
                                                                            >
                                                                                Change
                                                                            </Link>
                                                                        </div>
                                                                        <div onClick={() => window.location.reload()}>
                                                                            <Link
                                                                                className="td-u bar-action"
                                                                                aria-current="page"
                                                                                style={{ textDecoration: "none" }}

                                                                                to={process.env.PUBLIC_URL +`/DiamondDetails/${tag?.diamondData?.carat} Carat ${tag?.diamondData?.ShapeName} Diamond, ${tag?.diamondData?.ColorName}-${tag?.diamondData?.ClarityName}`}
                                                                            >
                                                                                View
                                                                            </Link>
                                                                        </div> */}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            }

                                            {tag?.diamondData != '' && tag?.jewelryData != '' ?
                                                <div className="step step-item invariant-color active-step keep-left">
                                                    <div className="node">
                                                        <div className="node-skin">
                                                            <div className="pho">
                                                                <img src={process.env.PUBLIC_URL + "/assets/images/steps/ring.svg"} alt="ring" style={{ backgroundColor: "white" }} />
                                                            </div>
                                                            <div className="cont">
                                                                <div className="action help-tips">TOTAL</div>
                                                                <div className="heading"><h2 className="nostyle-heading">${(tag?.jewelryData?.setting_price + tag?.diamondData?.amount)?.toFixed(2)}</h2></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                :
                                                <div className="step step-item invariant-color">
                                                    <div className="node">
                                                        <div className="node-skin">
                                                            <div className="pho">
                                                                <img src={process.env.PUBLIC_URL + "/assets/images/steps/ring.svg"} alt="ring" />
                                                            </div>
                                                            <div className="cont">
                                                                {/* <div className="action help-tips">Choose</div> */}
                                                                <div className="heading"><h2 className="nostyle-heading">TOTAL</h2></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            }
                                        </div>
                                    </div>
                                </section>


                            </>
                        )

                    })
                }
            </div>
            <div className='filters-data' style={{}}>
                <div className="list-filter list-filter-with" id="getFixed" style={{ maxWidth: '100%', }}>
                    <div className="container container-main" style={{ display: 'flex', }} >
                        <div className="row filterdiv" >
                            <div className="col-lg-12">
                                <div id="filter-modal">
                                    <div className="f2div">
                                        <div className="f3div">
                                            {/* <div className="modal-header h-hide mob-filter-btn filter-modal-header">
                                                <h5 className="modal-title mob-filter-tit-35">Filter</h5>
                                                <button type="button" className="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">
                                                    <i className="fa fa-angle-left" aria-hidden="true"></i></span></button><span className="clear-all-mob clearfilter">Clear All</span>
                                            </div> */}
                                            <div className="f4div">
                                                <div className="dropdown bootstrap-select show-tick" style={{ marginRight: 10 }}>
                                                    <Multiselect
                                                        placeholder='Select Metal type'
                                                        ref={multiselectRef}
                                                        showCheckbox={true}
                                                        customCloseIcon={<AiOutlineClose size={15} style={{ paddingLeft: 2, color: 'red' }} />}
                                                        style={{
                                                            chips: { background: 'white', color: Colors.brown, textDecoration: 'underline black', fontSize: 14 },
                                                            searchBox: { "borderRadius": "0px" },

                                                        }}
                                                        showArrow
                                                        loading={IsFilterLoading ? true : false}
                                                        options={metalType}
                                                        hideSelectedList={true}
                                                        selectedValues={SelectedMetalType}
                                                        onSelect={handleMetalValues}
                                                        onRemove={handleMetalValues}
                                                        displayValue="name" />
                                                </div>
                                                <div className="dropdown bootstrap-select show-tick" style={{ marginRight: 10 }}>
                                                    <Multiselect
                                                        placeholder='Select Diamond type'
                                                        ref={multiselectRef}
                                                        customCloseIcon={<AiOutlineClose size={15} style={{ paddingLeft: 2, color: 'red' }} />}
                                                        style={{
                                                            chips: { background: 'white', color: Colors.brown, textDecoration: 'underline black', fontSize: 14 },
                                                            searchBox: { "borderRadius": "0px" },

                                                        }}
                                                        disable={sid != undefined ? true : false}
                                                        showArrow
                                                        showCheckbox={true}
                                                        loading={IsFilterLoading ? true : false}
                                                        hideSelectedList={true}
                                                        selectedValues={SelectedDiamondType}
                                                        onSelect={handleDiamondValues}
                                                        onRemove={handleDiamondValues}
                                                        options={diamondType}
                                                        displayValue="name" />
                                                    {/* <Multiselect placeholder='Select Diamond type' showArrow options={diamondType} displayValue="name" /> */}
                                                </div>
                                                <div className="dropdown bootstrap-select show-tick" style={{ marginRight: 10 }}>
                                                    <Multiselect

                                                        placeholder='Select Setting type'
                                                        ref={multiselectRef}
                                                        customCloseIcon={<AiOutlineClose size={15} style={{ paddingLeft: 2, color: 'red' }} />}
                                                        style={{
                                                            chips: { background: 'white', color: Colors.brown, textDecoration: 'underline black', fontSize: 14 },
                                                            searchBox: { "borderRadius": "0px" },

                                                        }}
                                                        showArrow
                                                        showCheckbox={true}
                                                        loading={IsFilterLoading ? true : false}
                                                        hideSelectedList={true}
                                                        selectedValues={SelectedSettingType}
                                                        onSelect={handleSettingValues}
                                                        onRemove={handleSettingValues}
                                                        options={settingType}
                                                        displayValue="name" />
                                                    {/* <Multiselect placeholder='Select Setting type' showArrow options={settingType} displayValue="name" /> */}
                                                </div>
                                                <div className="dropdown bootstrap-select show-tick" style={{ marginRight: 10 }}>
                                                    <Multiselect singleSelect
                                                        placeholder='Select Weight type'
                                                        customCloseIcon={<AiOutlineClose size={15} style={{ paddingLeft: 2, color: 'red', }} />}
                                                        style={{
                                                            chips: { background: 'white', color: Colors.brown, fontSize: 14 },
                                                            searchBox: { "borderRadius": "0px" },

                                                        }}
                                                        ref={weightselectRef}

                                                        showArrow
                                                        loading={IsFilterLoading ? true : false}
                                                        onSelect={handleWeightValues}
                                                        onRemove={handleRemoveWeightValues}
                                                        options={weight}
                                                        displayValue="name" />
                                                    {/* <Multiselect placeholder='Select Weight type' showArrow options={settingType} displayValue="name" /> */}
                                                </div>
                                                <div className="dropdown bootstrap-select show-tick" style={{ marginRight: 10 }}>
                                                    <Multiselect singleSelect
                                                        placeholder='Select Price type'
                                                        customCloseIcon={<AiOutlineClose size={15} style={{ paddingLeft: 2, color: 'red' }} />}
                                                        style={{
                                                            chips: { background: 'white', color: Colors.brown, fontSize: 14 },
                                                            searchBox: { "borderRadius": "0px" },

                                                        }}
                                                        ref={priceselectRef}
                                                        showArrow
                                                        loading={IsFilterLoading ? true : false}
                                                        onSelect={handlePriceValues}
                                                        onRemove={handleRemovePriceValues}
                                                        options={price}
                                                        displayValue="name" />

                                                </div>
                                                <div className="dropdown bootstrap-select show-tick">
                                                    <Multiselect singleSelect
                                                        placeholder='Sorting'
                                                        customCloseIcon={<AiOutlineClose size={15} style={{ paddingLeft: 2, color: 'red', }} />}
                                                        style={{
                                                            chips: { background: 'white', color: Colors.brown, fontSize: 14 },
                                                            searchBox: { "borderRadius": "0px" },

                                                        }}
                                                        showArrow
                                                        ref={sortselectRef}
                                                        onSelect={handleSortingValues}
                                                        options={sorting}
                                                        // selectedValues={SelectedSort}
                                                        displayValue="name" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {/* <div style={{ display: 'contents' }}>
                            <select title="Sorting" className=" drop-w-200" defaultValue={0} id="27" onChange={sortingFun}>
                                <option value={0}>Sorting</option>
                                <option value={1}>Low To High</option>
                                <option value={2}>High To Low</option>
                                <option value={3}>Newest</option>
                            </select>
                        </div> */}
                        </div>
                    </div>
                    <div className="container container-main">
                        <div className="d-none d-lg-block">
                            <ul className="selcet-filter" style={{}}>
                                <li className="bg-none">
                                    <span style={{ color: '#23282D', }}>Results({filterCount})</span>
                                </li>
                                {SelectedMetalType?.map((item, index) => {
                                    return (
                                        <li key={index}>
                                            <span>{item.name}</span>
                                            <a className="select-span-a hand" onClick={() => handleMetalValues(SelectedMetalType, item)}>✖</a>
                                        </li>
                                    )
                                })}
                                {SelectedDiamondType?.map((item, index) => {
                                    return (
                                        <li key={index}>
                                            <span>{item.name}</span>
                                            <a className="select-span-a hand" onClick={() => handleDiamondValues(SelectedDiamondType, item)}>{sid == undefined && '✖'}</a>
                                        </li>
                                    )
                                })}
                                {SelectedSettingType?.map((item, index) => {
                                    return (
                                        <li key={index}>
                                            <span>{item.name}</span>
                                            <a className="select-span-a hand" onClick={() => handleSettingValues(SelectedSettingType, item)}>✖</a>
                                        </li>
                                    )
                                })}
                                {SelectedWeight != '' ?

                                    <li >
                                        <span>{SelectedWeight.name}</span>
                                        <a className="select-span-a hand" onClick={() => handleRemoveWeightValues(SelectedWeight, SelectedWeight)}>✖</a>
                                    </li>
                                    : null
                                }
                                {SelectedPrice != '' ?

                                    <li >
                                        <span>{SelectedPrice.name}</span>
                                        <a className="select-span-a hand" onClick={() => handleRemovePriceValues(SelectedPrice, SelectedPrice)}>✖</a>
                                    </li>
                                    : null
                                }
                                {SelectedMetalType.length > 0 || SelectedDiamondType.length > 0 || SelectedSettingType.length > 0 || SelectedWeight != '' || SelectedPrice != '' ?
                                    <li className="clearall hand">
                                        <a onClick={() => removeAllData()}>Clear all</a>
                                    </li> : null}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <section className="jumbotron pt-3" >
                <div className="container container-main" >
                    <div className="product-page-div">

                        {isLoading ?
                            // <p style={{ textAlign: "center" }}>Processing...</p>
                            <DiamondGridSkeleton />
                            : List.length > 0 ?
                                List.map((item, index) => {
                                    let getpath = item?.feature?.map((data, i) => { return data })
                                    return (
                                        <div key={index} className="product-div find-img">
                                            <div className="product-div-div"
                                            >
                                                <div className="product-div-box" >
                                                    <span className="heart-span hand" onClick={() => token == null || token == "" || token == undefined ? window.location.pathname = BASENAME + "Login" : CallAddtoWishlistApi(item)}>
                                                        <svg width="24" height="21" viewBox="0 0 24 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M6.5 1C3.4629 1 1 3.36095 1 6.27377C1 8.62513 1.9625 14.2057 11.4368 19.8471C11.6065 19.9471 11.8013 20 12 20C12.1987 20 12.3935 19.9471 12.5632 19.8471C22.0375 14.2057 23 8.62513 23 6.27377C23 3.36095 20.5371 1 17.5 1C14.4629 1 12 4.19623 12 4.19623C12 4.19623 9.5371 1 6.5 1Z"
                                                                stroke="#ca9e79"
                                                                strokeOpacity="0.65"
                                                                strokeWidth="2"
                                                                strokeLinecap="round"
                                                                strokeLinejoin="round">
                                                            </path>
                                                        </svg>
                                                    </span>
                                                    <div className="" onClick={() => getAllData == "" ? addNewKey(item) : window.location.pathname = BASENAME + `JDetails/${utf8_to_b64(item?.id)}/${item?.slug}`}>
                                                        {/* /user/manage(/:id)(/:type)" */}
                                                        {/* <Link className=""
                                                            state={"here"}
                                                            to={process.env.PUBLIC_URL +`/JDetails/${utf8_to_b64(item?.id)}/${item?.slug}`}
                                                        > */}
                                                        <div className="product-div-list" >
                                                            <img src={item?.default?.path == null ?
                                                                getpath[0]?.path : item?.default?.path}
                                                                style={{ height: '100%', width: '100%' }}
                                                                onError={(e) => {
                                                                    e.target.onerror = null;
                                                                    e.target.src = imageErrorSrc;
                                                                    e.target.style = 'height:100px;width:100px'
                                                                }}
                                                                className="inner-img-product change-image"
                                                            />

                                                        </div>

                                                        <div className="text-center show-viewbtn">
                                                            <h5 className="product-title pt-3 line1-doted-3">
                                                                {item?.title}
                                                            </h5>
                                                            <p className="product-title-price mb-0">
                                                                ${item?.setting_price.toFixed(2)}
                                                                {/* $ {item?.offerprice == null ? item?.price : item?.offerprice} */}
                                                            </p>
                                                            <div className="pt-3 hide-view-btn">
                                                                <div className='view-details-btn'>
                                                                    <span className="span-link">
                                                                        View Details
                                                                    </span>
                                                                    <span>&nbsp;
                                                                        <svg width="8" height="11" viewBox="0 0 8 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 10L6 5.5L1 1" stroke="#23282D" strokeWidth="1.5" strokeLinecap="round" /></svg>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        {/* </Link> */}
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    )
                                })
                                :
                                <div
                                    style={{ display: "grid", flex: 1, justifyContent: "center", alignItems: 'center', backgroundColor: '#f1ecf0' }}
                                >
                                    <img
                                        src={logo}
                                        alt="loading..."
                                        style={{ width: 150, height: 150 }}
                                    />
                                    <h4>No data Found</h4>
                                </div>

                        }
                    </div>
                    <div style={{ display: "flex", justifyContent: 'flex-end', alignItems: 'center', paddingTop: 30 }}>
                        <Pagination
                            color='primary'
                            count={count}
                            size="large"
                            page={Currentpage}
                            variant="outlined"
                            shape="rounded"
                            onChange={handleChange}
                        />
                    </div>
                </div>

            </section >

            <div className="modal fade mobile-more-filter" id="more-filter" role="dialog">
                <div className="modal-dialog modal-dialog-centered modal-lg">

                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">More Filters</h5>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div className="modal-body">
                            <div className="row">
                                <div className="col-20 col-lg-4">
                                    <p className="m-tit">
                                        Gender
                                    </p>
                                    <div className="max-125-m mCustomScrollbar light">
                                        <ul className="m-ul">
                                            <li>
                                                <label className="chk-filter">Male
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Female
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Other
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="col-20 col-lg-4">
                                    <p className="m-tit">
                                        Category
                                    </p>
                                    <div className="max-125-m mCustomScrollbar light">
                                        <ul className="m-ul">
                                            <li>
                                                <label className="chk-filter">Ring
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Necklace
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Earring
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Pendant
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Solitaire
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Hoop
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Stud
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="col-20 col-lg-4">
                                    <p className="m-tit">
                                        Collection
                                    </p>
                                    <div className="max-125-m mCustomScrollbar light">
                                        <ul className="m-ul">
                                            <li>
                                                <label className="chk-filter">Anniversary
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Birthday
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Wedding
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Enagagement
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Baby Birth
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Valentine
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Mother's Day
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Women's Day
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Festive Gift
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <ToastContainer />
        </div >
    )
}
