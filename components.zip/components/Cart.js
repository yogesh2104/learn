import axios from 'axios'
import { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { Link, Navigate } from 'react-router-dom'
import { BASE_URL, GetAPIUrl } from '../API/APIUrl'
import pr1 from '../assets/images/product-details/r1.jpg'
import pp1 from '../assets/images/product/p1.png'
import pp3 from '../assets/images/product/p3.png'
import LoadingSpinner from '../module/LoadingSpinner'
import { confirmRemove, ShowErrorMessage, ShowMessage } from '../module/Tostify'
import logo from "../assets/images/logo-img.svg"
import { CallCartCountApi } from '../reducers/userReducers'
import { utf8_to_b64 } from '../helpers/Utility'

export default function Cart() {
    const token = localStorage.getItem('token')

    const [Cartlist, setCartlist] = useState([]);
    const [Count, setCount] = useState('');
    const [TotalAmount, setTotalAmount] = useState('');

    const [IsCartLoading, setIsCartLoading] = useState(false)
    const [IsWishlistLoading, setIsWishlistLoading] = useState(false)

    useEffect(() => {
        CallFetchCartListApi()
    }, [])

    const CallFetchCartListApi = async () => {
        const controller = new AbortController();
        setIsCartLoading(true)
        console.log("token = = = = ", token);
        await axios.get(BASE_URL + GetAPIUrl.CARTLIST_URL, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                console.log("res", response);

                if (response.data.success == true) {
                    setCartlist(response?.data?.carts)
                    setCount(response?.data?.count)
                    setTotalAmount(response?.data?.cart_total)

                    CallCartCountApi(token)

                } else {
                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                ShowErrorMessage(error.message)

            }).finally(() => {
                setIsCartLoading(false)
            })
        controller.abort()
    }


    const confirmRemoveAddress = (item) => {

        confirmRemove().then((result) => {
            if (result == true) {
                CallDeleteCart(item)
            }
        }

        )
    }

    const CallDeleteCart = async (item) => {
        console.log("item", item);
        const controller = new AbortController();
        var form = new FormData();

        form.append("id", item?.id);
        form.append("jewelryid", item?.CartJewelryData?.id);
        form.append("diamondid", "");

        // console.log("fff", [...form]);
        await axios.post(BASE_URL + GetAPIUrl.DELETECART_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.success == true) {

                    ShowMessage(response.data.message)
                    CallFetchCartListApi()
                } else {

                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                ShowErrorMessage(error.message)

            });
        controller.abort()
    }
    const CallDeleteDiamondCart = async (item) => {
        console.log("item", item);
        const controller = new AbortController();
        var form = new FormData();

        form.append("id", item?.id);
        form.append("jewelryid", "");
        form.append("diamondid", item?.CartDiamondData?.id);

        // console.log("fff", [...form]);
        await axios.post(BASE_URL + GetAPIUrl.DELETECART_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.success == true) {

                    ShowMessage(response.data.message)
                    CallFetchCartListApi()
                } else {

                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                ShowErrorMessage(error.message)

            });
        controller.abort()
    }


    const CallAddtoWishlistApi = async (item) => {
        const controller = new AbortController();
        // setIsWishlistLoading(true)

        var form = new FormData();

        form.append("id", item?.id == null ? "" : item?.id);

        await axios.post(BASE_URL + GetAPIUrl.MOVETOWISHLIST_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.success == true) {

                    ShowMessage(response.data.message)
                    CallFetchCartListApi()
                    // window.location.pathname = 'Wishlist'
                } else {
                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                console.error('There was an error!', error);
                ShowErrorMessage(error.message)
            }).finally(() => {
                setIsWishlistLoading(false)
            })
        controller.abort()

    }

    const addNewKey = () => {
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '', SelectedringSize: '', diamondData: '' }]));
        localStorage.removeItem('Shape');
        localStorage.removeItem('MetalType')
        localStorage.removeItem('All')
        localStorage.removeItem('Subcategory')
        localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "21" }))
    }
    return (
        <div>

            <div>
                <div className="container container-main">
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item">
                                <Link to={'/'}><i className="fa fa-home" aria-hidden="true"></i></Link>
                            </li>
                            <li className="breadcrumb-item active" aria-current="page">Cart</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <section className="pb-3">
                <div className="container">
                    <div className="text-center max-80per">
                        <h5 className="title-1 mb-2">
                            Shopping Cart
                        </h5>
                        <p style={{ fontSize: 13, color: '#7a7a7a' }}>
                            Choose a diamond to complement the jewellery you wish to create. Our extensive selection of gems feature ten different shapes as well as a range of carat sizes to suit every preference. Each diamond featured in our catalogue is responsibly sourced and comes with certification from a leading grading organisation.
                        </p>
                    </div>
                </div>
            </section>

            <section className="jumbotron pt-2">
                <div className="container container-main">
                    <div>
                        <div className="row">
                            <div className="col-md-12 col-xl-9">
                                <div className="table-responsive mar-bot-25px">
                                    <table id="dia-table" className="table table-striped1" style={{ width: '100%' }}>
                                        <thead className="tbl-header-acc">
                                            <tr className="">
                                                <th className="text-center" style={{ width: '15%' }}>
                                                    Image
                                                </th>
                                                <th className="min-200th" style={{ width: '41%' }}>
                                                    Product Details
                                                </th>
                                                <th className="text-center" style={{ minWidth: '110%' }}>
                                                    {/* Quantity */}
                                                </th>
                                                <th className="text-center" style={{ minWidth: '110%' }}>
                                                    Price
                                                </th>
                                                <th className="text-center" style={{ minWidth: '110%' }}>
                                                    Action
                                                </th>
                                            </tr>
                                        </thead>


                                        <tbody className="tr-unhov-hand table-ver-midl">
                                            {IsCartLoading ?
                                                <LoadingSpinner /> :
                                                Cartlist?.length > 0 ?
                                                    <>
                                                        {
                                                            Cartlist?.map((item, index) => {
                                                                return (
                                                                    <>
                                                                        {item?.CartJewelryData != null &&
                                                                            <tr className="trtd-13" key={index}>
                                                                                <td className="text-center">
                                                                                    <img src={item?.CartJewelryData?.default?.path} className="wish-img" />
                                                                                </td>
                                                                                <td>
                                                                                    <h6 className="heading">
                                                                                        {item?.CartJewelryData?.title}
                                                                                    </h6>
                                                                                    <div className="descList m-w-220">
                                                                                        {/* <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Stone Type</span>
                                                                                            <span style={{ padding: 8 }}>:</span>
                                                                                            <span className="wishlist_prd_right">Diamond</span>
                                                                                        </div> */}
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Metal</span>
                                                                                            <span style={{ padding: 8 }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.CartJewelryData?.metal_stamp?.paraname} {item?.CartJewelryData?.metal_type?.paraname}</span>
                                                                                        </div>
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">SKU</span>
                                                                                            <span style={{ padding: 8 }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.CartJewelryData?.itemcode}</span>
                                                                                        </div>

                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Ring Size</span>
                                                                                            <span style={{ padding: 8 }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.RingSizeData?.paraname}</span>
                                                                                        </div>
                                                                                    </div>
                                                                                </td>
                                                                                <td className="text-center"></td>
                                                                                {/* <td className="text-center">
                                                                                    <div className="quantity buttons_added">
                                                                                        <input type="button" value="-" className="minus" />
                                                                                        <input type="number" step="1" min="1" max="" name="quantity" value="1" title="Qty" className="input-text qty text" size="4" pattern="" inputmode="" />
                                                                                        <input type="button" value="+" className="plus" />
                                                                                    </div>
                                                                                </td> */}
                                                                                <td className="text-center">
                                                                                    <b>${item?.CartJewelryData?.setting_price.toFixed(2)}</b>
                                                                                </td>
                                                                                <td className="text-center">
                                                                                    <label className="edit-cart" title="Edit" onClick={() => CallAddtoWishlistApi(item)}>
                                                                                        <i className="fa fa-heart-o" aria-hidden="true"></i>
                                                                                    </label>
                                                                                    <label className="delete-cart" title="Delete" onClick={() => confirmRemoveAddress(item)}>
                                                                                        <i className="fa fa-trash"></i>
                                                                                    </label>
                                                                                </td>
                                                                            </tr>
                                                                        }
                                                                        {item?.CartJewelryData != null && item?.CartDiamondData != null ?
                                                                            <tr className="trtd-13">
                                                                                <td colSpan="6">
                                                                                    <hr className="hr-border" />
                                                                                </td>
                                                                            </tr>
                                                                            :
                                                                            <tr className="trtd-13 bor-trlast"></tr>
                                                                        }
                                                                        {item?.CartDiamondData != null &&
                                                                            <tr className="trtd-13 bor-trlast" >
                                                                                <td className="text-center">
                                                                                    <img src={item?.CartDiamondData?.image} className="wish-img" />
                                                                                </td>
                                                                                <td>
                                                                                    <h6 className="heading">
                                                                                        {item?.CartDiamondData?.title}
                                                                                    </h6>
                                                                                    <div className="descList m-w-220">
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">SKU</span>
                                                                                            <span style={{ padding: 8 }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.CartDiamondData?.loatno}</span>
                                                                                        </div>
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Shape</span>
                                                                                            <span style={{ padding: 8 }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.CartDiamondData?.shape_name?.paraname}</span>
                                                                                        </div>
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Carat</span>
                                                                                            <span style={{ padding: 8 }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.CartDiamondData?.carat}</span>
                                                                                        </div>
                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Clarity</span>
                                                                                            <span style={{ padding: 8 }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.CartDiamondData?.clarity_name?.clarityname}</span>
                                                                                        </div>

                                                                                        <div className="wishlist_plist">
                                                                                            <span className="sourcesansreg wishlist_prd_left">Color</span>
                                                                                            <span style={{ padding: 8 }}>:</span>
                                                                                            <span className="wishlist_prd_right">{item?.CartDiamondData?.color_name?.paraname}</span>
                                                                                        </div>

                                                                                    </div>
                                                                                </td>
                                                                                <td className="text-center">

                                                                                </td>
                                                                                <td className="text-center">
                                                                                    <b>${item?.CartDiamondData?.amount.toFixed(2)}</b>
                                                                                </td>
                                                                                <td className="text-center">
                                                                                    {item?.CartJewelryData == null &&
                                                                                        <label className="edit-cart" title="Edit" onClick={() => CallAddtoWishlistApi(item)}>
                                                                                            <i className="fa fa-heart-o" aria-hidden="true"></i>
                                                                                        </label>
                                                                                    }
                                                                                    <label className="delete-cart" title="Delete" onClick={() => CallDeleteDiamondCart(item)}>
                                                                                        <i className="fa fa-trash"></i>
                                                                                    </label>
                                                                                </td>
                                                                            </tr>
                                                                        }
                                                                    </>
                                                                )
                                                            })
                                                        }
                                                    </>
                                                    :
                                                    <tr>
                                                        <td colSpan={5}>
                                                            <div
                                                                style={{ display: "grid", flex: 1, justifyContent: "center", alignItems: 'center', backgroundColor: '#f1ecf0' }}
                                                            >
                                                                <img
                                                                    src={logo}
                                                                    alt="loading..."
                                                                    style={{ width: 150, height: 150 }}
                                                                />
                                                                <h4>No data Found</h4>
                                                            </div>
                                                        </td>
                                                    </tr>
                                            }
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                            <div className="col-md-12 col-xl-3">
                                <div style={{ position: 'sticky', top: 100 }}>
                                    <div className="tbl-boxprice">
                                        <div className="page-title1-head mar-bt-15-0">
                                            <div className="cart-estimate-title title-head">
                                                <span>
                                                    <h6>
                                                        <b>Shopping Bag Totals</b>
                                                    </h6>
                                                </span>
                                            </div>
                                        </div>
                                        <div>
                                            <table className="table table-striped mar-bot-tbl pricefooter lasttr pricecolor">
                                                <tfoot className="t-foot-cart cart-tb-price">
                                                    <tr className="bor-top-none">
                                                        <td className="text-left-tbl"><b>Sub-Total</b></td>
                                                        <td>
                                                            <b>:</b>
                                                        </td>
                                                        <td className="text-right-tbl fw-6">${TotalAmount}</td>
                                                    </tr>
                                                    <tr>
                                                        <td className="text-left-tbl"><b>No of Items</b></td>
                                                        <td>
                                                            <b>:</b>
                                                        </td>
                                                        <td className="text-right-tbl fw-6">{Count == 0 ? '-' : Count}</td>
                                                    </tr>
                                                    {/* <tr>
                                                        <td className="text-left-tbl"><b>Discount (5%)</b></td>
                                                        <td>
                                                            <b>:</b>
                                                        </td>
                                                        <td className="text-right-tbl fw-6">$4.00</td>
                                                    </tr>
                                                    <tr>
                                                        <td className="text-left-tbl"><b>Shipping</b></td>
                                                        <td>
                                                            <b>:</b>
                                                        </td>
                                                        <td className="text-right-tbl fw-6">Free</td>
                                                    </tr> */}
                                                    <tr>
                                                        <td className="text-left-tbl col-333"><b>Total Price</b></td>
                                                        <td>

                                                        </td>
                                                        <td className="text-right-tbl col-333"><b>${TotalAmount}</b></td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                    <div onAuxClick={() => { addNewKey(); }}
                                        onClick={() => { addNewKey(); }} >
                                        <Link
                                            className=""
                                            aria-current="page"
                                            to={`/Jewelry/${utf8_to_b64("21")}`}
                                        >
                                            <button className="add-cart-me btn-shadow-me w-100">Continue Shopping</button>
                                        </Link>

                                    </div>
                                    {Cartlist?.length > 0 &&
                                        <div>
                                            <Link
                                                className=""
                                                aria-current="page"
                                                to={`/Checkout`}
                                            >
                                                <button className="add-cart-me btn-shadow-me w-100">Proceed To Checkout</button>
                                            </Link>
                                        </div>
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    )
}
