import React from 'react'
import Breadcrumb from "react-bootstrap/Breadcrumb"; //! npm install react-bootstrap bootstrap
import { FaHome } from "react-icons/fa";   //! npm install react-icons --save
import './CustomDesign.css'
import LeftSideFrom from './LeftSideFrom';
import RightSideFrom from './RightSideFrom';
import GuideText from './GuideText';
import { Link } from 'react-router-dom';

const CustomDesign = () => {
  return (
    <>
      <div className="container">
        <div className="container container-main">
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb"> 
              <li className="breadcrumb-item">
                <Link to={'/'}><i className="fa fa-home" aria-hidden="true"></i></Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Custom Design</li>
            </ol>
          </nav>
        </div>
      </div>
      <section>
        <div className="container pd-30">
          <div className="pd-z">
            <p className="Custom-title ">CUSTOMIZE YOUR DESIGN</p>
            <hr className="hr-line" />
            <p></p>
            <br />
            <div className="row">
              <div className="col-md-8 fix-left">
                <LeftSideFrom />
              </div>
              <div className="col-md-4">
                <RightSideFrom />
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-12 container">
          <GuideText />
        </div>
      </section>
    </>
  );
}

export default CustomDesign