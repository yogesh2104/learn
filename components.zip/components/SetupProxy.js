
// const express = require('express');
// const cors = require('cors');

// const { createProxyMiddleware } = require('http-proxy-middleware');
// const { GetAPIUrl } = require('../API/APIUrl');

// const app = express();

// // app.use(cors({
// //     origin:'https://develop.d2xvqe3cz44j47.amplifyapp.com/',
// //     methods:['GET','POST','PUT','DELETE'],
// // }))


// // app.get('/cors', (req, res) => {
// // res.set('Access-Control-Allow-Origin', '*');
// // res.send({ "msg": "This has CORS enabled 🎈" })
// // })
// app.post(GetAPIUrl.B2CSIGNUP_URL, createProxyMiddleware(
//   { target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }
//   ));
// app.post(GetAPIUrl.B2BSIGNUP_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.LOGIN_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.LOGOUT_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.get(GetAPIUrl.COUNTRY, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.STATE, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.PARAMETERS, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.DIAMONDLIST_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.get(GetAPIUrl.HOME_SLIDER_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.get(GetAPIUrl.HOME_CATEGORY_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.get(GetAPIUrl.HOME_ARRIVAL_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.HOME_COLLECTION_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.get(GetAPIUrl.HOME_SIGNATURE_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.JEWELRYLIST_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.get(GetAPIUrl.JEWELRY_FILTER_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.HOME_SUBSCRIBE_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.get(GetAPIUrl.DIAMONDDETAIL_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.get(GetAPIUrl.JEWELRYDETAIL_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.ADDTOCART_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.get(GetAPIUrl.CARTLIST_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.WISHLIST_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.DELETECART_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.DELETEWISHLIST_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.SEARCH_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.UPDATEPROFILE_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.ADDADDRESS_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.get(GetAPIUrl.ADDRESS_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));
// app.post(GetAPIUrl.CATEGORY_URL, createProxyMiddleware({ target: 'https://laravel.weingenious.in/diora_adams/backend/api', changeOrigin: true, secure: false }));

// // app.listen(3000);

// // const express = require("express")
// // const cors = require("cors")
// // const axios = require("axios")
// // const app = express()

// // app.use(cors())

// // export const getJewellryList = (form) => {
// //     return axios.post(BASE_URL + GetAPIUrl.JEWELRYLIST_URL, form)
// //         .then((json) => {
// //             console.log("json.status", json);
            
// //         })
// //         .catch(error => {
// //             console.log("error.messag", error.message);

// //         });

// // } 
