import { useState } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { BASE_URL, GetAPIUrl } from '../API/APIUrl'
import call from '../assets/images/icons/call.svg'
import cart from '../assets/images/icons/cart.svg'
import hearticon from '../assets/images/icons/heart.svg'
import menuclose from '../assets/images/icons/menu-close.svg'
import menuopen from '../assets/images/icons/menu-open.svg'
import message from '../assets/images/icons/message.svg'
import search from '../assets/images/icons/search.svg'
import user from '../assets/images/icons/user.svg'
import logo from '../assets/images/logo-img.svg'
import menuimg1 from '../assets/images/menu-img1.png'
import black from '../assets/images/menu-shape/color/black.png'
import blue from '../assets/images/menu-shape/color/blue.png'
import green from '../assets/images/menu-shape/color/green.png'
import olive from '../assets/images/menu-shape/color/olive.png'
import orange from '../assets/images/menu-shape/color/orange.png'
import pink from '../assets/images/menu-shape/color/pink.png'
import purple from '../assets/images/menu-shape/color/purple.png'
import smoky from '../assets/images/menu-shape/color/smoky.png'
import white from '../assets/images/menu-shape/color/white.png'
import yellow from '../assets/images/menu-shape/color/yellow.png'
import whasscher from '../assets/images/menu-shape/white-shape/asscher.png'
import whcushion from '../assets/images/menu-shape/white-shape/cushion.png'
import whemerald from '../assets/images/menu-shape/white-shape/emerald.png'
import whheart from '../assets/images/menu-shape/white-shape/heart.png'
import whmarquise from '../assets/images/menu-shape/white-shape/marquise.png'
import whoval from '../assets/images/menu-shape/white-shape/oval.png'
import whpear from '../assets/images/menu-shape/white-shape/pear.png'
import whprincess from '../assets/images/menu-shape/white-shape/princess.png'
import whradiant from '../assets/images/menu-shape/white-shape/radiant.png'
import whround from '../assets/images/menu-shape/white-shape/round.png'
import whsquare from '../assets/images/menu-shape/white-shape/square.png'
import startdiamond from '../assets/images/start-diamond.png'
import startring from '../assets/images/start-ring.png'
import { fetch2, fetchGet } from '../helpers/fetch'
import Cookies from "universal-cookie";
import { logout, updateUser } from '../reducers/userReducers'
import { confirmLogout, confirmRemove, ShowErrorMessage, ShowMessage } from '../module/Tostify'
import { useDispatch, useSelector } from 'react-redux'
import LoadingSpinner from '../module/LoadingSpinner'
import axios from 'axios'
import { useEffect } from 'react'
import { Colors } from '../constant/Constant'
import { Messages } from '../constant/Messages'
import Swal from 'sweetalert2'

const $ = window.$;

export default function Myaccount() {
    const token = localStorage.getItem('token')
    const userData = useSelector(state => state.user.data)
    const publicIp = require("react-public-ip");

    const [state, setState] = useState({
        firstname: '',
        lastname: '',
        email: '',
    }
    );

    const { firstname, lastname, email, mobileno, oldpassword, newPassword, confirmPassword } = state;


    const [saveAddress, setSaveAddress] = useState({});
    const [ErrorsData, setErrorsData] = useState('')


    const { Addfirstname, Addlastname, Addmobileno, Addaddress, Addemail, pincode,
        Addcity, Addressid } = saveAddress;


    const [CountryList, setCountryList] = useState([])
    const [stateList, setStateList] = useState([])

    const [country, setCountry] = useState('')
    const [Addstate, setAddstate] = useState('')

    const [changePass, setChangePass] = useState(true)
    const [errorResponse, setErrorResponse] = useState(true)

    const [oldPassShow, setOldPassShow] = useState(false)
    const [newPassShow, setNewPassShow] = useState(false)
    const [cPassShow, setCPassShow] = useState(false)
    const [showDetail, setShowDetail] = useState(false)
    const [selectedMenu, setSelectedMenu] = useState('personal-id')
    const menu = [
        {
            menuName: 'Personal Info',
            datavalue: 'personal-id',
            href: 'javascript:void(0)',
        },
        {
            menuName: 'My Address',
            datavalue: 'myaddress-id',
            href: 'javascript:void(0)',
        },
        {
            menuName: 'My Order',
            datavalue: 'myorder-id',
            href: 'javascript:void(0)',
        },
        {
            menuName: 'Log out',
            datavalue: '',
            href: 'javascript:void(0)',
        },
    ]
    const [Loading, setLoading] = useState(false)
    const [profileLoading, setProfileLoading] = useState(false)
    const [addressListLoading, setAddressListLoading] = useState(false)
    const [addressList, setAddressList] = useState([])
    const [SaveAddressLoading, setSaveAddressLoading] = useState(false)


    // const [Addfirstname, setAddFirstName] = useState('')
    // const [Addlastname, setAddLastName] = useState('')
    // const [address, setAddress] = useState('')
    // const [CountryList, setCountryList] = useState([])
    // const [stateList, setStateList] = useState([])
    // const [states, setStates] = useState('')
    // const [city, setCity] = useState('')
    // const [pincode, setPincode] = useState('')
    const [isdefault, setisdefault] = useState(false)

    const cookies = new Cookies();
    let navigate = useNavigate();
    const dispatch = useDispatch()

    const Remember = cookies.get('email') == undefined ? false : true

    const authenticate = async () => {
        // dispatch(logout())
        setLoading(true)
        // const result = await fetch2(BASE_URL + GetAPIUrl.LOGOUT_URL, null, token)
        // console.log("result", result);
        await axios.post(BASE_URL + GetAPIUrl.LOGOUT_URL, null, {
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {

                if (response.data?.success == true) {
                    if (Remember == false) {
                        cookies.remove('email', { path: process.env.PUBLIC_URL + "/" });
                        cookies.remove('password', { path: process.env.PUBLIC_URL + "/" });
                    }
                    navigate('/Login')
                    dispatch(logout())
                    ShowMessage(response.data.message)
                    setLoading(false)
                    // window.location.pathname = '/Login'

                } else {
                    ShowErrorMessage(response.data.message)
                    setLoading(false)
                }
            });
    }
    const updateProfile = async () => {
        setProfileLoading(true)

        var formdata = new FormData();
        formdata.append("firstname", firstname);
        formdata.append("lastname", lastname);
        formdata.append("email", email);
        formdata.append("mobileno", mobileno == undefined ? '' : mobileno);
        formdata.append("change_password", changePass);

        if (changePass == true) {
            formdata.append("old_password", oldpassword == undefined ? '' : oldpassword);
            formdata.append("password", newPassword == undefined ? '' : newPassword);
            formdata.append("confirm_password", confirmPassword == undefined ? '' : confirmPassword);
        }

        await axios.post(BASE_URL + GetAPIUrl.UPDATEPROFILE_URL, formdata, {
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {

                if (response.data?.success == true) {
                    localStorage.setItem('data', JSON.stringify(response.data.data))
                    dispatch(updateUser());
                    ShowMessage(response.data.message)
                    setProfileLoading(false)
                    // window.location.pathname = '/Login'

                } else {

                    ShowErrorMessage(response.data.message)
                    setProfileLoading(false)
                }
            }).catch((e) => {
                setErrorResponse(e.response.data.errors)
                setProfileLoading(false)
            })
    }

    const fetchMyAddress = async () => {
        setAddressListLoading(true)
        await axios.get(BASE_URL + GetAPIUrl.ADDRESS_URL, {
            headers: {
                'Accept': 'application/json',
                'Authorization': "Bearer " + localStorage.getItem('token')
            }
        })
            .then(response => {

                if (response?.data?.success == true) {
                    setAddressList(response?.data?.userAdddress)
                } else {
                }
            }).catch((error) => {
                ShowErrorMessage(error)
            }).finally(() => {
                setAddressListLoading(false)
            })
    }

    const SaveAddress = async () => {

        const ipv4 = await publicIp.v4() || "";
        const ipv6 = await publicIp.v6() || "";
        let data = {
            "id": Addressid != undefined || Addressid != '' ? Addressid : '',
            "firstname": Addfirstname,
            "lastname": Addlastname,
            "email": Addemail,
            "address": Addaddress,
            "city": Addcity,
            "state": Addstate,
            "country": country,
            "zip": pincode,
            "mobileno": Addmobileno,
            "ip_address": ipv4 == undefined ? '' : ipv4,
            "isdefault": isdefault == true ? 1 : 0
        }
        await axios.post(BASE_URL + GetAPIUrl.ADDADDRESS_URL, data, {
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                console.log("response", response);
                if (response.data.code == 200) {

                    return (
                        Swal.fire({
                            title: 'Sweet!',
                            text: 'Data Successfully Saved.!',
                            icon: "success",

                            allowOutsideClick: false,
                            allowEscapeKey: false,

                        }).then((result) => {
                            if (result.isConfirmed) {
                                $('#address-modal').modal('hide');
                                ShowMessage(response.data.message)
                                resetAll()
                                fetchMyAddress()
                            }
                        })
                    )
                } else {
                    ShowErrorMessage(response.errors.message)
                }
            }).catch((error) => {
                console.log("error", error);
                setErrorsData(error.response.data.errors)
            })

    }


    const CallCountryApi = async () => {
        const result = await axios.get(BASE_URL + GetAPIUrl.COUNTRY)
        if (result.data.success == true) {
            setCountryList(result.data.data)
            setAddstate('')
        }
    }
    const CallStateApi = async (countryid) => {
        let data = {
            "countryid": countryid,
        }
        const result = await fetch2(BASE_URL + GetAPIUrl.STATE, data)
        console.log("result", result);
        if (result.success == true) {
            setStateList(result.data)
        }
        // console.log("result", result);
    }
    useEffect(() => {

        if (userData) {
            setState({ ...userData });
        }
        fetchMyAddress()
        CallCountryApi()
    }, [userData]);


    const handleTextChange = e => {
        let { name, value } = e.target;
        setState({ ...state, [name]: value });
    }
    const handleAddressChange = e => {
        let { name, value } = e.target;
        setSaveAddress({ ...saveAddress, [name]: value });
    }
    const updateState = async (item) => {
        resetAll()
        console.log("item", item);
        let countryId = ''
        let stateId = ''

        let data = {
            "countryid": item?.country,
        }

        let result = await axios.get(BASE_URL + GetAPIUrl.COUNTRY)
        if (result.data.success == true) {
            setCountryList(result.data.data)
            // result.data.data.filter((tag) => tag?.id == item?.id ? flag = tag.name : null)
            result.data.data.filter((tag) => {
                if (tag?.id == item?.country) {
                    countryId = tag?.id

                }
            })
        }

        const stateResult = await fetch2(BASE_URL + GetAPIUrl.STATE, data)
        if (stateResult.success == true) {
            setStateList(stateResult?.data)
            stateResult?.data?.filter((tag) => {
                if (tag?.id == item?.state) {
                    stateId = tag?.id
                }
            })
        }
        console.log("stateflag", stateId, countryId);

        setCountry(countryId)
        setAddstate(stateId)
        setSaveAddress({
            "Addressid": item?.id,
            "userid": item?.userid,
            "Addfirstname": item?.firstname,
            "Addlastname": item?.lastname,
            "Addemail": item?.email,
            "Addmobileno": item?.mobileno,
            "Addaddress": item?.address,
            "Addcity": item?.city,
            "pincode": item?.pincode,
        })

        setisdefault(item?.isdefault === 1 ? true : false)
    }

    const resetAll = () => {
        setCountry('')
        setAddstate('')
        setSaveAddress({
            "Addressid": '',
            "userid": '',
            "Addfirstname": '',
            "Addlastname": '',
            "Addemail": '',
            "Addmobileno": '',
            "Addaddress": '',
            "Addcity": '',
            "pincode": '',
        })
        setisdefault(false)
        setErrorsData('')

    }

    const confirmLogoutBtn = () => {

        confirmLogout().then((result) => {
            if (result == true) {
                authenticate()
            }
        }

        )
    }
    const confirmRemoveAddress = (item) => {

        confirmRemove().then((result) => {
            if (result == true) {
                removeAddress(item)
            }
        }

        )
    }
    const removeAddress = async (item) => {
        let data = {
            "id": item.id,
        }
        await axios.post(BASE_URL + GetAPIUrl.REMOVEADDRESS_URL, data, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        }).then(response => {
            console.log("response", response.data);
            if (response.data.code == 200) {
                ShowMessage(response.data.message)
                fetchMyAddress()
            } else {
                ShowErrorMessage(response.data.message)
            }

            // result.data.data.filter((tag) => tag?.id == item?.id ? flag = tag.name : null)

        }).catch(() => {

        }).finally(() => {

        })
    }
    // $(function () {
    //     if ($("#address-modal").modal('hide')){
    //         resetAll()
    //     }
    // })

    return (
        <div>
            {Loading || profileLoading || addressListLoading || SaveAddressLoading == true &&

                <LoadingSpinner />
            }

            <div>
                <div className="container container-main">
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><Link to={'/'}><i className="fa fa-home" aria-hidden="true"></i></Link></li>
                            <li className="breadcrumb-item active" aria-current="page">My Account</li>
                        </ol>
                    </nav>
                </div>
            </div>

            <section className="jumbotron pt-3">
                <div className="container container-main">
                    <div>
                        <div className="row">
                            <div className="col-lg-3" style={{ display: 'grid' }} >
                                <div className="thumbsider" style={{ position: 'sticky', top: '100%' }}>
                                    <ul className="left-list ul-box-shadow ul-bg mar-b-10">

                                        {menu?.map((item, index) => {
                                            return (
                                                <a key={index}
                                                    className={selectedMenu == item.datavalue ?
                                                        "active-select-li active-list-li" : 'active-select-li'}
                                                    data-value={item.datavalue}
                                                    href={() => item.href}
                                                    onClick={() => { item.menuName == 'Log out' ? confirmLogoutBtn() : setSelectedMenu(item.datavalue) }} >
                                                    <li>{item.menuName}</li>
                                                </a>

                                            )
                                        })
                                        }
                                    </ul>
                                </div>
                            </div>
                            <div className="col-lg-9">
                                <div>
                                    <div className="acc-right-box main-div" id="personal-id" style={{ display: selectedMenu != 'personal-id' && 'none' }}>
                                        <div>
                                            <h5 className="title-1">
                                                Personal Information
                                            </h5>
                                            <p className="col777">
                                                {Messages.PERSONAL_INFO}
                                            </p>
                                        </div>
                                        <br />
                                        <div className="row">
                                            <div className="col-lg-4">
                                                <div className="form-group text-left">
                                                    <label className="lblmy">First Name:</label>
                                                    <input type="text"
                                                        className="form-control my-textbox"
                                                        id="fname"
                                                        placeholder="First Name"
                                                        name="firstname"
                                                        value={firstname || ""}
                                                        onChange={handleTextChange}
                                                    />
                                                    <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                        {errorResponse != '' && errorResponse?.firstname?.map((key, i) => key)}
                                                    </p>
                                                </div>
                                            </div>
                                            <div className="col-lg-4">
                                                <div className="form-group text-left">
                                                    <label className="lblmy">Last Name:</label>
                                                    <input type="text" className="form-control my-textbox"
                                                        id="lname"
                                                        name="lastname"
                                                        placeholder="Last Name"
                                                        value={lastname}
                                                        onChange={handleTextChange}
                                                    />
                                                    <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                        {errorResponse != '' && errorResponse?.lastname?.map((key, i) => key)}
                                                    </p>
                                                </div>
                                            </div>
                                            <div className="col-lg-4">
                                                <div className="form-group text-left">
                                                    <label className="lblmy">Email Id:</label>
                                                    <input disabled={true} type="text" className="form-control my-textbox"
                                                        id="emailid"
                                                        placeholder="Email Id"
                                                        name="email"
                                                        value={email || ""}
                                                        onChange={handleTextChange}
                                                    />
                                                    <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                        {errorResponse != '' && errorResponse?.email?.map((key, i) => key)}
                                                    </p>
                                                </div>
                                            </div>
                                            {/* <div className="col-lg-4">
                                                <div className="form-group text-left">
                                                    <label className="lblmy">Mobile no:</label>
                                                    <input type="text"
                                                        className="form-control my-textbox"
                                                        id="mobileno"
                                                        placeholder="Mobile Number"
                                                        name="mobileno"
                                                        value={mobileno || ""}
                                                        onChange={handleTextChange}
                                                    />
                                                </div>
                                            </div> */}
                                        </div>
                                        <br />
                                        <div>
                                            <div className="form-group mar-b-14">
                                                <label className="chk-sign mar-top-10" style={{ fontWeight: 500, display: 'inline-block' }} >
                                                    Change Password
                                                    <input type="checkbox" id="changepasschk"
                                                        name="changepasschk"
                                                        checked={changePass ? true : false}
                                                        onChange={() => setChangePass(!changePass)} />
                                                    <span className="checkmark-chk"></span>
                                                </label>
                                            </div>
                                            {changePass ?
                                                <div className="check-pass-div">
                                                    <div className="row">
                                                        <div className="col-lg-4">
                                                            <div className="form-group text-left input-pass">
                                                                <label className="lblmy">Old Password:</label>
                                                                <input type={oldPassShow ? "password" : 'text'}
                                                                    style={{ font: oldPassShow && "small-caption", }}
                                                                    className="form-control my-textbox"
                                                                    id="oldpassword"
                                                                    name="oldpassword"
                                                                    placeholder="Old Password"
                                                                    value={oldpassword || ""}
                                                                    onChange={handleTextChange}
                                                                />
                                                                <span className="show-pass hand" title={oldPassShow ? "Hide password" : "show password"} onClick={() => setOldPassShow(!oldPassShow)} style={{ paddingLeft: 5, paddingRight: 5 }} >
                                                                    <i className={oldPassShow ? "fa fa-eye oldpassword" : 'fa fa-eye-slash'} aria-hidden="true"></i>
                                                                </span>

                                                            </div>
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorResponse != '' && errorResponse.old_password?.map((key, i) => key)}
                                                            </p>
                                                        </div>
                                                        <div className="col-lg-4">
                                                            <div className="form-group text-left input-pass">
                                                                <label className="lblmy">New Password:</label>
                                                                <input type={newPassShow ? "password" : 'text'}
                                                                    style={{ font: newPassShow && "small-caption", }}
                                                                    className="form-control my-textbox" id="newpassword"
                                                                    placeholder="New Password"
                                                                    name="newPassword"
                                                                    value={newPassword || ""}
                                                                    onChange={handleTextChange}
                                                                />
                                                                <span className="show-pass hand" title={newPassShow ? "Hide password" : "show password"} onClick={() => setNewPassShow(!newPassShow)} style={{ paddingLeft: 5, paddingRight: 5 }}>
                                                                    <i className={newPassShow ? "fa fa-eye oldpassword" : 'fa fa-eye-slash'} aria-hidden="true"></i>
                                                                </span>
                                                            </div>
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorResponse != '' && errorResponse?.password?.map((key, i) => key)}
                                                            </p>
                                                        </div>
                                                        <div className="col-lg-4">
                                                            <div className="form-group text-left input-pass">
                                                                <label className="lblmy">Confirm Password:</label>
                                                                <input type={cPassShow ? "password" : 'text'}
                                                                    style={{ font: cPassShow && "small-caption", }}
                                                                    className="form-control my-textbox" id="confpassword"
                                                                    placeholder="Confirm Password"
                                                                    name="confirmPassword"
                                                                    value={confirmPassword || ""}
                                                                    onChange={handleTextChange}
                                                                />
                                                                <span className="show-pass hand" title={cPassShow ? "Hide password" : "show password"} onClick={() => setCPassShow(!cPassShow)} style={{ paddingLeft: 5, paddingRight: 5 }}>
                                                                    <i className={cPassShow ? "fa fa-eye oldpassword" : 'fa fa-eye-slash'} aria-hidden="true"></i>
                                                                </span>
                                                            </div>
                                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                                {errorResponse != '' && errorResponse?.confirm_password?.map((key, i) => key)}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div> : null}
                                        </div>
                                        <br />
                                        <div className="row">
                                            <div className="col-lg-3" onClick={() => updateProfile()}>
                                                <a className="acc-save-nowbtn mb-2">
                                                    Save
                                                </a>
                                            </div>
                                            <div className="col-lg-3">
                                                <a className="cancel-nowbtn mb-2">
                                                    Cancel
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="acc-right-box main-div" id="myaddress-id" style={{ display: selectedMenu != 'myaddress-id' && 'none' }}>
                                        <div>
                                            <h5 className="title-1">
                                                My Address
                                            </h5>
                                            {/* <p className="col777">
                                                It is a long established fact that a reader will be distracted by the readable content.
                                            </p> */}
                                        </div>
                                        <br />

                                        <div className="mar-bot-30">
                                            {addressList?.map((item, index) => {
                                                return (
                                                    item?.isdefault == 1 &&
                                                    <div className="row mar-bot-10" key={index}>
                                                        <div className="col-lg-8 col-md-7">
                                                            <h6 className="lsp1 colmain"> <b className="f-500">Default Billing Address</b></h6>
                                                        </div>
                                                        {/* <div className="col-lg-4 col-md-5">
                                                            <a className="change-add-btn mobile-1rem-bot" data-toggle="modal" data-target="#address-modal">
                                                                Change Address
                                                            </a>
                                                        </div> */}
                                                    </div>
                                                )
                                            })}
                                            <div className="row">
                                                <div className="col-lg-12">
                                                    <div className="box-content">
                                                        {addressList?.map((item, index) => {
                                                            return (
                                                                item?.isdefault == 1 &&
                                                                <div className="add-p" key={index}>
                                                                    <a className="change-add-btn mobile-1rem-bot" onClick={() => updateState(item)} data-toggle="modal" data-target="#address-modal">
                                                                        Change Address
                                                                    </a>
                                                                    <p>{item?.firstname} {item?.lastname}</p>
                                                                    <p>{item?.address}</p>
                                                                    <p>{item?.city}-{item?.pincode}</p>
                                                                    <p>Mobile No: <a className="color-80" href={`tel:${item?.mobileno}`}>{item.mobileno}</a>
                                                                    </p>
                                                                </div>
                                                                // :
                                                                // <span style={{ marginTop: 10, display: 'block' }} > You have no Default address entries in your address book. </span>

                                                            )
                                                        })}
                                                    </div>
                                                </div>
                                            </div>
                                            <hr className="hrmy" />
                                            <div className="row mar-bot-15">
                                                <div className="col-lg-12">
                                                    <h6 className="lsp1 colmain">
                                                        <b className="f-500">Additional Address Entries</b>
                                                    </h6>
                                                    {addressList?.map((item, index) => {
                                                        return (
                                                            item?.isdefault == 0 &&
                                                            <div className="row mar-bot-10" key={index}>
                                                                <div className="col-lg-12 col-md-7 add-p">
                                                                    <a className="change-add-btn mobile-1rem-bot" onClick={() => updateState(item)} data-toggle="modal" data-target="#address-modal">
                                                                        Change Address
                                                                    </a>
                                                                    <p>{item?.firstname} {item?.lastname}</p>

                                                                    <p>{item?.address}</p>
                                                                    <p>{item?.city}-{item?.pincode}</p>
                                                                    <p>Mobile No: <a className="color-80" href={`tel:${item?.mobileno}`}>{item.mobileno}</a>
                                                                    </p>
                                                                    <button type="button" className="btn btn-danger" onClick={() => confirmRemoveAddress(item)}>Remove</button>

                                                                    <hr className="hrmy" />

                                                                </div>
                                                                {/* <div className="col-lg-2 col-md-5">
                                                                        <a className="change-add-btn mobile-1rem-bot" data-toggle="modal" data-target="#address-modal">
                                                                            Change Address
                                                                        </a>
                                                                    </div> */}
                                                            </div>
                                                        )
                                                    })}
                                                </div>
                                            </div>

                                            <div className="row">
                                                <div className="col-lg-3"> <a data-toggle="modal" data-target="#address-modal"
                                                    className="acc-save-nowbtn mb-2 hand" onClick={() => resetAll()}
                                                    style={{ marginTop: 25 }}> Add New Address </a>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div className="acc-right-box main-div" id="myorder-id" style={{ display: selectedMenu != 'myorder-id' && 'none' }}>

                                        <div className="ord-details-div" style={{ display: !showDetail && 'none' }} >
                                            <div>
                                                <h5 className="title-1" style={{ marginBottom: 20 }} >
                                                    <span className="show-ord-list-div hand" onClick={() => setShowDetail(false)}>
                                                        <i className="fa fa-chevron-left" aria-hidden="true"></i> Back to Order List
                                                    </span>
                                                </h5>
                                                <table className="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <td className="text-left font-liberation-bold" colSpan="2">Order Details</td>
                                                        </tr>
                                                    </thead>
                                                    <tbody className="bg-fff">
                                                        <tr>
                                                            <td className="text-left" style={{ width: '50%' }}>
                                                                <b>Order ID:</b> #11217
                                                                <br />
                                                                <b>Date Added:</b> 11/04/2020
                                                            </td>
                                                            <td className="text-left" style={{ width: '50%' }}>
                                                                <b>Payment Method:</b> Cash On Delivery
                                                                <br />
                                                                <b>Shipping Method:</b> Free Shipping
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <table className="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <td className="text-left font-liberation-bold" style={{ width: '50%', verticalAlign: 'top' }}>Payment Address</td>
                                                            <td className="text-left font-liberation-bold" style={{ width: '50%', verticalAlign: 'top' }}>Shipping Address</td>
                                                        </tr>
                                                    </thead>
                                                    <tbody className="bg-fff">
                                                        <tr>
                                                            <td className="text-left">Khagesh Soni
                                                                <br />Lorem Ipsum Lorem
                                                                <br />Surat 394221
                                                                <br />Andhra Pradesh
                                                                <br />India
                                                            </td>
                                                            <td className="text-left">Khagesh Soni
                                                                <br />Lorem Ipsum Lorem
                                                                <br />Surat 394221
                                                                <br />Andhra Pradesh
                                                                <br />India
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <div className="table-responsive mar-bot-25px thtable" style={{ boxShadow: ' 0 2px 7px 3px #dee2e6a6' }}>
                                                    <table id="order-table" className="table table-striped1" style={{ width: '100%', marginBottom: 0, boxShadow: ' 0 2px 7px 3px #e8e8e8' }}>
                                                        <thead className="font-auto tbl-header" style={{ width: '100%' }}>
                                                            <tr className="trth-center th-r-bor">
                                                                <th className="text-left" style={{ minWidth: 250 }}>Product Name</th>
                                                                <th style={{ minWidth: 100 }}>Date</th>
                                                                <th style={{ minWidth: 100 }}>Status</th>
                                                                <th style={{ minWidth: 100 }}>Order Total</th>
                                                                <th style={{ minWidth: 100 }}>Action</th>

                                                            </tr>
                                                        </thead>
                                                        <tbody className="tr-unhov-hand table-striped1-odd" >
                                                            <tr className="trtd-center trtd-13 tr-hov-td" >
                                                                <td style={{ width: '30%' }} className="text-left">Antique Filigree Diamond Ring</td>
                                                                <td>4/10/20</td>
                                                                <td><span className="pending-tag">Pending</span></td>
                                                                <td>$1,568.00</td>
                                                                <td>
                                                                    <a title="Return Order" href="javascript:void(0);" className="col-site add-row details-icon show-view"> <i className="fa fa-reply hand" aria-hidden="true"></i>
                                                                    </a>&nbsp;
                                                                    <a href="#" className="col-site add-row details-icon" title="Reorder"> <i className="fa fa-retweet" aria-hidden="true"></i>
                                                                    </a>&nbsp;
                                                                    <a title="Cancel Order" href="#" className="col-site add-row details-icon"> <i className="fa fa-window-close-o" aria-hidden="true"></i>
                                                                    </a>
                                                                </td>
                                                            </tr>

                                                            <tr className="trtd-center trtd-13 tr-hov-td" style={{ borderBottomStyle: 'hidden' }}>
                                                                <td className="f-div-cart" style={{ padding: 10, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                                                    <img src="http://localhost:3000/static/media/p3.3d81e6293b9a246b5c9d.png" width="50%" className="max-150-img" />
                                                                </td>
                                                                <td colSpan={2} className="s-div-cart" style={{ padding: 10, position: 'relative', textAlign: 'left' }}>
                                                                    <a href="https://www.dovediamonds.com.au/diamonddetail/Loose-Diamonds/PearCut Diamond-1244453">
                                                                        <h6> 0.30 Pear Cut Diamond </h6>
                                                                    </a>
                                                                    <p className="mb-1"> VG Cut | F Colour | SI1 Clarity </p>
                                                                    <p>Stock : #UC32025</p>
                                                                    <h6 style={{ color: 'black' }}> Price: AU$ 187.00 </h6>
                                                                </td>
                                                                <td colSpan={2} style={{ verticalAlign: 'bottom' }}>
                                                                    {/* <div className="remove-bottom d-none d-md-block">
                                                                                <a href='' onclick="removecart(1657023987)">Remove Item</a>
                                                                            </div> */}
                                                                    <div className="t-div-cart d-block  d-md-none">
                                                                        <h4 className="mb-4"> Price: $187 </h4>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr><td colSpan="6"><hr className="hr-border" /></td></tr>
                                                            <tr className="trtd-center trtd-13 tr-hov-td" style={{ borderTopStyle: 'hidden' }}>
                                                                <td className="f-div-cart" style={{ padding: 10, position: 'relative', display: 'flex', borderTopStyle: 'hidden', alignItems: 'center', justifyContent: 'center' }}>
                                                                    <img src="http://localhost:3000/static/media/r1.d4776484921927d226f1.jpg" width="50%" className="max-150-img" />
                                                                </td>
                                                                <td colSpan={2} className="s-div-cart" style={{ padding: 10, position: 'relative', textAlign: 'left' }}>
                                                                    <a href="https://www.dovediamonds.com.au/diamonddetail/Loose-Diamonds/PearCut Diamond-1244453">
                                                                        <h6> 0.30 Pear Cut Diamond </h6>
                                                                    </a>
                                                                    <p className="mb-1"> VG Cut | F Colour | SI1 Clarity </p>
                                                                    <p>Stock : #UC32025</p>
                                                                    <h6 style={{ color: 'black' }}> Price: AU$ 187.00 </h6>
                                                                </td>
                                                                <td colSpan={2} style={{ verticalAlign: 'bottom' }}>
                                                                    {/* <div className="remove-bottom d-none d-md-block">
                                                                                <a href='' onclick="removecart(1657023987)">Remove Item</a>
                                                                            </div> */}
                                                                    <div className="t-div-cart d-block  d-md-none">
                                                                        <h6 className="mb-4"> Price: $187 </h6>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                        <tfoot className="myacc-tbl-fot" style={{ width: '100%' }}>
                                                            <tr className="subtotal">
                                                                <th colSpan="4" className="mark" scope="row">Subtotal:</th>
                                                                <td className="" data-th="Subtotal"> <span className="price">$1,568.00</span>
                                                                </td>
                                                            </tr>
                                                            <tr className="shipping">
                                                                <th colSpan="4" className="mark" scope="row">Shipping &amp; Handling:</th>
                                                                <td className="" data-th="Shipping &amp; Handling"> <span className="price">$0.00</span>
                                                                </td>
                                                            </tr>
                                                            <tr className="grand_total">
                                                                <th colSpan="4" className="mark amount" scope="row"> <strong>Grand Total:</strong>
                                                                </th>
                                                                <td className="amount" data-th="Grand Total"> <strong><span className="price col000">$1,568.00</span></strong>
                                                                </td>
                                                            </tr>
                                                        </tfoot>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="ord-list-div" style={{ display: showDetail && 'none' }} >
                                            <div>
                                                <h5 className="title-1">
                                                    My Order
                                                </h5>
                                                <p className="col777">
                                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.
                                                </p>
                                            </div>
                                            <br />
                                            <div className="row">
                                                <div className="col-lg-12">
                                                    <div className="table-responsive wishlist-tbl">
                                                        <table className="w-100">
                                                            <thead className="first-wish-th">
                                                                <tr>
                                                                    <th className="text-left">Order Id</th>
                                                                    <th>Date</th>
                                                                    <th className="text-left">Ship To</th>
                                                                    <th>Order Total</th>
                                                                    <th>Status</th>
                                                                    <th>Action</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody className="tr-odd-even">
                                                                <tr>
                                                                    <td>
                                                                        000019001
                                                                    </td>
                                                                    <td className="text-center">
                                                                        4/10/20
                                                                    </td>
                                                                    <td className="text-left">
                                                                        Antique Filigree Diamond Ring
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <h6> $77.00 </h6>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <span className="pending-tag">Pending</span>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <a className="action-btn show-details-div" onClick={() => setShowDetail(true)}>
                                                                            <i className="fa fa-eye hand"></i>
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        0450194587
                                                                    </td>
                                                                    <td className="text-center">
                                                                        06/12/20
                                                                    </td>
                                                                    <td className="text-left">
                                                                        Antique Filigree Diamond Ring
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <h6> $88.00 </h6>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <span className="completed-tag">Completed</span>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <a className="action-btn show-details-div" onClick={() => setShowDetail(true)}>
                                                                            <i className="fa fa-eye hand"></i>
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        000019001
                                                                    </td>
                                                                    <td className="text-center">
                                                                        4/10/20
                                                                    </td>
                                                                    <td className="text-left">
                                                                        Antique Filigree Diamond Ring
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <h6> $77.00 </h6>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <span className="pending-tag">Pending</span>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <a className="action-btn show-details-div" onClick={() => setShowDetail(true)}>
                                                                            <i className="fa fa-eye hand"></i>
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        0450194587
                                                                    </td>
                                                                    <td className="text-center">
                                                                        06/12/20
                                                                    </td>
                                                                    <td className="text-left">
                                                                        0.6ct Round Diamond, G-VS2
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <h6> $88.00 </h6>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <span className="completed-tag">Completed</span>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <a className="action-btn show-details-div" onClick={() => setShowDetail(true)}>
                                                                            <i className="fa fa-eye hand"></i>
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        000019001
                                                                    </td>
                                                                    <td className="text-center">
                                                                        4/10/20
                                                                    </td>
                                                                    <td className="text-left">
                                                                        Antique Filigree Diamond Ring
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <h6> $77.00 </h6>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <span className="pending-tag">Pending</span>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <a className="action-btn show-details-div" onClick={() => setShowDetail(true)}>
                                                                            <i className="fa fa-eye hand"></i>
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        0450194587
                                                                    </td>
                                                                    <td className="text-center">
                                                                        06/12/20
                                                                    </td>
                                                                    <td className="text-left">
                                                                        0.6ct Round Diamond, G-VS2
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <h6> $88.00 </h6>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <span className="completed-tag">Completed</span>
                                                                    </td>
                                                                    <td className="text-center">
                                                                        <a className="action-btn show-details-div" onClick={() => setShowDetail(true)}>
                                                                            <i className="fa fa-eye hand"></i>
                                                                        </a>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>



            <div className="modal fade" id="address-modal" style={{ display: 'none' }} aria-hidden="true" >
                <div className="modal-dialog modal-lg" role="document">
                    <div className="modal-content">
                        <div className="modal-header" >
                            <h5 className="modal-title Feijoa">Add New Address</h5>
                            <button type="button" className="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true" style={{ fontSize: 30 }}>×</span>
                            </button>
                        </div>
                        <div className="modal-body" style={{ paddingLeft: 25, paddingRight: 25 }} >
                            <div className="row collf-14">
                                <div className="col-lg-6">
                                    <div className="form-group form-lablecss">
                                        <label className="lblmy">First Name*</label>
                                        <input type="text"
                                            className="form-control my-textbox"
                                            placeholder=""
                                            name="Addfirstname"
                                            value={Addfirstname || ""}
                                            onChange={handleAddressChange}
                                        />
                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                            {ErrorsData.firstname != undefined && ErrorsData?.firstname?.map((key, i) => key)}
                                        </p>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="form-group form-lablecss">
                                        <label className="lblmy">Last Name*</label>
                                        <input type="text" className="form-control my-textbox"
                                            name="Addlastname"
                                            value={Addlastname || ""}
                                            onChange={handleAddressChange}
                                        />
                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                            {ErrorsData.lastname != undefined && ErrorsData?.lastname?.map((key, i) => key)}
                                        </p>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="form-group form-lablecss">
                                        <label className="lblmy">Mobile no*</label>
                                        <input type="text"
                                            maxLength={10}
                                            className="form-control my-textbox"
                                            name="Addmobileno"
                                            value={Addmobileno || ""}
                                            onChange={handleAddressChange}
                                        />
                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                            {ErrorsData.mobileno != undefined && ErrorsData?.mobileno?.map((key, i) => key)}
                                        </p>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="form-group form-lablecss">
                                        <label className="lblmy">Email id*</label>
                                        <input type="text" className="form-control my-textbox"
                                            name="Addemail"
                                            value={Addemail || ""}
                                            onChange={handleAddressChange}
                                        />
                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                            {ErrorsData.email != undefined && ErrorsData?.email?.map((key, i) => key)}
                                        </p>
                                    </div>
                                </div>
                                <div className="col-lg-12">
                                    <div className="form-group form-lablecss">
                                        <label className="lblmy">Address*</label>
                                        <textarea rows="2" className="form-control my-textbox" style={{ minHeight: 'auto' }}
                                            name="Addaddress"
                                            value={Addaddress || ""}
                                            onChange={handleAddressChange}
                                        ></textarea>
                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                            {ErrorsData.address != undefined && ErrorsData?.address?.map((key, i) => key)}
                                        </p>
                                    </div>
                                </div>
                                {/* <div className="col-lg-6">
                                    <div className="form-group form-lablecss">
                                        <label className="lblmy">Country*</label>
                                        <select className="form-control my-textbox">
                                            <option value="india">India</option>
                                            <option data-code="US" value="United States">United States</option>
                                            <option data-code="VN" value="Vietnam">Vietnam</option>
                                            <option data-code="AU" value="Australia">Australia</option>
                                            <option data-code="AT" value="Austria">Austria</option>
                                            <option data-code="AZ" value="Azerbaijan">Azerbaijan</option>
                                            <option data-code="BS" value="Bahamas">Bahamas</option>
                                            <option data-code="BH" value="Bahrain">Bahrain</option>
                                            <option data-code="BZ" value="Belize">Belize</option>
                                            <option data-code="BJ" value="Benin">Benin</option>
                                        </select>
                                    </div>
                                </div> */}
                                <div className="col-xl-6 col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label className="lblmy">Country <sup>*</sup></label>
                                        <select
                                            value={country}
                                            name="Country"
                                            id="Country"
                                            className="form-control my-textbox selectarrow-none"
                                            data-parsley-trigger="change"
                                            data-parsley-errors-container="#Country_msg"
                                            required=""
                                            onChange={(e) => { CallStateApi(e.target.value); setCountry(e.target.value) }}
                                        >
                                            <option value="" disabled="">Select Country</option>
                                            {CountryList?.map((item, index) => {
                                                return (
                                                    <option key={index} value={item?.id} data-value={item?.id}>{item?.name}</option>
                                                )
                                            })}

                                        </select>
                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                            {ErrorsData.country != undefined && ErrorsData?.country?.map((key, i) => key)}
                                        </p>
                                        {/* <p id="Country_msg"></p> */}

                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="form-group form-lablecss">
                                        <label className="lblmy">State*</label>
                                        <select disabled={country == '' ? true : false}
                                            value={Addstate}
                                            name="State" id="State" className="form-control my-textbox"
                                            data-parsley-trigger="change"
                                            data-parsley-errors-container="#State_msg"
                                            onChange={(e) => setAddstate(e.target.value)}
                                        >
                                            <option value="" disabled="" >Select State</option>
                                            {stateList?.map((item, index) => {
                                                return (
                                                    <option key={index} value={item?.id} data-value={item?.id}>{item?.name}</option>
                                                )
                                            })}
                                        </select>
                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                            {ErrorsData.state != undefined && ErrorsData?.state?.map((key, i) => key)}
                                        </p>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="form-group form-lablecss">
                                        <label className="lblmy">City*</label>
                                        <input type="text"
                                            className="form-control my-textbox"
                                            name="Addcity"
                                            value={Addcity}
                                            onChange={handleAddressChange}
                                        />
                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                            {ErrorsData.city != undefined && ErrorsData?.city?.map((key, i) => key)}
                                        </p>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="form-group form-lablecss">
                                        <label className="lblmy">Pincode*</label>
                                        <input type="text" className="form-control my-textbox"
                                            name="pincode"
                                            value={pincode}
                                            onChange={handleAddressChange}
                                        />
                                        <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                            {ErrorsData.zip != undefined && ErrorsData?.zip?.map((key, i) => key)}
                                        </p>
                                    </div>
                                </div>

                                <div className="col-lg-12">
                                    {/* <div className="form-group checkbox-wrapper">
                                        <div className="page__section">
                                            <div className="page__toggle">
                                                <label className="toggle">
                                                    <input className="toggle__input" type="checkbox" />
                                                    <span className="toggle__label">
                                                        <span className="toggle__text">Use as my default billing address</span>
                                                    </span>
                                                </label>
                                            </div>

                                        </div> */}
                                    <div className="form-group checkbox-wrapper">
                                        <label className="checkboxs"> Use as my default billing address
                                            <input type="checkbox"
                                                id="isdefault"
                                                name="isdefault"
                                                value="isdefault"
                                                checked={isdefault}
                                                onChange={() => setisdefault(!isdefault)} />
                                            <span className="checkmark"></span>
                                        </label>

                                    </div>

                                </div>
                                {/* <div className="col-lg-12">
                                    <div className="form-group">

                                        <label className="chk-sign mar-top-10" sstyle={{ fontWeight: 500, display: 'inline-block' }}>
                                            Use as my default shipping address
                                            <input type="checkbox" />
                                            <span className="checkmark-chk"></span>
                                        </label>
                                    </div>
                                </div> */}
                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" onClick={() => resetAll()} data-dismiss="modal" className="btn cancel-nowbtn" style={{ minWidth: 120, borderRadius: 0 }}>Close</button>

                            <button type="button" onClick={() => SaveAddress()} className="btn acc-save-nowbtn" style={{ minWidth: 120, borderRadius: 0 }}>Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </div >
    )
}
