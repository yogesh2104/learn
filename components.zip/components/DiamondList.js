import React, { useState } from "react";


import Blackdiamond from "../assets/images/color-diamond/Black.png";
import Bluediamond from "../assets/images/color-diamond/Blue.png";
import Graydiamond from "../assets/images/color-diamond/Gray.png";
import Greendiamond from "../assets/images/color-diamond/Green.png";
import Orangediamond from "../assets/images/color-diamond/Orange.png";
import Pinkdiamond from "../assets/images/color-diamond/Pink.png";
import Purplediamond from "../assets/images/color-diamond/Purple.png";
import Reddiamond from "../assets/images/color-diamond/Red.png";
import Violetdiamond from "../assets/images/color-diamond/Violet.png";
import Yellowdiamond from "../assets/images/color-diamond/Yellow.png";
import logo from "../assets/images/logo-img.svg";
import asscher from "../assets/images/menu-shape/white-shape/asscher.png";
import cushion from "../assets/images/menu-shape/white-shape/cushion.png";
import emerald from "../assets/images/menu-shape/white-shape/emerald.png";
import heart from "../assets/images/menu-shape/white-shape/heart.png";
import marquise from "../assets/images/menu-shape/white-shape/marquise.png";
import oval from "../assets/images/menu-shape/white-shape/oval.png";
import pear from "../assets/images/menu-shape/white-shape/pear.png";
import princess from "../assets/images/menu-shape/white-shape/princess.png";
import radiant from "../assets/images/menu-shape/white-shape/radiant.png";
import round from "../assets/images/menu-shape/white-shape/round.png";
import r1 from "../assets/images/product-details/r1.jpg";
import noimage from "../assets/images/product-details/noimage.jpg";

import AsscherDiamond from "../assets/images/diamond-shape/shape/Asscher.png";
import CushionDiamond from "../assets/images/diamond-shape/shape/Cushion.png";
import EmeraldDiamond from "../assets/images/diamond-shape/shape/Emerald.png";
import HeartDiamond from "../assets/images/diamond-shape/shape/Heart.png";
import MarquiseDiamond from "../assets/images/diamond-shape/shape/Marquise.png";
import OvalDiamond from "../assets/images/diamond-shape/shape/Oval.png";
import PearDiamond from "../assets/images/diamond-shape/shape/Pear.png";
import roundDiamond from "../assets/images/diamond-shape/shape/Round.png";

import axios from "axios";
import { useEffect } from "react";
import RadiantDiamond from "../assets/images/diamond-shape/shape/Pear.png";
import PrincessDiamond from "../assets/images/diamond-shape/shape/Princess.png";

import { Link, Navigate, useLocation, useParams } from "react-router-dom";
import igi_cert from "../assets/igi_cert.jpg";
import { Colors } from "../constant/Constant";
import { fetch2 } from "../helpers/fetch";
import { BASE_URL, GetAPIUrl } from "../API/APIUrl";
import { useSelector } from "react-redux";
import { CategorySkeleton, DiamondFilterSkeleton, DiamondGridSkeleton, DiamondListSkeleton } from "../module/Skeletons";
import { ShowErrorMessage, ShowMessage } from "../module/Tostify";
import { Pagination } from "@material-ui/lab";
import { b64_to_utf8, utf8_to_b64 } from "../helpers/Utility";
import Slider from "@mui/material/Slider";



const $ = window.$;


const DiamondList = () => {
  let { did, mincarat, maxcarat, slug } = useParams();

  // console.log("dianmon.search", did == undefined ? "" : b64_to_utf8(did), slug, mincarat == undefined ? "" : b64_to_utf8(mincarat), maxcarat == undefined ? "" : b64_to_utf8(maxcarat),);




  // const location = useLocation();
  // const state = location?.state?.fromDashboard;
  // console.log("state", state.fromDashboard);

  const [List, setList] = useState([]);
  const [filterList, setFilterList] = useState([]);
  const [filterCount, setFilterCount] = useState();

  const [isLoading, setIsLoading] = useState(false);

  const [minPrice, setMinPrice] = useState('');

  const [maxPrice, setMaxPrice] = useState('');

  const [fixedMinPrice, setFixedMinPrice] = useState('');
  const [fixedMaxPrice, setFixedMaxPrice] = useState('');

  const [minCarat, setMinCarat] = useState('');

  const [maxCarat, setMaxCarat] = useState('');

  const [fixedMinCarat, setFixedMinCarat] = useState('');
  const [fixedMaxCarat, setFixedMaxCarat] = useState('');

  const [minTable, setMinTable] = useState('');

  const [maxTable, setMaxTable] = useState('');
  const [fixedMinTable, setFixedMinTable] = useState('');
  const [fixedMaxTable, setFixedMaxTable] = useState('');

  const [minDepth, setMinDepth] = useState('');

  const [maxDepth, setMaxDepth] = useState('');
  const [fixedMinDepth, setFixedMinDepth] = useState('');
  const [fixedMaxDepth, setFixedMaxDepth] = useState('');



  // let { minPrice, maxPrice, minCarat, maxCarat, minTable, maxTable, minDepth, maxDepth } = state


  const [hide, setHide] = useState(true);
  const [hideAll, setHideAll] = useState(false);

  const [selectedShape, setSelectedShape] = useState(did == undefined ? [] : [{ id: b64_to_utf8(did) }]);
  const ShapeIds = localStorage.getItem('Shape')

  console.log("ShapeIds", ShapeIds);

  const [selectedClarity, setSelectedClarity] = useState([]);
  const [selectedColor, setSelectedColor] = useState([]);
  const [selectedCut, setSelectedCut] = useState([]);
  const [selectedFlour, setSelectedFlour] = useState([]);
  const [selectedPolish, setSelectedPolish] = useState([]);
  const [selectedSym, setSelectedSym] = useState([]);
  const [selectedLab, setSelectedLab] = useState([]);

  const [prodSelected, setProdSelected] = useState(false);

  const [prodSelectedIndex, setProdSelectedIndex] = useState(-1);

  const [selectedDiaType, setSelectedDiaType] = useState(slug == "Lab" || slug == "Natural" ? slug : 'Lab');

  const [shapeId, setShapeId] = useState(did == undefined ? [] : [b64_to_utf8(did)]);
  const [ClarityId, setClarityId] = useState([]);
  const [ColorId, setColorId] = useState([]);
  const [CutId, setCutId] = useState([]);
  const [SymId, setSymId] = useState([]);
  const [FluorescenceId, setFluorescenceId] = useState([]);
  const [PolishId, setPolishId] = useState([]);
  const [LabId, setLabId] = useState([]);
  const [Currentpage, setCurrentpage] = useState(1);
  const [length, setLength] = useState(28);

  const PER_PAGE = length;
  const FromSetting = JSON.parse(localStorage.getItem('FromSetting'))
  const [Category, setCategory] = useState(JSON.parse(localStorage.getItem('Category')) ? JSON.parse(localStorage.getItem('Category')) : '')
  const [getAllData, setGetAllData] = useState(JSON.parse(localStorage.getItem('All')) != null ? JSON.parse(localStorage.getItem('All')) : '')

  const count = Math.ceil(filterCount / PER_PAGE);

  const [shapes, setShapes] = useState([])
  const [Clarity, setClarity] = useState([])
  const [Color, setColor] = useState([])
  const [Cut, setCut] = useState([])
  const [Fluorescence, setFluorescence] = useState([])
  const [Polish, setPolish] = useState([])
  const [Sym, setSym] = useState([])
  const [Lab, setLab] = useState([])
  const [SortColumn, setSortColumn] = useState('')
  const [SortOrder, setSortOrder] = useState("ASC")

  const token = useSelector((state) => state?.user?.token)

  const DiaType = [
    {
      id: 66,
      type: "Natural",
      DiaName: "Natural",
    },
    {
      id: 67,
      type: "Lab",
      DiaName: "Lab Down",
    },
  ];


  // const _DATA = usePagination(List, PER_PAGE);

  const handleChange = (e, p) => {
    setCurrentpage(p);
    setProdSelected(false)
    // _DATA.jump(p);
  };

  const [sort, setSort] = useState(1);


  useEffect(() => {

    AllParameter()
    $(function () {

      $(".show-adv-option").click(function () {
        $(".more-option-filter").slideToggle();
        $(".hideadvtxt").toggle();
        $(".showadvtxt").toggle();
        $(".downcl").toggle();
        $(".upcl").toggle();
      });
    })

    $(function () {

      $(".clickli .col-list").click(function () {
        $(this).toggleClass("all-active");
      });
      $(".clickli-shape").click(function () {
        $(this).toggleClass("all-active-shape");
      });
      $(window).on("load", function () {
        if ($(window).width() < 767) {
          $(".first-afilter a:nth-child(2)").addClass("ataglist-thumb-active");
        }
        if ($(window).width() > 768) {
          $(".first-afilter a:first-child").addClass("ataglist-thumb-active");
        }
      });

      $(".table-list-click").click(function () {
        $(".ataglist-thumb").removeClass("ataglist-thumb-active");
        $(".thumblist-view-data").hide();
        $(".pair-tableview-data").hide();
        $(".table-view-data").show();
        $(this).addClass("ataglist-thumb-active");
      });
      $(".thumblist-list-click").click(function () {
        $(".ataglist-thumb").removeClass("ataglist-thumb-active");
        $(".table-view-data").hide();
        $(".pair-tableview-data").hide();
        $(".thumblist-view-data").show();
        $(this).addClass("ataglist-thumb-active");
      });

      $(".pair-tablelist-click").click(function () {
        $(".ataglist-thumb").removeClass("ataglist-thumb-active");
        $(".table-view-data").hide();
        $(".thumblist-view-data").hide();
        $(".pair-tableview-data").show();
        $(this).addClass("ataglist-thumb-active");
      });
    })

    $(function () {
      $(".show-all-adv-option").click(function () {
        $(".hide-all-setfilter").slideToggle();
        $(".hidealladvtxt").toggle();
        $(".showalladvtxt").toggle();
        $(".downclall").toggle();
        $(".upclall").toggle();
      });

    })


  }, [])

  // useEffect(() => {

  // }, [
  //   shapeId,
  //   ClarityId,
  //   ColorId,
  //   CutId,
  //   SymId,
  //   FluorescenceId,
  //   PolishId,
  //   LabId,
  //   selectedDiaType,
  //   Currentpage,
  // ])
  React.useEffect(() => {
    const getSliderFilterData = setTimeout(() => {
      DiamondListsApi(Currentpage, '', '');
    }, 800)
    return () => clearTimeout(getSliderFilterData)
  }, [Currentpage, shapeId, minPrice, maxPrice, ColorId, ClarityId, PolishId, SymId, LabId, FluorescenceId, maxCarat, minCarat, minDepth, maxDepth, minTable, maxTable, selectedDiaType])



  const [Loading, setLoading] = useState(false)

  const AllParameter = async () => {
    const controller = new AbortController();
    setLoading(true)
    var form = new FormData();
    form.append("type", "diamond");
    form.append("paraname[]", "Shape");
    form.append("paraname[]", "Cut");
    form.append("paraname[]", "Clarity");
    form.append("paraname[]", "color");
    form.append("paraname[]", "Flour");
    form.append("paraname[]", "Polish");
    form.append("paraname[]", "Symmetry");
    form.append("paraname[]", "Lab");
    axios.post(BASE_URL + GetAPIUrl.PARAMETERS, form)
      .then(response => {
        if (response.data.success == true) {
          setLoading(false)
          setShapes(response?.data?.data?.Shape)
          setClarity(response?.data?.data?.Clarity)
          setColor(response?.data?.data?.Color)
          setCut(response?.data?.data?.Cut)
          setFluorescence(response?.data?.data?.Flour)
          setPolish(response?.data?.data?.Polish)
          setSym(response?.data?.data?.Symmetry)
          setLab(response?.data?.data?.Lab)

          setMinPrice(response?.data?.data?.Price.min)
          setMaxPrice(response?.data?.data?.Price.max)
          setFixedMinPrice(response?.data?.data?.Price.min)
          setFixedMaxPrice(response?.data?.data?.Price.max)




          // setMinPrice(mincarat == undefined ? "" : b64_to_utf8(mincarat) == "null" ? response?.data?.data?.Price.min : b64_to_utf8(mincarat))
          // setMaxPrice(maxcarat == undefined ? "" : b64_to_utf8(maxcarat) == "null" ? response?.data?.data?.Price.max : b64_to_utf8(maxcarat))

          setMinCarat(response?.data?.data?.Carat.min)
          setMaxCarat(response?.data?.data?.Carat.max)
          setFixedMinCarat(response?.data?.data?.Carat.min)
          setFixedMaxCarat(response?.data?.data?.Carat.max)

          setMinTable(response?.data?.data?.Table.min)
          setMaxTable(response?.data?.data?.Table.max)
          setFixedMinTable(response?.data?.data?.Table.min)
          setFixedMaxTable(response?.data?.data?.Table.max)

          setMinDepth(response?.data?.data?.Depth.min)
          setMaxDepth(response?.data?.data?.Depth.max)
          setFixedMinDepth(response?.data?.data?.Depth.min)
          setFixedMaxDepth(response?.data?.data?.Depth.max)


        } else {
          setLoading(false)
          ShowErrorMessage(response?.data?.message)
        }
      })
      .catch(error => {
        ShowErrorMessage(error.message)

      });
    controller.abort()

  }

  const DiamondListsApi = async (Currentpage, SortColumn, SortOrder) => {
    const controller = new AbortController
    let count = length * (Currentpage - 1)
    setIsLoading(true);

    var form = new FormData();
    form.append("draw", Currentpage);
    form.append("start", Currentpage == 1 ? 0 : count);
    form.append("length", length);
    form.append("filter[Shape]", shapeId);
    form.append("filter[ColorName]", ColorId);
    form.append("filter[ClarityName]", ClarityId);
    form.append("filter[CutName]", CutId);
    form.append("filter[PolishName]", PolishId);
    form.append("filter[SymName]", SymId);
    form.append("filter[Flour]", FluorescenceId);
    form.append("filter[LAB]", LabId);
    form.append("filter[DiaType][]", selectedDiaType);
    form.append("filter[CaratMin]", minCarat);
    form.append("filter[CaratMax]", maxCarat);
    form.append("filter[PriceMin]", minPrice);
    form.append("filter[PriceMax]", maxPrice);
    form.append("filter[DepthMin]", minDepth);
    form.append("filter[DepthMax]", maxDepth);
    form.append("filter[TableMin]", minTable);
    form.append("filter[TableMax]", maxTable);
    form.append("filter[SortColumn]", SortColumn);
    form.append("filter[SortOrder]", SortOrder);


    await axios.post(BASE_URL + GetAPIUrl.DIAMONDLIST_URL, form).then((json) => {
      if (json.status == 200) {
        setFilterCount(json.data.recordsFiltered);
        setList(json.data.data);
        setFilterList(json.data.data);
        setIsLoading(false);
        if (ShapeIds != null) {
          let data = {
            "id": json?.data?.data[0]?.shape_name?.id,
            "name": json?.data?.data[0]?.shape_name?.paraname,
            "description": json?.data[0]?.data?.shape_name?.description,
            "image": json?.data?.data[0]?.shape_name?.image,
          }
          localStorage.setItem('Shape', JSON.stringify([data]));
        }
      } else {
        setIsLoading(false);
        ShowErrorMessage(json.data.message)
      }

    }).catch(error => {
      ShowErrorMessage(error.message)
    });
    controller.abort()
  };



  const ResetFilters = () => {

    setSelectedShape([]);
    setShapeId([]);
    setSelectedClarity([]);
    setClarityId([]);
    setSelectedColor([]);
    setColorId([]);
    setSelectedCut([]);
    setCutId([]);


    setMinPrice(139.75)
    setMaxPrice(7220.00)


    setMinCarat(0.5)
    setMaxCarat(4)



    setMinTable(49.5)
    setMaxTable(81.5)



    setMinDepth(55.2)
    setMaxDepth(76.9)

    setSelectedFlour([]);
    setFluorescenceId([]);
    setSelectedPolish([]);
    setPolishId([]);
    setSelectedSym([]);
    setSymId([]);

    setSelectedLab([]);
    setLabId([]);
    setSort(1);
    setSelectedDiaType("Lab");
    setCurrentpage(1);
    setList([...filterList]);
  };
  const handleFilterShape = (item) => {

    let array = [...selectedShape];
    let selectedIndex = array.findIndex((d) => d.id == item.id);
    if (array?.length > 0 && selectedIndex >= 0) {
      array.splice(selectedIndex, 1);
    } else {
      array.push(item);
    }
    let ShapeId = array?.map((item) => {
      return item.id;
    });

    setShapeId([...ShapeId]);
    setCurrentpage(1);

    setSelectedShape(array);
  };
  const handleFilterClarity = (item) => {
    let array = [...selectedClarity];
    let selectedIndex = array.findIndex((d) => d.id == item.id);
    if (array?.length > 0 && selectedIndex >= 0) {
      array.splice(selectedIndex, 1);
    } else {
      array.push(item);
    }
    let ClarityId = array?.map((item) => {
      return item.id;
    });
    setClarityId(ClarityId);
    setCurrentpage(1);

    setSelectedClarity(array);
  };

  const handleFilterColor = (item) => {
    let array = [...selectedColor];
    let selectedIndex = array.findIndex((d) => d.id == item.id);
    if (array?.length > 0 && selectedIndex >= 0) {
      array.splice(selectedIndex, 1);
    } else {
      array.push(item);
    }
    let ColorId = array?.map((item) => {
      return item.id;
    });
    setColorId(ColorId);
    setCurrentpage(1);

    setSelectedColor(array);
  };

  const handleFilterCut = (item) => {
    let array = [...selectedCut];
    let selectedIndex = array.findIndex((d) => d.id == item.id);
    if (array?.length > 0 && selectedIndex >= 0) {
      array.splice(selectedIndex, 1);
    } else {
      array.push(item);
    }
    let CutId = array?.map((item) => {
      return item.id;
    });
    setCutId(CutId);
    setCurrentpage(1);

    setSelectedCut(array);
  };

  const handleTextChange = (event) => {
    event.preventDefault()
    setMinPrice(event.target.value);

  };
  const handleTextChange2 = (event) => {
    event.preventDefault()
    setMaxPrice(event.target.value);
  };

  const handleChange3 = (event, newValue) => {
    event.preventDefault()
    setMinPrice(newValue[0]);
    setMaxPrice(newValue[1]);
  };

  const handleCaratChange = (event, newValue) => {
    event.preventDefault()
    setMinCarat(newValue[0]);
    setMaxCarat(newValue[1]);
  };
  const handleCaratTextChange = (event) => {
    event.preventDefault()
    setMinCarat(event.target.value);

  };
  const handleCaratTextChange2 = (event) => {
    event.preventDefault()
    setMaxCarat(event.target.value);
  };


  const handleTableChange = (event, newValue) => {
    event.preventDefault()
    setMinTable(newValue[0]);
    setMaxTable(newValue[1]);
  };
  const handleTableTextChange = (event) => {
    event.preventDefault()
    setMinTable(event.target.value);

  };
  const handleTableTextChange2 = (event) => {
    event.preventDefault()
    setMaxTable(event.target.value);
  };

  const handleDepthChange = (event, newValue) => {
    event.preventDefault()
    setMinDepth(newValue[0]);
    setMaxDepth(newValue[1]);
  };
  const handleDepthTextChange = (event) => {
    event.preventDefault()
    setMinDepth(event.target.value);

  };
  const handleDepthTextChange2 = (event) => {
    event.preventDefault()
    setMaxDepth(event.target.value);
  };



  const handleFilterFlour = (item) => {
    let array = [...selectedFlour];
    let selectedIndex = array.findIndex((d) => d.id == item.id);
    if (array?.length > 0 && selectedIndex >= 0) {
      array.splice(selectedIndex, 1);
    } else {
      array.push(item);
    }
    let FluorescenceId = array?.map((item) => {
      return item.id;
    });
    setFluorescenceId(FluorescenceId);
    setCurrentpage(1);

    setSelectedFlour(array);
  };

  const handleFilterPolish = (item) => {
    let array = [...selectedPolish];
    let selectedIndex = array.findIndex((d) => d.id == item.id);
    if (array?.length > 0 && selectedIndex >= 0) {
      array.splice(selectedIndex, 1);
    } else {
      array.push(item);
    }
    let PolishId = array?.map((item) => {
      return item.id;
    });
    setPolishId(PolishId);
    setCurrentpage(1);

    setSelectedPolish(array);
  };

  const handleFilterSym = (item) => {
    let array = [...selectedSym];
    let selectedIndex = array.findIndex((d) => d.id == item.id);
    if (array?.length > 0 && selectedIndex >= 0) {
      array.splice(selectedIndex, 1);
    } else {
      array.push(item);
    }
    let SymId = array?.map((item) => {
      return item.id;
    });
    setSymId(SymId);
    setCurrentpage(1);

    setSelectedSym(array);
  };


  const handleFilterLab = (item) => {
    let array = [...selectedLab];
    let selectedIndex = array.findIndex((d) => d.id == item.id);
    if (array?.length > 0 && selectedIndex >= 0) {
      array.splice(selectedIndex, 1);
    } else {
      array.push(item);
    }
    let LabId = array?.map((item) => {
      return item.id;
    });
    setLabId(LabId);
    setCurrentpage(1);

    setSelectedLab(array);
  };

  const openDetail = (index) => {
    let array = [...List];
    array.some((item, tag) => {
      if (tag == index) {
        setProdSelectedIndex(index);
        setProdSelected(!prodSelected);
      }
    });
  };
  const AddStorageData = (item) => {
    // localStorage.setItem('DiamondId', item.id)
    FromSetting?.map(tag => {
      console.log("tag", tag);
      localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: tag?.jewelryData, SelectedringSize: tag?.SelectedringSize, diamondData: item }]))
    })
  }


  const HandleSorting = (e) => {
    //  [ColorName,ClarityName,CutName,carat]
    if (e.target.name === SortColumn) {
      setSortOrder(SortOrder == "DESC" ? "ASC" : "DESC")
      DiamondListsApi(Currentpage, e.target.name, SortOrder == "DESC" ? "ASC" : "DESC")
    } else {
      DiamondListsApi(Currentpage, e.target.name, "DESC")
      setSortOrder("DESC")

    }
    setSortColumn(e.target.name)
  }

  return (
    <>

      <div className="container container-main">
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb">
            {/* <li className="breadcrumb-item">

                <Link
                  className="fa fa-home"
                  aria-current="page"
                  aria-hidden='true'
                  to={"/"}
                >

                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                Diamond
              </li> */}
          </ol>
        </nav>
      </div>
      {getAllData == '' &&
        FromSetting?.map((tag, index) => {
          return (
            Category.categoryName != "All" ?
              // Category?.map(item => item?.categoryId != '') ?
              <section className="mobile-view-none" key={index}>
                <div className="container container-main">
                  <div className="wizard2-steps mb-3">
                    <div className="step wizard2-steps-heading">
                      <div className="node">
                        <div className="node-skin">
                          <div className="cont">
                            <h2 className="nostyle-heading">Build Your Own Ring</h2>
                          </div>
                        </div>
                      </div>
                    </div>
                    {
                      tag?.jewelryData == '' ?
                        <div className="cyo-bar-step step step-item">
                          <div className="node" >
                            <div className="node-skin">
                              <div className="pho">
                                <img src={process.env.PUBLIC_URL + "/assets/images/steps/setting.svg"} alt="setting" />
                              </div>
                              <div className="cont">
                                <div className="action help-tips">
                                  <a href="#" className="td-u bar-action line1-doted-2"></a>
                                </div>
                                <div className="heading">
                                  <div className="action help-tips">
                                    <a href="#" className="td-u bar-action">Choose</a>
                                  </div>
                                  <h2 className="nostyle-heading">setting</h2>


                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        :
                        <div className="cyo-bar-step step step-item active-step keep-left">
                          <div className="node" >
                            <div className="node-skin">
                              <div className="pho">

                                <img style={{ background: 'rgba(76, 175, 80, 0.1)' }} src={tag?.jewelryData?.default.path} alt="setting" />


                              </div>
                              <div className="cont">
                                <div className="heading"><h2 className="nostyle-heading">Setting</h2>
                                  <div className="action help-tips">
                                    <div className="td-u bar-action">{tag?.jewelryData?.title}
                                      <aside>Price :${tag?.jewelryData?.setting_price?.toFixed(2)}</aside></div>
                                  </div>
                                  {/* <div className="action double-action">
                                  <Link
                                    className="td-u bar-action"
                                    aria-current="page"
                                    style={{ textDecoration: "none" }}

                                    to={process.env.PUBLIC_URL +`/Jewelry/${tag?.jewelryData?.title}`}
                                  >
                                    Change
                                  </Link>
                                  <Link
                                    className="td-u bar-action"
                                    aria-current="page"
                                    style={{ textDecoration: "none" }}

                                    to={process.env.PUBLIC_URL +`/JDetails/${utf8_to_b64(tag?.jewelryData?.id)}/${tag?.jewelryData?.title}`}
                                  >
                                    View
                                  </Link>
                                </div> */}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                    }
                    {tag?.diamondData == '' ?
                      <div className="cyo-bar-step step step-item active-step keep-left">
                        <div className="node" >
                          <div className="node-skin">
                            <div className="pho">
                              <img src={process.env.PUBLIC_URL + "/assets/images/steps/diamonds.svg"} alt="diamond" />
                            </div>
                            <div className="cont">
                              <div className="action help-tips">
                                <a href="#" className="td-u bar-action line1-doted-2"></a>
                              </div>
                              <div className="heading">
                                <div className="action help-tips">
                                  <a href="#" className="td-u bar-action">Choose</a>
                                </div>
                                <h2 className="nostyle-heading">Diamond</h2>


                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      :
                      <div className="cyo-bar-step step step-item  active-step keep-left">
                        <div className="node" >
                          <div className="node-skin">
                            <div className="pho">
                              <img src={tag?.diamondData?.image} alt="diamond" style={{ backgroundColor: "white" }} />
                            </div>
                            <div className="cont">
                              <div className="action help-tips">
                                <a href="#" className="td-u bar-action line1-doted-2"></a>
                              </div>
                              <div className="heading">
                                <h2 className="nostyle-heading">Diamond</h2>
                                <div className="action help-tips">
                                  <div className="td-u bar-action">{tag?.diamondData?.carat} Carat {tag?.diamondData?.ShapeName} Diamond, {tag?.diamondData?.ColorName}-{tag?.diamondData?.ClarityName}
                                    <aside>Price :${tag.diamondData.amount}</aside></div>
                                </div>
                                {/* <div className="action double-action">
                                <Link
                                  className="td-u bar-action"
                                  aria-current="page"
                                  style={{ textDecoration: "none" }}

                                  to={process.env.PUBLIC_URL +`/DiamondList/${tag?.diamondData?.carat} Carat ${tag?.diamondData?.ShapeName} Diamond, ${tag?.diamondData?.ColorName}-${tag?.diamondData?.ClarityName}`}

                                >
                                  Change
                                </Link>
                                <Link
                                  className="td-u bar-action"
                                  aria-current="page"
                                  style={{ textDecoration: "none" }}

                                  to={process.env.PUBLIC_URL +`/DiamondDetails/${utf8_to_b64(tag?.diamondData?.id)}/${tag?.diamondData?.carat} Carat ${tag?.diamondData?.ShapeName} Diamond, ${tag?.diamondData?.ColorName}-${tag?.diamondData?.ClarityName}`}

                                >
                                  View
                                </Link>
                              </div> */}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    }

                    {tag?.diamondData != '' && tag?.jewelryData != '' ?
                      <div className="step step-item invariant-color active-step keep-left">
                        <div className="node">
                          <div className="node-skin">
                            <div className="pho">
                              <img src={process.env.PUBLIC_URL + "/assets/images/steps/ring.svg"} alt="ring" style={{ backgroundColor: "white" }} />
                            </div>
                            <div className="cont">
                              <div className="action help-tips">TOTAL</div>
                              <div className="heading"><h2 className="nostyle-heading">${(tag?.jewelryData?.setting_price + tag?.diamondData?.amount)?.toFixed(2)}</h2></div>
                            </div>
                          </div>
                        </div>
                      </div>
                      :
                      <div className="step step-item invariant-color">
                        <div className="node">
                          <div className="node-skin">
                            <div className="pho">
                              <img src={process.env.PUBLIC_URL + "/assets/images/steps/ring.svg"} alt="ring" />
                            </div>
                            <div className="cont">
                              {/* <div className="action help-tips">Choose</div> */}
                              <div className="heading"><h2 className="nostyle-heading">TOTAL</h2></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    }
                  </div>
                </div>
              </section>
              :
              <section>
                <div class="container">
                  <div class="text-center max-80per">
                    <h5 class="title-1 mb-2">
                      Diamonds
                    </h5>
                    <p style={{ fontSize: "13px", color: "#7a7a7a" }}>
                      Choose a diamond to complement the jewellery you wish to create. Our extensive selection of gems feature ten different shapes as well as a range of carat sizes to suit every preference. Each diamond featured in our catalogue is responsibly sourced and comes with certification from a leading grading organisation.
                    </p>
                  </div>
                </div>
              </section>
          )
        })


      }
      <section className="pb-4">
        <div className="main-div" id="natural-id">
          <div className="set-filter-div set-filter-click">
            <h6>
              Set Filters <span className="s1">+</span>
              <span className="s2">−</span>
            </h6>
          </div>

          <div
            className="container container-main hide-all-setfilter"
            style={{}}
          >
            <div className="">
              <div className="row">
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Shape
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="Choose a diamond to complement the jewellery you wish to create. Our extensive selection of gems feature ten different shapes as well as a range of carat sizes to suit every preference."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      {Loading == true ?
                        <DiamondFilterSkeleton />
                        :
                        shapes?.map((item, index) => {
                          let selected = selectedShape?.some((tag) => {
                            return JSON.parse(tag.id) === item.id;
                          });
                          return (
                            <li
                              key={index}
                              className={
                                selected
                                  ? "all-active-shape"
                                  : "hand line-h-2 clickli-shape"
                              }
                              data-toggle="tooltip"
                              title={item.description}
                            >
                              <div style={{ cursor: ShapeIds === null ? 'pointer' : 'default' }}
                                className="shapes"
                                onClick={() => { ShapeIds === null && handleFilterShape(item) }}
                              >
                                <img src={item.image} width="27" />
                              </div>
                              <p className="mb-0">{item.name}</p>
                            </li>
                          );
                        })}
                    </ul>
                  </div>
                </div>

                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Clarity
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="Inclusions are birthmarks that give each diamond its own personality and add up to form the diamond's clarity. Gemologists rate the clarity of gemstones on a scale of FL to I3, with FL being the highest level of clarity. The clarity of diamonds is determined by the microscopic imperfections or flaws in the diamond throughout the growing process."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      {Loading == true ?
                        <DiamondFilterSkeleton />
                        :
                        Clarity?.map((item, index) => {
                          let selected = selectedClarity.some((tag) => {
                            return tag.id === item.id;
                          });

                          return (
                            <li
                              key={index}
                              className="hand line-h-2 clickli-shape"
                              data-toggle="tooltip"
                              title={item.description}
                            >
                              <div
                                className={
                                  selected ? "col-list all-active" : "col-list"
                                }
                                onClick={() => handleFilterClarity(item)}
                              >
                                <span>{item.name}</span>
                              </div>
                            </li>
                          );
                        })}
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Color
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="The color of a diamond is the soft tinge of yellow/brown that may be observed inside the diamond. Diamond color is graded by evaluating the diamond's body color face down on a pure white backdrop. All diamonds on the GIA D through Z scale are considered white, albeit the lower end may have a yellow tint."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      {Loading == true ?
                        <DiamondFilterSkeleton />
                        :
                        Color?.map((item, index) => {
                          let selected = selectedColor?.some((tag) => {
                            return tag.id === item.id;
                          });
                          return (
                            <li
                              key={index}
                              className="hand line-h-2 clickli"
                              onClick={() => handleFilterColor(item)}
                              title={item.description}
                            >
                              <div
                                className={
                                  selected ? "col-list all-active" : "col-list"
                                }
                              >
                                <span>{item.name}</span>
                              </div>
                            </li>
                          );
                        })}
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Cut
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="Diamonds are cut to optimize a diamond's sparkle, fire, brilliance, and overall aesthetic appeal. The cut is a measurement of how light performs when it strikes a diamond. Light performance causes the radiance of diamonds; cutting determines quantity of light performance achieved."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      {Loading == true ?
                        <DiamondFilterSkeleton />
                        :
                        Cut?.map((item, index) => {
                          let selected = selectedCut?.some((tag) => {
                            return tag.id === item.id;
                          });
                          return (
                            <li
                              key={index}
                              className="hand line-h-2 clickli"
                              title={item.description}
                              onClick={() => handleFilterCut(item)}
                            >
                              <div
                                className={
                                  selected ? "col-list all-active" : "col-list"
                                }
                              >
                                <span>{item.name}</span>
                              </div>
                            </li>
                          );
                        })}
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10" >
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Price
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <Slider
                      className=""
                      value={[minPrice, maxPrice]}
                      min={fixedMinPrice}
                      max={fixedMaxPrice}
                      onChange={handleChange3}
                    />
                    <div className='grid grid-cols-2 space-x-14 row' style={{ justifyContent: 'space-between' }}>
                      <div>
                        <span className='absolute'>$</span><input
                          className='w-16 ml-2 border relative px-2'
                          type="text"
                          id="min"
                          name="min"
                          value={minPrice}
                          onChange={handleTextChange}
                        />
                      </div>
                      <div style={{}}>
                        <span className='absolute'>$</span><input
                          className='w-16 ml-2 border relative px-2'
                          type="text"
                          id="max"
                          name="max"
                          value={maxPrice}
                          onChange={handleTextChange2}
                        />
                      </div>
                    </div>

                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Carat{" "}
                    </h6>
                    <Slider
                      value={[minCarat, maxCarat]}
                      min={fixedMinCarat}
                      max={fixedMaxCarat}
                      onChange={handleCaratChange}
                    />

                    <div className='grid grid-cols-2 space-x-14 row' style={{ justifyContent: 'space-between' }}>
                      <div>
                        <span className='absolute'></span><input
                          className='w-16 ml-2 border relative px-2'
                          type="text"
                          id="min"
                          name="min"
                          value={minCarat}
                          onChange={handleCaratTextChange}
                        />
                      </div>
                      <div>
                        <span className='absolute'></span><input
                          className='w-16 ml-2 border relative px-2'
                          type="text"
                          id="max"
                          name="max"
                          value={maxCarat}
                          onChange={handleCaratTextChange2}
                        />
                        {/* <InputRange
                      step={0.01}
                      maxValue={maxCarat}
                      minValue={minCarat}
                      value={sliderCarat}
                      onChange={(value) => setSliderCarat(value)}
                    /> */}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="more-option-filter" style={{ display: "none" }}>
                  <div className="row">
                    <div className="col-lg-4 mb-3 mob-sm-mb-20">
                      <div>
                        <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                          Fluorescence
                          <span>
                            <i
                              className="fa fa-angle-right"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </h6>
                        <ul className="ul-left-0 color-list mob-filter-none">
                          {Loading == true ?
                            <DiamondFilterSkeleton />
                            :
                            Fluorescence?.map((item, index) => {
                              let selected = selectedFlour?.some((tag) => {
                                return tag.id === item.id;
                              });
                              return (
                                <li
                                  key={index}
                                  className="hand line-h-2 clickli"
                                  title={item.description}
                                  onClick={() => handleFilterFlour(item)}
                                >
                                  <div
                                    className={
                                      selected
                                        ? "col-list all-active"
                                        : "col-list"
                                    }
                                  >
                                    <span>{item.name}</span>
                                  </div>
                                </li>
                              );
                            })}
                        </ul>
                      </div>
                    </div>
                    <div className="col-lg-4 mb-3 mob-sm-mb-20">
                      <div>
                        <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                          Polish
                          <span>
                            <i
                              className="fa fa-angle-right"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </h6>
                        <ul className="ul-left-0 color-list mob-filter-none">
                          {Loading == true ?
                            <DiamondFilterSkeleton />
                            :
                            Polish?.map((item, index) => {
                              let selected = selectedPolish?.some((tag) => {
                                return tag.id === item.id;
                              });
                              return (
                                <li
                                  key={index}
                                  className="hand line-h-2 clickli"
                                  title={item.description}
                                  onClick={() => handleFilterPolish(item)}
                                >
                                  <div
                                    className={
                                      selected
                                        ? "col-list all-active"
                                        : "col-list"
                                    }
                                  >
                                    <span>{item.name}</span>
                                  </div>
                                </li>
                              );
                            })}
                        </ul>
                      </div>
                    </div>
                    <div className="col-lg-4 mb-3 mob-sm-mb-20">
                      <div>
                        <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                          Symmetry
                          <span>
                            <i
                              className="fa fa-angle-right"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </h6>
                        <ul className="ul-left-0 color-list mob-filter-none">
                          {Loading == true ?
                            <DiamondFilterSkeleton />
                            :
                            Sym?.map((item, index) => {
                              let selected = selectedSym?.some((tag) => {
                                return tag.id === item.id;
                              });
                              return (
                                <li
                                  key={index}
                                  className="hand line-h-2 clickli"
                                  title={item.description}
                                  onClick={() => handleFilterSym(item)}
                                >
                                  <div
                                    className={
                                      selected
                                        ? "col-list all-active"
                                        : "col-list"
                                    }
                                  >
                                    <span>{item.name}</span>
                                  </div>
                                </li>
                              );
                            })}
                        </ul>
                      </div>
                    </div>
                    <div className="col-lg-4 mb-3 mob-sm-mb-10">
                      <div>
                        <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                          Table %{" "}
                        </h6>
                        <div className='w-72 ml-5'>
                          <Slider
                            value={[minTable, maxTable]}
                            min={fixedMinTable}
                            max={fixedMaxTable}
                            onChange={handleTableChange}
                          />
                        </div>
                        <div className='grid grid-cols-2 space-x-14 row' style={{ justifyContent: 'space-between' }}>
                          <div>
                            <span className='absolute'></span>
                            <input
                              className='w-16 ml-2 border relative px-2'
                              type="text"
                              id="min"
                              name="min"
                              value={minTable}
                              onChange={handleTableTextChange}
                            />
                          </div>
                          <div>
                            <span className='absolute'></span><input
                              className='w-16 ml-2 border relative px-2'
                              type="text"
                              id="max"
                              name="max"
                              value={maxTable}
                              onChange={handleTableTextChange2}
                            />
                          </div>
                        </div>
                        {/* <InputRange
                          formatLabel={(value) => `${value}%`}
                          step={0.01}
                          maxValue={maxTable}
                          minValue={minTable}
                          value={sliderTable}
                          onChange={(value) => setSliderTable(value)}
                        /> */}
                      </div>
                    </div>
                    <div className="col-lg-4 mb-3 mob-sm-mb-10">
                      <div>
                        <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                          Depth %{" "}
                          <span>
                            <i
                              className="fa fa-angle-right"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </h6>
                        <Slider
                          value={[minDepth, maxDepth]}
                          min={fixedMinDepth}
                          max={fixedMaxDepth}
                          onChange={handleDepthChange}
                        />
                      </div>
                      <div className='grid grid-cols-2 space-x-14 row' style={{ justifyContent: 'space-between' }}>
                        <div>
                          <span className='absolute'></span><input
                            className='w-16 ml-2 border relative px-2'
                            type="text"
                            id="min"
                            name="min"
                            value={minDepth}
                            onChange={handleDepthTextChange}
                          />
                        </div>
                        <div>
                          <span className='absolute'></span><input
                            className='w-16 ml-2 border relative px-2'
                            type="text"
                            id="max"
                            name="max"
                            value={maxDepth}
                            onChange={handleDepthTextChange2}
                          />
                        </div>
                        {/* <InputRange
                          formatLabel={(value) => `${value}%`}
                          step={0.01}
                          maxValue={maxDepth}
                          minValue={minDepth}
                          value={sliderDepth}
                          onChange={(value) => setSliderDepth(value)}
                        /> */}
                      </div>
                    </div>

                    <div className="col-lg-4 mb-3 mob-sm-mb-10">
                      <div>
                        <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                          Lab
                          <span>
                            <i
                              className="fa fa-angle-right"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </h6>
                        <ul className="ul-left-0 color-list mob-filter-none">
                          {Loading == true ?
                            <DiamondFilterSkeleton />
                            :
                            Lab?.map((item, index) => {
                              let selected = selectedLab?.some((tag) => {
                                return tag.id === item.id;
                              });
                              return (
                                <li
                                  key={index}
                                  className="hand line-h-2 clickli"
                                  title={item.name}
                                  onClick={() => handleFilterLab(item)}
                                >
                                  <div
                                    className={
                                      selected
                                        ? "col-list all-active"
                                        : "col-list"
                                    }
                                  >
                                    <span>{item.name}</span>
                                  </div>
                                </li>
                              );
                            })}
                        </ul>
                      </div>
                    </div>
                    <div className="col-lg-4 mb-3 mob-sm-mb-10">
                      <div>
                        <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                          Diamond Type
                          <span>
                            <i
                              className="fa fa-angle-right"
                              aria-hidden="true"
                            ></i>
                          </span>
                        </h6>
                        <ul className="ul-left-0 color-list mob-filter-none">
                          {DiaType?.map((item, index) => {
                            return (
                              <li
                                key={index}
                                className="hand line-h-2 clickli"
                                title={item.type}
                                onClick={() => setSelectedDiaType(item.type)}
                              >
                                <div
                                  className={
                                    item.type == selectedDiaType
                                      ? "col-list all-active"
                                      : "col-list"
                                  }
                                >
                                  <span>{item.DiaName}</span>
                                </div>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
              <div className="row">
                <div className="col-lg-12 mb-1">
                  <div className="bor-top-filter">

                    <a className="more-filter-btn advance-btn hand mar-bot-20 show-adv-option">
                      <span className="showadvtxt" style={{ display: 'none', lineHeight: 1, fontFamily: 'Jost Medium' }}>Hide Filters Options &nbsp;</span>
                      <span className="hideadvtxt" style={{ lineHeight: 1, fontFamily: 'Jost Medium' }}>Show Filters Options &nbsp;</span>
                      <i className="fa fa-chevron-down downcl" aria-hidden="true" style={{ fontSize: 12 }}></i>
                      <i className="fa fa-chevron-up upcl" aria-hidden="true" style={{ display: 'none', fontSize: 12 }}></i>
                    </a>
                  </div>
                </div>
              </div>

            </div>
          </div>


        </div>
        <div
          style={{
            // display: "flex",
            justifyContent: "flex-end",
            // paddingRight:135
          }}
        >
          <div className="row" style={{
            // paddingRight: 20,
          }}>
            <div className="col-lg-6 mb-1" >
              <div className="bor-top-filter">

                <a className="more-filter-btn advance-btn hand mar-bot-20 show-all-adv-option">
                  <span className="showalladvtxt" style={{ lineHeight: 1, fontFamily: 'Jost Medium' }}>Hide Filters &nbsp;</span>
                  <span className="hidealladvtxt" style={{ display: 'none', lineHeight: 1, fontFamily: 'Jost Medium' }}>Show Filters &nbsp;</span>
                  <i className="fa fa-chevron-down downclall" aria-hidden="true" style={{ display: 'none', fontSize: 12 }}></i>
                  <i className="fa fa-chevron-up upclall" aria-hidden="true" style={{ fontSize: 12 }}></i>
                </a>
              </div>
            </div>
            <div className="col-lg-6 mb-1">
              <div className="bor-top-filter">

                <a className="more-reset-filter-btn advance-btn hand mar-bot-20 " onClick={() => ResetFilters()}>
                  <span className="" style={{ lineHeight: 1, textAlign: 'center', fontFamily: 'Jost Medium' }}>Reset Filters &nbsp;</span>
                  <i className="fa fa-reply" aria-hidden="true" style={{ fontSize: 12 }}></i>
                </a>
              </div>
            </div>
          </div>

        </div>
        <div className="main-div" id="labgrown-id" style={{ display: "none" }}>
          <div className="set-filter-div set-filter-click">
            <h6>
              Set Filters <span className="s1">+</span>
              <span className="s2">−</span>
            </h6>
          </div>

          <div className="container container-main hide-all-setfilter">
            <div className="more-option-filter">
              <div className="row">
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Shape
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="Choose a diamond to complement the jewellery you wish to create. Our extensive selection of gems feature ten different shapes as well as a range of carat sizes to suit every preference."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Round"
                      >
                        <div className="shapes">
                          <img src={round} width="27" />
                        </div>
                        <p className="mb-0">Round</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Asscher"
                      >
                        <div className="shapes">
                          <span>
                            <img src={asscher} width="27" />
                          </span>
                        </div>
                        <p>Asscher</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Cushion"
                      >
                        <div className="shapes">
                          <span>
                            <img src={cushion} width="27" />
                          </span>
                        </div>
                        <p>Cushion</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Emerald"
                      >
                        <div className="shapes">
                          <span>
                            <img src={emerald} width="27" />
                          </span>
                        </div>
                        <p>Emerald</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Heart"
                      >
                        <div className="shapes">
                          <span>
                            <img src={heart} width="27" />
                          </span>
                        </div>
                        <p>Heart</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Marquise"
                      >
                        <div className="shapes">
                          <span>
                            <img src={marquise} width="27" />
                          </span>
                        </div>
                        <p>Marquise</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Oval"
                      >
                        <div className="shapes">
                          <span>
                            <img src={oval} width="27" />
                          </span>
                        </div>
                        <p>Oval</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Pear"
                      >
                        <div className="shapes">
                          <span>
                            <img src={pear} width="27" />
                          </span>
                        </div>
                        <p>Pear</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Princess"
                      >
                        <div className="shapes">
                          <span>
                            <img src={princess} width="27" />
                          </span>
                        </div>
                        <p>Princess</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Radiant"
                      >
                        <div className="shapes">
                          <span>
                            <img src={radiant} width="27" />
                          </span>
                        </div>
                        <p>Radiant</p>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Clarity
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="Inclusions are birthmarks that give each diamond its own personality and add up to form the diamond's clarity. Gemologists rate the clarity of gemstones on a scale of FL to I3, with FL being the highest level of clarity. The clarity of diamonds is determined by the microscopic imperfections or flaws in the diamond throughout the growing process."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      {/* {Clarity.map((item,index)=>{
                        return(
                          <li className="hand line-h-2 clickli" title={item.ClarityName}>
                          <div className="col-list">
                            <span>{item.ClarityName}</span>
                          </div>
                        </li>
                        )
                      })} */}
                      <li className="hand line-h-2 clickli" title="IF">
                        <div className="col-list">
                          <span>IF</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VVS1">
                        <div className="col-list">
                          <span>VVS1</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VVS2">
                        <div className="col-list">
                          <span>VVS2</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VS1">
                        <div className="col-list">
                          <span>VS1</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VS2">
                        <div className="col-list">
                          <span>VS2</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="SI1">
                        <div className="col-list">
                          <span>SI1</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="SI2">
                        <div className="col-list">
                          <span>SI2</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="SI3">
                        <div className="col-list">
                          <span>SI3</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="I1">
                        <div className="col-list">
                          <span>I1</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="I2">
                        <div className="col-list">
                          <span>I2</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="I3">
                        <div className="col-list">
                          <span>I3</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Color
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="The color of a diamond is the soft tinge of yellow/brown that may be observed inside the diamond. Diamond color is graded by evaluating the diamond's body color face down on a pure white backdrop. All diamonds on the GIA D through Z scale are considered white, albeit the lower end may have a yellow tint."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="D">
                        <div className="col-list">
                          <span>D</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="E">
                        <div className="col-list">
                          <span>E</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="F">
                        <div className="col-list">
                          <span>F</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="G">
                        <div className="col-list">
                          <span>G</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="H">
                        <div className="col-list">
                          <span>H</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="I">
                        <div className="col-list">
                          <span>I</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="J">
                        <div className="col-list">
                          <span>J</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="K">
                        <div className="col-list">
                          <span>K</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="L">
                        <div className="col-list">
                          <span>L</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="M">
                        <div className="col-list">
                          <span>M</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Cut
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="Diamonds are cut to optimize a diamond's sparkle, fire, brilliance, and overall aesthetic appeal. The cut is a measurement of how light performs when it strikes a diamond. Light performance causes the radiance of diamonds; cutting determines quantity of light performance achieved."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="EX">
                        <div className="col-list">
                          <span>EX</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VG">
                        <div className="col-list">
                          <span>VG</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="GD">
                        <div className="col-list">
                          <span>GD</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="ID">
                        <div className="col-list">
                          <span>ID</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="FR">
                        <div className="col-list">
                          <span>FR</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                {/* <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Price
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 mob-filter-none">
                      <div>
                        <div className="slider-price PipsSlider mycl hand"></div>
                      </div>
                      <div>
                        <ul
                          className="PipsSlider mycl mar-lf-10 ul-0 ul-1-start"
                          style={{ display: "flow-root" }}
                        >
                          <li className="min-price-li">
                            <input
                              className="price_start Bottom text-center price-textbox"
                              type="text"
                              defaultValue="$800"
                            />
                          </li>
                          <li className="max-price-li">
                            <input
                              className="price_end Bottom text-center price-textbox"
                              type="text"
                              defaultValue="$2500"
                            />
                          </li>
                        </ul>
                      </div>
                    </ul>
                  </div>
                </div> */}
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Carat
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="Diamond carat is its weight and reflects the diamond's size. Carat is the most visible C. Not to confused with karat (a measure of gold purity), a 1.00 carat or ct diamond weighs 0.20 grams. The larger the diamond, the more valuable it becomes."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="block-grid-price ul-10 ul-1-start mob-filter-none">
                      <div>
                        <div className="slider-carat PipsSlider mycl hand"></div>
                      </div>
                      <div>
                        <ul
                          className="PipsSlider mycl mar-lf-10 ul-0 ul-1-start"
                          style={{ display: "flow-root" }}
                        >
                          <li className="min-price-li">
                            <input
                              className="carat_start Bottom text-center price-textbox"
                              type="text"
                              defaultValue="8"
                            />
                          </li>
                          <li className="max-price-li">
                            <input
                              className="carat_end Bottom text-center price-textbox"
                              type="text"
                              defaultValue="15"
                            />
                          </li>
                        </ul>
                      </div>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Fluorescence
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="None">
                        <div className="col-list">
                          <span>None</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Faint">
                        <div className="col-list">
                          <span>Faint</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Slight">
                        <div className="col-list">
                          <span>Slight</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Medium">
                        <div className="col-list">
                          <span>Medium</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Strong">
                        <div className="col-list">
                          <span>Strong</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Polish
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="EX">
                        <div className="col-list">
                          <span>EX</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VG">
                        <div className="col-list">
                          <span>VG</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="GD">
                        <div className="col-list">
                          <span>GD</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Fair">
                        <div className="col-list">
                          <span>Fair</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Poor">
                        <div className="col-list">
                          <span>Poor</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Symmetry
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="EX">
                        <div className="col-list">
                          <span>EX</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VG">
                        <div className="col-list">
                          <span>VG</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="GD">
                        <div className="col-list">
                          <span>GD</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Fair">
                        <div className="col-list">
                          <span>Fair</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Poor">
                        <div className="col-list">
                          <span>Poor</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Table %
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="block-grid-price ul-10 ul-1-start mob-filter-none">
                      <div>
                        <div className="slider-table PipsSlider mycl hand"></div>
                      </div>
                      <div>
                        <ul
                          className="PipsSlider mycl mar-lf-10 ul-0 ul-1-start"
                          style={{ display: "flow-root" }}
                        >
                          <li className="min-price-li">
                            <input
                              className="table_start Bottom text-center price-textbox"
                              type="text"
                              defaultValue="8%"
                            />
                          </li>
                          <li className="max-price-li">
                            <input
                              className="table_end Bottom text-center price-textbox"
                              type="text"
                              defaultValue="15%"
                            />
                          </li>
                        </ul>
                      </div>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Depth %
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="block-grid-price ul-10 ul-1-start mob-filter-none">
                      <div>
                        <div className="slider-depth PipsSlider mycl hand"></div>
                      </div>
                      <div>
                        <ul
                          className="PipsSlider mycl mar-lf-10 ul-0 ul-1-start"
                          style={{ display: "flow-root" }}
                        >
                          <li className="min-price-li">
                            <input
                              className="depth_start Bottom text-center price-textbox"
                              type="text"
                              defaultValue="5%"
                            />
                          </li>
                          <li className="max-price-li">
                            <input
                              className="depth_end Bottom text-center price-textbox"
                              type="text"
                              defaultValue="18%"
                            />
                          </li>
                        </ul>
                      </div>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Lab
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="EX">
                        <div className="col-list">
                          <span>IGI</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VG">
                        <div className="col-list">
                          <span>GIA</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="GD">
                        <div className="col-list">
                          <span>AGL</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-12 mb-1">
                <div className="bor-top-filter">

                  <a className="more-filter-btn advance-btn hand mar-bot-20 show-adv-option">
                    <span className="showadvtxt" style={{ display: 'none', lineHeight: 1 }}>Hide Filters Options &nbsp;</span>
                    <span className="hideadvtxt" style={{ fontSize: 12 }}>Show Filters Options &nbsp;</span>
                    <i className="fa fa-chevron-down downcl" aria-hidden="true" style={{ fontSize: 12 }}></i>
                    <i className="fa fa-chevron-up upcl" aria-hidden="true" style={{ display: 'none', fontSize: 12 }}></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="main-div" id="colors-id" style={{ display: "none" }}>
          <div className="set-filter-div set-filter-click">
            <h6>
              Set Filters <span className="s1">+</span>
              <span className="s2">−</span>
            </h6>
          </div>

          <div className="container container-main hide-all-setfilter">
            <div className="more-option-filter">
              <div className="row">
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Color
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="The color of a diamond is the soft tinge of yellow/brown that may be observed inside the diamond. Diamond color is graded by evaluating the diamond's body color face down on a pure white backdrop. All diamonds on the GIA D through Z scale are considered white, albeit the lower end may have a yellow tint."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Yellow"
                      >
                        <div className="shapes">
                          <img
                            src={Yellowdiamond}
                            width="27"
                            className="img-filter"
                          />
                        </div>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Orange"
                      >
                        <div className="shapes">
                          <span>
                            <img
                              src={Orangediamond}
                              width="27"
                              className="img-filter"
                            />
                          </span>
                        </div>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Green"
                      >
                        <div className="shapes">
                          <span>
                            <img
                              src={Greendiamond}
                              width="27"
                              className="img-filter"
                            />
                          </span>
                        </div>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Blue"
                      >
                        <div className="shapes">
                          <span>
                            <img
                              src={Bluediamond}
                              width="27"
                              className="img-filter"
                            />
                          </span>
                        </div>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Violet"
                      >
                        <div className="shapes">
                          <span>
                            <img
                              src={Violetdiamond}
                              width="27"
                              className="img-filter"
                            />
                          </span>
                        </div>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Pink"
                      >
                        <div className="shapes">
                          <span>
                            <img
                              src={Pinkdiamond}
                              width="27"
                              className="img-filter"
                            />
                          </span>
                        </div>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Purple"
                      >
                        <div className="shapes">
                          <span>
                            <img
                              src={Purplediamond}
                              width="27"
                              className="img-filter"
                            />
                          </span>
                        </div>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Red"
                      >
                        <div className="shapes">
                          <span>
                            <img
                              src={Reddiamond}
                              width="27"
                              className="img-filter"
                            />
                          </span>
                        </div>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Gray"
                      >
                        <div className="shapes">
                          <span>
                            <img
                              src={Graydiamond}
                              width="27"
                              className="img-filter"
                            />
                          </span>
                        </div>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Black"
                      >
                        <div className="shapes">
                          <span>
                            <img
                              src={Blackdiamond}
                              width="27"
                              className="img-filter"
                            />
                          </span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Shape
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="Choose a diamond to complement the jewellery you wish to create. Our extensive selection of gems feature ten different shapes as well as a range of carat sizes to suit every preference."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Round"
                      >
                        <div className="shapes">
                          <img src={round} width="27" />
                        </div>
                        <p className="mb-0">Round</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Asscher"
                      >
                        <div className="shapes">
                          <span>
                            <img src={asscher} width="27" />
                          </span>
                        </div>
                        <p>Asscher</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Cushion"
                      >
                        <div className="shapes">
                          <span>
                            <img src={cushion} width="27" />
                          </span>
                        </div>
                        <p>Cushion</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Emerald"
                      >
                        <div className="shapes">
                          <span>
                            <img src={emerald} width="27" />
                          </span>
                        </div>
                        <p>Emerald</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Heart"
                      >
                        <div className="shapes">
                          <span>
                            <img src={heart} width="27" />
                          </span>
                        </div>
                        <p>Heart</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Marquise"
                      >
                        <div className="shapes">
                          <span>
                            <img src={marquise} width="27" />
                          </span>
                        </div>
                        <p>Marquise</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Oval"
                      >
                        <div className="shapes">
                          <span>
                            <img src={oval} width="27" />
                          </span>
                        </div>
                        <p>Oval</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Pear"
                      >
                        <div className="shapes">
                          <span>
                            <img src={pear} width="27" />
                          </span>
                        </div>
                        <p>Pear</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Princess"
                      >
                        <div className="shapes">
                          <span>
                            <img src={princess} width="27" />
                          </span>
                        </div>
                        <p>Princess</p>
                      </li>
                      <li
                        className="hand line-h-2 clickli-shape"
                        data-toggle="tooltip"
                        title="Radiant"
                      >
                        <div className="shapes">
                          <span>
                            <img src={radiant} width="27" />
                          </span>
                        </div>
                        <p>Radiant</p>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Clarity
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="Inclusions are birthmarks that give each diamond its own personality and add up to form the diamond's clarity. Gemologists rate the clarity of gemstones on a scale of FL to I3, with FL being the highest level of clarity. The clarity of diamonds is determined by the microscopic imperfections or flaws in the diamond throughout the growing process."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="IF">
                        <div className="col-list">
                          <span>IF</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VVS1">
                        <div className="col-list">
                          <span>VVS1</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VVS2">
                        <div className="col-list">
                          <span>VVS2</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VS1">
                        <div className="col-list">
                          <span>VS1</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VS2">
                        <div className="col-list">
                          <span>VS2</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="SI1">
                        <div className="col-list">
                          <span>SI1</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="SI2">
                        <div className="col-list">
                          <span>SI2</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="SI3">
                        <div className="col-list">
                          <span>SI3</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="I1">
                        <div className="col-list">
                          <span>I1</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="I2">
                        <div className="col-list">
                          <span>I2</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="I3">
                        <div className="col-list">
                          <span>I3</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Cut
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="Diamonds are cut to optimize a diamond's sparkle, fire, brilliance, and overall aesthetic appeal. The cut is a measurement of how light performs when it strikes a diamond. Light performance causes the radiance of diamonds; cutting determines quantity of light performance achieved."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="EX">
                        <div className="col-list">
                          <span>EX</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VG">
                        <div className="col-list">
                          <span>VG</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="GD">
                        <div className="col-list">
                          <span>GD</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="ID">
                        <div className="col-list">
                          <span>ID</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="FR">
                        <div className="col-list">
                          <span>FR</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                {/* <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Price
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 mob-filter-none">
                      <div>
                        <div className="slider-price PipsSlider mycl hand"></div>
                      </div>
                      <div>
                        <ul
                          className="PipsSlider mycl mar-lf-10 ul-0 ul-1-start"
                          style={{ display: "flow-root" }}
                        >
                          <li className="min-price-li">
                            <input
                              className="price_start Bottom text-center price-textbox"
                              type="text"
                              defaultValue="$800"
                            />
                          </li>
                          <li className="max-price-li">
                            <input
                              className="price_end Bottom text-center price-textbox"
                              type="text"
                              defaultValue="$2500"
                            />
                          </li>
                        </ul>
                      </div>
                    </ul>
                  </div>
                </div> */}
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Carat
                      <span
                        className="question"
                        data-toggle="tooltip"
                        title="Diamond carat is its weight and reflects the diamond's size. Carat is the most visible C. Not to confused with karat (a measure of gold purity), a 1.00 carat or ct diamond weighs 0.20 grams. The larger the diamond, the more valuable it becomes."
                      >
                        <i className="fa fa-info-circle" aria-hidden="true"></i>
                      </span>
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="block-grid-price ul-10 ul-1-start mob-filter-none">
                      <div>
                        <div className="slider-carat PipsSlider mycl hand"></div>
                      </div>
                      <div>
                        <ul
                          className="PipsSlider mycl mar-lf-10 ul-0 ul-1-start"
                          style={{ display: "flow-root" }}
                        >
                          <li className="min-price-li">
                            <input
                              className="carat_start Bottom text-center price-textbox"
                              type="text"
                              defaultValue="8"
                            // value={minCarat}
                            // onChange={()=>setMinCarat()}
                            />
                          </li>
                          <li className="max-price-li">
                            <input
                              className="carat_end Bottom text-center price-textbox"
                              type="text"
                              defaultValue="15"
                            // value={maxCarat}
                            />
                          </li>
                        </ul>
                      </div>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Fluorescence
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="None">
                        <div className="col-list">
                          <span>None</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Faint">
                        <div className="col-list">
                          <span>Faint</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Slight">
                        <div className="col-list">
                          <span>Slight</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Medium">
                        <div className="col-list">
                          <span>Medium</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Strong">
                        <div className="col-list">
                          <span>Strong</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Polish
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="EX">
                        <div className="col-list">
                          <span>EX</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VG">
                        <div className="col-list">
                          <span>VG</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="GD">
                        <div className="col-list">
                          <span>GD</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Fair">
                        <div className="col-list">
                          <span>Fair</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Poor">
                        <div className="col-list">
                          <span>Poor</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Symmetry
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="EX">
                        <div className="col-list">
                          <span>EX</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VG">
                        <div className="col-list">
                          <span>VG</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="GD">
                        <div className="col-list">
                          <span>GD</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Fair">
                        <div className="col-list">
                          <span>Fair</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="Poor">
                        <div className="col-list">
                          <span>Poor</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Table %
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="block-grid-price ul-10 ul-1-start mob-filter-none">
                      <div>
                        <div className="slider-table PipsSlider mycl hand"></div>
                      </div>
                      <div>
                        <ul
                          className="PipsSlider mycl mar-lf-10 ul-0 ul-1-start"
                          style={{ display: "flow-root" }}
                        >
                          <li className="min-price-li">
                            <input
                              className="table_start Bottom text-center price-textbox"
                              type="text"
                              defaultValue="8%"
                            />
                          </li>
                          <li className="max-price-li">
                            <input
                              className="table_end Bottom text-center price-textbox"
                              type="text"
                              defaultValue="15%"
                            />
                          </li>
                        </ul>
                      </div>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Depth %
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="block-grid-price ul-10 ul-1-start mob-filter-none">
                      <div>
                        <div className="slider-depth PipsSlider mycl hand"></div>
                      </div>
                      <div>
                        <ul
                          className="PipsSlider mycl mar-lf-10 ul-0 ul-1-start"
                          style={{ display: "flow-root" }}
                        >
                          <li className="min-price-li">
                            <input
                              className="depth_start Bottom text-center price-textbox"
                              type="text"
                              defaultValue="5%"
                            />
                          </li>
                          <li className="max-price-li">
                            <input
                              className="depth_end Bottom text-center price-textbox"
                              type="text"
                              defaultValue="18%"
                            />
                          </li>
                        </ul>
                      </div>
                    </ul>
                  </div>
                </div>
                <div className="col-lg-4 mb-3 mob-sm-mb-10">
                  <div>
                    <h6 className="mb-2 mobile-diamond-title title-upper diamond-click-toggle">
                      Lab
                      <span>
                        <i className="fa fa-angle-right" aria-hidden="true"></i>
                      </span>
                    </h6>
                    <ul className="ul-left-0 color-list mob-filter-none">
                      <li className="hand line-h-2 clickli" title="EX">
                        <div className="col-list">
                          <span>IGI</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="VG">
                        <div className="col-list">
                          <span>GIA</span>
                        </div>
                      </li>
                      <li className="hand line-h-2 clickli" title="GD">
                        <div className="col-list">
                          <span>AGL</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-12 mb-1">
                <div className="bor-top-filter">

                  <a className="more-filter-btn advance-btn hand mar-bot-20 show-adv-option" >
                    <span className="showadvtxt" style={{ display: 'none', lineHeight: 1 }}>Hide Filters Options &nbsp;</span>
                    <span className="hideadvtxt" style={{ fontSize: 12 }}>Show Filters Options &nbsp;</span>
                    <i className="fa fa-chevron-down downcl" aria-hidden="true" style={{ fontSize: 12 }}></i>
                    <i className="fa fa-chevron-up upcl" aria-hidden="true" style={{ display: 'none', fontSize: 12 }}></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <div className="container container-main">
        <div
          style={{
            backgroundColor: "#efefef",
            padding: 15,
            marginBottom: 10,
          }}
        >
          <div className="searchflex-div">
            <div>
              <h6 style={{ fontWeight: 600, marginBottom: 0, fontSize: 14 }}>SEARCH RESULT ({filterCount})</h6>
            </div>
            <div className="thumb-flex-div first-afilter">
              <a className="table-list-click hand ataglist-thumb ataglist-thumb-active" data-toggle="tooltip" title="List View">
                <i className="fa fa-list" aria-hidden="true"></i>
              </a>
              <a className="thumblist-list-click hand ataglist-thumb" data-toggle="tooltip" title="Grid View">
                <i className="fa fa-th" aria-hidden="true"></i>
              </a>

            </div>
          </div>

        </div>
      </div>
      <>
        <div className="container container-main dia-list-divbg mb-5 table-view-data" style={{ backgroundColor: 'white' }}>
          <div className="row">
            <div className="col-lg-12" style={{ backgroundColor: 'white' }}>
              <div className="table-responsive details-table mar-bot-25px search-result-tbl-main">
                {isLoading ?
                  // <p style={{ textAlign: "center" }}>Processing...</p>
                  <DiamondListSkeleton />

                  : List?.length == 0 ?
                    <div
                      style={{ display: "grid", justifyContent: "center", flex: 1, backgroundColor: '#f1ecf0' }}
                    >
                      <img
                        src={logo}
                        alt="loading..."
                        style={{ width: 150, height: 150 }}
                      />
                      <h4>No data Found</h4>
                    </div>
                    :
                    <table
                      id="dia-table"
                      className="table table-striped1"
                      style={{ width: "100%" }}
                    >
                      <thead className="font-auto tbl-header">
                        <tr className="trth-center th-r-bor">
                          <th>SHAPE</th>
                          <th style={{ cursor: 'pointer' }} scope="col"><a name='carat' onClick={(e) => HandleSorting(e)} class="sort-by">CARAT</a></th>
                          <th style={{ cursor: 'pointer' }} scope="col"><a name='ColorName' onClick={(e) => HandleSorting(e)} class="sort-by">COLOR</a></th>
                          <th style={{ cursor: 'pointer' }} scope="col"><a name='ClarityName' onClick={(e) => HandleSorting(e)} class="sort-by">CLARITY</a></th>
                          <th style={{ cursor: 'pointer' }} scope="col"><a name='CutName' onClick={(e) => HandleSorting(e)} class="sort-by">CUT</a></th>
                          <th>LAB
                            {/* <div>
                              <button>▲</button>
                              <button>▼</button>
                            </div>LAB */}
                          </th>
                          <th>CERTICATE NO.</th>
                          <th>MEASUREMENT</th>
                          <th style={{ cursor: 'pointer' }} scope="col"><a name='amount' onClick={(e) => HandleSorting(e)} class="sort-by">PRICE</a></th>


                          <th>VIEW</th>
                        </tr>
                      </thead>
                      {List?.map((item, index) => {
                        return (
                          <tbody className="tr-unhov-hand table-striped1-odd">
                            <tr
                              key={index}
                              className="tr-hover trtd-center trtd-13 tr-hov-td add-row rm-row roted-180"
                            >
                              <td>{item.ShapeName}</td>
                              <td>{item.carat.toFixed(2)}</td>
                              <td>{item.ColorName}</td>
                              <td>{item.ClarityName}</td>
                              <td>{item.CutName}</td>
                              <td>{item.LabName}</td>
                              <td> <a href={item.cert_location}>{item.cert_no}</a></td>
                              <td>{item.measurement}</td>
                              <td>${item.amount}</td>
                              {prodSelected == true &&
                                prodSelectedIndex == index ? (
                                <td>
                                  <a
                                    className="table-atag toggle-tr add-row"
                                    onClick={() => openDetail(index)}
                                  >
                                    <i className="fa fa-chevron-up  hand"></i>
                                  </a>
                                </td>
                              ) : (
                                <td>
                                  <a
                                    className="table-atag toggle-tr add-row"
                                    onClick={() => openDetail(index)}
                                  >
                                    <i className="fa fa-chevron-down  hand"></i>
                                  </a>
                                </td>
                              )}
                            </tr>
                            {prodSelected == true && prodSelectedIndex == index && (
                              <tr
                                className="row-detail bg-diamond-details"
                                style={{ backgroundColor: "#fff" }}
                              >

                                <td colSpan="12">
                                  {/* <Link
                                    aria-current="page"                                  
                                    to={process.env.PUBLIC_URL +`/DiamondDetails/${utf8_to_b64(item?.id)}/${item?.carat}-Carat-${item?.ShapeName} Diamond, ${item?.ColorName}-${item?.ClarityName}}`}
                                  > */}
                                  <div
                                    className="text-left"
                                    style={{ padding: "15px" }}
                                  >
                                    <div className="row m-0">
                                      <div className="col-lg-5">
                                        {item.video == null || item.video == '' ?
                                          <a href='https://media.giphy.com/media/cccpTlG85cCdEtyybs/giphy.mp4'>
                                            <iframe
                                              className="DVideoFrame" allow="autoplay"
                                              style={{
                                                width: "100%",
                                                minHeight: "300px",
                                              }}
                                              src='https://media.giphy.com/media/cccpTlG85cCdEtyybs/giphy.mp4'
                                            ></iframe>
                                          </a>
                                          :
                                          <a href={item.video}>
                                            <iframe
                                              className="DVideoFrame"
                                              allow="autoplay"
                                              style={{
                                                width: "100%",
                                                minHeight: "300px",
                                              }}
                                              src={item.video}
                                            ></iframe>
                                          </a>
                                        }
                                      </div>
                                      <div className="col-lg-7 order-lg-1">
                                        <div className="row">
                                          <div className="col-lg-8">
                                            <h5>
                                              {item.carat} Carat {item.ShapeName}{" "}
                                              {item.diamond_type} Diamond
                                            </h5>
                                            <ul className="ulli-list-li">
                                              <li>Sku: {item.loatno}</li>
                                              <li>Shape: {item.ShapeName}</li>
                                              <li>Color: {item.ColorName}</li>
                                              <li>Clarity: {item.ClarityName}</li>
                                              <li>
                                                Certifying Lab: {item.LabName}
                                              </li>
                                              <li>Cut: {item.CutName}</li>
                                              <li>Polish: {item.PolishName}</li>
                                              <li>Symmetry: {item.SymName}</li>
                                              <li>Fluor: {item.FlourName}</li>
                                              <li>
                                                Measurement: {item.measurement}
                                              </li>
                                              <li>
                                                Tabel Area(%): {item.tablearea}
                                              </li>
                                              <li>
                                                Table Depth(%): {item.tabledepth}
                                              </li>
                                            </ul>
                                            <div
                                              className="pt-4"
                                              style={{ clear: "both" }}
                                              onClick={() => { Category.categoryName != "All" && AddStorageData(item) }}>
                                              <Link
                                                className="view-diamond-btn"
                                                aria-current="page"
                                                style={{
                                                  backgroundColor: Colors.peach,
                                                  padding: "5px 15px",
                                                  color: "black",
                                                  fontSize: "14px",
                                                }}

                                                to={`/DiamondDetails/${utf8_to_b64(item?.id)}/${item?.carat}-Carat-${item?.ShapeName} Diamond, ${item?.ColorName}-${item?.ClarityName}}`}
                                              >View Details

                                              </Link>
                                              {/* <a
                                              className="view-diamond-btn"
                                              href="/DiamondDetails"
                                              style={{
                                                backgroundColor: Colors.peach,
                                                padding: "5px 15px",
                                                color: "black",
                                                fontSize: "14px",
                                              }}
                                            >
                                              View Details
                                            </a> */}
                                            </div>
                                          </div>
                                          <div className="col-lg-4">
                                            <a href={item.cert_location} target="_blank">
                                              <div className="igipdf-div">
                                                <img
                                                  className="css-8atqhb"
                                                  src={
                                                    item.image == null
                                                      ? igi_cert
                                                      : item.image
                                                  }
                                                  alt="Diamond Foundry Certificate"
                                                  width="100%"
                                                />
                                                <div
                                                  className="igi-link"
                                                  color="#000000"
                                                  style={{
                                                    cursor: 'pointer',
                                                    position: 'absolute',
                                                    width: '1.6rem',
                                                    height: '1.6rem',
                                                    left: '100px',
                                                  }}
                                                >
                                                  <svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    height="15"
                                                    viewBox="0 0 12 11"
                                                    width="15"
                                                    role="img"
                                                  >
                                                    <title>
                                                      arrow-new-window
                                                    </title>
                                                    <path
                                                      d="m10.8391647.00024955c-.0237858.00070418-.0475108.00265368-.0710642.00583936h-3.10812503c-.23020519-.00304973-.44433052.11024764-.5603832.29650834-.11605269.18626069-.11605269.41662732 0 .60288801.11605268.18626069.33017801.29955806.5603832.29650833h1.65068514l-5.93199301 5.55675254c-.16675628.14997678-.23392949.37268354-.17561329.58223009.0583162.20954656.23300929.37318903.45670627.42781626s.46144282-.00829686.62154729-.16450467l5.93199273-5.55675224v1.54626737c-.0032556.21564309.1176925.41622348.3165312.52493502.1988386.10871154.4447616.10871154.6436002 0 .1988387-.10871154.3197869-.30929193.3165312-.52493502v-2.91384978c.0257311-.17425026-.0317435-.35027464-.1571283-.48122829-.1253847-.13095365-.3059601-.20355224-.4936702-.19847532zm-9.56250212.00577931c-.69773619 0-1.27666258.54236527-1.27666258 1.19596473v8.37133273c0 .65359958.57892639 1.19590468 1.27666258 1.19590468h8.93663802c.6977363 0 1.2767267-.5423051 1.2767267-1.19590468v-3.58771402c.0031916-.21564309-.1177566-.41622348-.3165953-.52493502-.1988386-.10871154-.4447616-.10871154-.6436002 0-.1988387.10871154-.3197868.30929193-.3165312.52493502v3.58771402h-8.93663802v-8.37133273h3.82998773c.23020519.00304973.44433052-.11024764.5603832-.29650833.11605269-.18626069.11605269-.41662732 0-.60288801-.11605268-.1862607-.33017801-.29955807-.5603832-.29656839z"
                                                      transform="translate(.252263)"
                                                    ></path>
                                                  </svg>
                                                </div>
                                              </div>
                                            </a>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  {/* </Link> */}
                                </td>

                              </tr>
                            )}
                          </tbody>
                        );
                      })}
                    </table>
                }
              </div>
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: 'flex-end', alignItems: 'center', paddingTop: 30 }}>
            <Pagination
              color='primary'
              count={count}
              size="large"
              page={Currentpage}
              variant="outlined"
              shape="rounded"
              onChange={handleChange}
            />
          </div>


        </div>

        <div className="thumblist-view-data mb-5">
          <div className="container container-main ">
            <div className="product-page-div">
              {isLoading ?
                // <p style={{ textAlign: "center" }}>Processing...</p>
                <DiamondGridSkeleton />
                : List?.length == 0 ?
                  <div
                    style={{ display: "grid", justifyContent: "center", flex: 1, backgroundColor: '#f1ecf0' }}
                  >
                    <img
                      src={logo}
                      alt="loading..."
                      style={{ width: 150, height: 150 }}
                    />
                    <h4>No data Found</h4>
                  </div>
                  :
                  List?.map((item, index) => {
                    return (
                      <div className="product-div find-img">
                        <div className="product-div-div">
                          <div className="product-div-box">
                            <div className="product-div-list">
                              <img
                                src={item.image == null ? noimage : item.image}
                                className="inner-img-product"
                              />
                            </div>
                            <div className="text-center show-viewbtn">
                              <h5 className="product-title pt-3 line1-doted-3">
                                {item.carat} Carat {item.ShapeName}{" "}
                                {item.diamond_type} Diamond {" "}
                                <br />
                                Certificate no: {item.cert_no}
                              </h5>
                              <p className="product-title-price mb-0">
                                ${item.amount}
                              </p>
                              <div className="pt-3 hide-view-btn"
                                onClick={() => AddStorageData(item)}>
                                <Link
                                  className="view-diamond-btn"
                                  aria-current="page"
                                  style={{
                                    backgroundColor: Colors.peach,
                                    padding: "5px 15px",
                                    color: "black",
                                    fontSize: "14px",
                                  }}

                                  to={`/DiamondDetails/${utf8_to_b64(item?.id)}/${item?.carat}-Carat-${item?.ShapeName} Diamond, ${item?.ColorName}-${item?.ClarityName}}`}
                                // state={{ diamondId: item.id }}
                                >

                                  <span className="span-link">View Details</span>
                                  <span>
                                    &nbsp;
                                    <svg
                                      width="8"
                                      height="11"
                                      viewBox="0 0 8 11"
                                      fill="none"
                                      xmlns="http://www.w3.org/2000/svg"
                                    >
                                      <path
                                        d="M1 10L6 5.5L1 1"
                                        stroke="#23282D"
                                        strokeWidth="1.5"
                                        strokeLinecap="round"
                                      />
                                    </svg>
                                  </span>
                                </Link>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}

            </div>
            <div style={{ display: "flex", justifyContent: 'flex-end', alignItems: 'center', paddingTop: 30 }}>
              <Pagination
                color='primary'
                count={count}
                size="large"
                page={Currentpage}
                variant="outlined"
                shape="rounded"
                onChange={handleChange}
              />
            </div>

          </div>
        </div>
      </>


    </>
  );
};

export default DiamondList;
