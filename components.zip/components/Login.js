
import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { loginUser } from '../reducers/userReducers'

import Backdrop from '@material-ui/core/Backdrop'
import CircularProgress from '@material-ui/core/CircularProgress'
import { makeStyles } from '@material-ui/core/styles'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import { Colors } from '../constant/Constant'
import Cookies from 'universal-cookie';
import { AiOutlineBorder, AiOutlineCheckSquare } from "react-icons/ai";
import { BASE_URL, GetAPIUrl } from '../API/APIUrl'
import axios from 'axios'
import { ShowErrorMessage, ShowMessage } from '../module/Tostify'

const useStyles = makeStyles((theme) => ({
    backdrop: {
        zIndex: theme.zIndex.drawer + 1,
        color: '#fff',
    },
}));


const Login = ({ authorized }) => {
    const cookies = new Cookies();


    const location = useLocation();

    const Loginid = new URLSearchParams(location.search).get("Loginid");

    // console.log("email", cookies.get('email'));
    // console.log("password", cookies.get('password'));

    const classes = useStyles()
    const [email, setEmail] = useState(cookies.get('email') == undefined ? '' : cookies.get('email'))

    const [password, setPassword] = useState(cookies.get('password') == undefined ? '' : cookies.get('password'))
    const [Remember, setRemember] = useState(cookies.get('email') == undefined ? false : true)
    const [showPassShow, setShowPassShow] = useState(false)

    const dispatch = useDispatch()
    const userData = useSelector(state => state.user)
    const navigate = useNavigate();

    const token = useSelector((state) => state?.user?.token)

    // const validation = event => {
    //     event.preventDefault()
    //     let message = "";
    //     if (email == "") {
    //         message = Messages.EMAIL_REQUIRED;
    //         setEmailMessage(message)
    //     }
    //     else if (regx.EMAIL.test(email) == false) {
    //         message = Messages.EMAIL_INVALID;
    //         setEmailMessage(message)
    //     }
    //     else {
    //         setEmailMessage('')
    //     }
    //     if (password == "") {
    //         message = Messages.PASSWORD_REQUIRED;
    //         setPasswordMessage(message)
    //     } else {
    //         setPasswordMessage('')
    //     }
    //     if (message == '') {
    //         console.log("yoooo.!");
    //         authenticate()
    //     }
    // }


    const authenticate = async (event) => {

        event.preventDefault()

        dispatch(loginUser({ email, password, Remember }))
        // var form = new FormData();
        // form.append("email", email);
        // form.append("password", password);
        // await axios.post(BASE_URL +GetAPIUrl.LOGIN_URL, form)  
        //     .then(response => {
        //         console.log("response",response.token);
        //         if (response.data.success == true) {   
        //             if (Remember == true) {
        //                 cookies.set('email', email, { path: '/' });
        //                 cookies.set('password', password, { path: '/' });
        //                 localStorage.setItem('data', JSON.stringify(response.data.data))
        //                 localStorage.setItem('token', response.data.token)
        //                 window.location.pathname = '/'  
        //                 ShowMessage(response.data.message)

        //             } else {
        //                 if (cookies.get('email') != undefined) {
        //                     cookies.remove('email', { path: '/' });
        //                     cookies.remove('password', { path: '/' });
        //                 }
        //             }
        //             ShowMessage(response.data.message)
        //         } else {
        //             ShowErrorMessage(response.message)
        //         }
        //     }).catch((error) => {
        //         ShowErrorMessage(error)
        //     })
    }

    const changeHandle = event => {
        event.preventDefault()
        setRemember(!Remember)
    }
    if (authorized) {
        // window.location.reload(false)
        return navigate(-1);

    }
    console.log("Newss", token);
    return (
        <>
            {/* {userData.status == true &&
                <Backdrop className={classes.backdrop} open>
                    <CircularProgress color="inherit" />
                </Backdrop>

            } */}

            <div>
                <div className="container container-main">
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item">
                                <Link to={'/'}><i className="fa fa-home" aria-hidden="true"></i></Link>
                            </li>
                            <li className="breadcrumb-item active" aria-current="page">Login</li>
                        </ol>
                    </nav>
                </div>
            </div>

            <section className="jumbotron">
                <div className="limiter">
                    <div className="container-login100">
                        <div className="wrap-login100">
                            <form className="login100-form validate-form">
                                <span className="login100-form-title p-b-34">Login</span>
                                <div className="">
                                    <div className="row">
                                        <div className="col-xl-12">
                                            <div className="form-group">
                                                <label className="lblmy lblmy-active">Email*</label>
                                                <input
                                                    value={email}
                                                    onChange={e => setEmail(e.target.value)}
                                                    type="text"
                                                    className="form-control my-textbox"
                                                    placeholder="Enter Email Id" />
                                                <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                    {userData?.error != '' && userData?.error?.email?.map((key, i) => key)}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="col-xl-12">
                                            <div className="form-group">
                                                <label className="lblmy">Password*</label>
                                                <input
                                                    style={{ font: showPassShow && "small-caption", }}
                                                    value={password}
                                                    onChange={e => setPassword(e.target.value)}
                                                    id="showpassword"
                                                    type={showPassShow ? "text" : 'password'}
                                                    className="form-control my-textbox"
                                                    placeholder="Enter Password" />
                                                <span className="show-pass hand" title={showPassShow ? "Hide password" : "show password"} onClick={() => setShowPassShow(!showPassShow)}
                                                    style={{ paddingLeft: 5, paddingRight: 5 }} >
                                                    <i className={showPassShow ? "fa fa-eye-slash" : 'fa fa-eye showpassword'} aria-hidden="true"></i>
                                                </span>
                                                <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                    {userData?.error != '' && userData?.error?.password?.map((key, i) => key)}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="col-xl-6 col-6">
                                            <div className="form-check-inline">

                                                <label className="container-checkbox">
                                                    <button style={{ border: 0, backgroundColor: 'white' }} onClick={changeHandle}>
                                                        {Remember == true ?
                                                            <h3>  <AiOutlineCheckSquare /></h3>
                                                            :
                                                            <h3>  <AiOutlineBorder /></h3>
                                                        }</button>
                                                    Remember me
                                                    {/* <input type="checkbox" /> */}


                                                </label>
                                            </div>
                                        </div>

                                        <div className="col-xl-12 text-center">
                                            <br />
                                            {/* <button onClick={authenticate} className="login-me btn-shadow-me min-w-200">Log in</button> */}

                                            <button onClick={authenticate} className="login-me btn-shadow-me min-w-200">Log in</button>

                                        </div>
                                        <div className="w-100">
                                            <div className="col-xl-12 mt-2">
                                                <p className="text-center" style={{ fontWeight: 600 }}>
                                                    {" Do not have an account with us ?" + " "}
                                                    <Link
                                                        className="login-link"
                                                        aria-current="page"
                                                        to={'/Signup'}
                                                    >
                                                        {"Sign Up"}
                                                    </Link>
                                                    {/* <a className="login-link" href="signup.html"> Sign Up </a> */}
                                                </p>
                                            </div>
                                            <div className="col-xl-12 mt-2">
                                                <p className="text-center" style={{ fontWeight: 600 }}>
                                                    {"Forget Password ?" + " "}
                                                    <Link
                                                        className="login-link"
                                                        aria-current="page"
                                                        to={'/ForgetPassword'}
                                                    >
                                                        {"Click here"}
                                                    </Link>
                                                    {/* <a className="login-link" href="signup.html"> Sign Up </a> */}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div className="login100-more d-none d-xl-block d-lg-block" style={{ backgroundImage: `url('./assets/images/login/login-banner.jpg')` }}></div>
                        </div>
                    </div>
                </div>
            </section>
            {/* <ToastContainer /> */}
        </>

    )
}

export default Login