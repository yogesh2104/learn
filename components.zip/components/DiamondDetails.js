import axios from 'axios';
import React, { useEffect, useRef, useState } from 'react';
import { Link, Navigate, useLocation, useParams } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import { BASE_URL, GetAPIUrl } from '../API/APIUrl';
import { ShowErrorMessage, ShowMessage } from '../module/Tostify';
import noimage from "../assets/images/product-details/noimage.jpg";
import ReactPlayer from 'react-player';
import { makeStyles, withStyles } from "@material-ui/core/styles";
import PlayerControls from '../module/PlayerControls';
import Slider from "@material-ui/core/Slider";
import Tooltip from "@material-ui/core/Tooltip";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import screenful from "screenfull";
import LoadingSpinner from '../module/LoadingSpinner';
import { useSelector } from 'react-redux';
import { b64_to_utf8, BASENAME, utf8_to_b64 } from '../helpers/Utility';
import { CallCartCountApi } from '../reducers/userReducers';


const $ = window.$;


const DiamondDetails = () => {
    let { sid, slug } = useParams();
    console.log("location.search", sid == undefined ? "" : b64_to_utf8(sid), slug);

    const DiamondId = sid == undefined ? "" : b64_to_utf8(sid)
    const JewelryId = localStorage.getItem('JewelryId')

    const FromSetting = JSON.parse(localStorage.getItem('FromSetting'))
    const [Category, setCategory] = useState(JSON.parse(localStorage.getItem('Category')) ? JSON.parse(localStorage.getItem('Category')) : '')
    console.log("FromSetting", FromSetting);
    const [DiamondDetail, setDiamondDetail] = useState([])
    const [selecteImage, setSelecteImage] = useState('')
    const [IsLoading, setIsLoading] = useState(false)
    const [IsWishlistLoading, setIsWishlistLoading] = useState(false)
    const [IsCartLoading, setIsCartLoading] = useState(false)

    const token = useSelector((state) => state?.user?.token)

    // let { id } = useParams();
    useEffect(() => {
        CallDiamondDetailApi()
    }, [])
    const CallDiamondDetailApi = async () => {
        setIsLoading(true)
        const controller = new AbortController();

        axios.get(BASE_URL + GetAPIUrl.DIAMONDDETAIL_URL + `/${DiamondId}`)
            .then(response => {
                if (response.data.success == true) {
                    setIsLoading(false)
                    setDiamondDetail(response.data.data);
                    setSelecteImage(response.data.data.images[0])
                } else {
                    setIsLoading(false)
                    ShowErrorMessage(response.data.message)
                }
            }).catch(error => {
                ShowErrorMessage(error.message)
            });
        controller.abort()
    }
    const selectionFun = (item, index) => {
        setSelecteImage(item)
    }


    const CallAddtoWishlistApi = async () => {
        setIsWishlistLoading(true)
        const controller = new AbortController();
        var form = new FormData();
        let JewelryId = FromSetting.map((tag) => {
            return tag?.jewelryData?.id
        })
        let SelectedringSizeid = FromSetting.map((tag) => {
            return tag?.SelectedringSize?.id
        })
        form.append("jewelryid", JewelryId == null ? "" : JewelryId);
        form.append("diamondid", DiamondId == null ? "" : DiamondId);
        form.append('ringsize',SelectedringSizeid)

        await axios.post(BASE_URL + GetAPIUrl.WISHLIST_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.success == true) {
                    setIsWishlistLoading(false)
                    ShowMessage(response.data.message)
                    CallCartCountApi(token)
                    // window.location.pathname = '/Wishlist'
                } else {
                    setIsWishlistLoading(false)
                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                setIsWishlistLoading(false)
                ShowErrorMessage(error.message)
            });
        controller.abort()
    }
    const CallAddtoCart = async () => {
        setIsCartLoading(true)
        const controller = new AbortController();
        let JewelryId = FromSetting.map((tag) => {
            return tag?.jewelryData?.id
        })
        let SelectedringSizeid = FromSetting.map((tag) => {
            return tag?.SelectedringSize?.id
        })

        var form = new FormData();

        form.append("jewelryid", JewelryId == null ? "" : JewelryId);
        form.append("diamondid", DiamondId == null ? "" : DiamondId);
        form.append('ringsize',SelectedringSizeid)

        await axios.post(BASE_URL + GetAPIUrl.ADDTOCART_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.success == true) {
                    setIsCartLoading(false)
                    ShowMessage(response.data.message)
                    CallCartCountApi(token)
                    // window.location.pathname = '/Cart'
                } else {
                    setIsCartLoading(false)
                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                setIsCartLoading(false)
                ShowErrorMessage(error.message)
            });
        controller.abort()
    }
    let dataFlow = FromSetting?.map(item => item?.jewelryData != '' && item?.diamondData != '')

    const removeStorageData = () => {
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '', SelectedringSize: '', diamondData: '' }]));
        // window.location.reload(false);
    }
    const AddStorageData = (item) => {
        let data = {
            "id": item?.id,
            "name": item?.paraname,
            "description": item?.description,
            "image": item?.image,
        }
        localStorage.setItem('Shape', JSON.stringify([data]));
        // localStorage.removeItem('Shape');
        localStorage.removeItem('MetalType')
        localStorage.removeItem('All')
        localStorage.removeItem('Subcategory')
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '', SelectedringSize: '', diamondData: '' }]));
    }
    $(function () {
        $('.f-click').on({
            'click': function () {
                // $('.change-image').attr('src','images/product/p1.png');
                $(this).parent().closest('.find-img').find('.change-image').attr('src', $(this).data('src'));
                // $(this).toggleClass('active-1');
                $(this).addClass("active-1").siblings().removeClass("active-1");
            }
        });
        // Instantiate EasyZoom instances
        var $easyzoom = $('.easyzoom').easyZoom();
        // Setup thumbnails example
        var api1 = $easyzoom.filter('.easyzoom--with-thumbnails').data('easyZoom');

        $('.thumbnails').on('click', 'a', function (e) {
            var $this = $(this);
            e.preventDefault();
            // Use EasyZoom's `swap` method
            api1.swap($this.data('standard'), $this.attr('href'));
        });
        // Setup toggles example
        var api2 = $easyzoom.filter('.easyzoom--with-toggle').data('easyZoom');

        $('.toggle').on('click', function () {
            var $this = $(this);

            if ($this.data("active") === true) {
                $this.text("Switch on").data("active", false);
                api2.teardown();
            } else {
                $this.text("Switch off").data("active", true);
                api2._init();
            }
        });

        $(".add-active li").click(function () {
            $("li").removeClass("active-bor-z");
            $(this).addClass("active-bor-z");
        });
        $(window).scroll(function () {
            var pos = $(window).scrollTop();
            if (pos >= 100) {
                var explorefix = $('.myHeader').css("height");
                $(".thumbsider").css({
                    position: 'sticky',
                });
                $('.thumbsider').css("top", parseInt(explorefix) + 10);
            }
            else {
                $(".thumbsider").css({
                    position: 'inherit',
                    top: '0px'
                });

            }
        })
    });

    return (
        <>
            {IsLoading || IsWishlistLoading || IsCartLoading ?
                < LoadingSpinner />
                :
                null
            }

            <>
                <div>
                    <div className="container container-main">
                        <nav aria-label="breadcrumb">
                            <ol className="breadcrumb">
                                {/* <li className="breadcrumb-item">
                                    <Link
                                        className=""
                                        aria-current="page"
                                        to={'/'}
                                    >
                                        <i className="fa fa-home" aria-hidden="true"></i>
                                    </Link>

                                </li>
                                <li className="breadcrumb-item active" aria-current="page">Diamond Details</li> */}
                            </ol>
                        </nav>
                    </div>
                </div>
                {Category.categoryName != "All" &&
                    FromSetting?.map((tag, i) => {
                        return (
                            <section className="mobile-view-none" key={i}>
                                <div className="container container-main">
                                    <div className="wizard2-steps mb-3">
                                        <div className="step wizard2-steps-heading">
                                            <div className="node">
                                                <div className="node-skin">
                                                    <div className="cont">
                                                        <h2 className="nostyle-heading">Build Your Own Ring</h2>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {tag?.jewelryData == '' ?
                                            <div className="cyo-bar-step step step-item ">
                                                <div className="node" >
                                                    <div className="node-skin">
                                                        <div className="pho">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/steps/setting.svg"} alt="setting" />
                                                        </div>
                                                        <div className="cont">
                                                            <div className="action help-tips">
                                                                <a href="#" className="td-u bar-action line1-doted-2"></a>
                                                            </div>
                                                            <div className="heading">
                                                                <div className="action help-tips">
                                                                    <a href="#" className="td-u bar-action">Choose</a>
                                                                </div>
                                                                <h2 className="nostyle-heading">setting</h2>


                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            :
                                            <div className="cyo-bar-step step step-item active-step keep-left">
                                                <div className="node" >
                                                    <div className="node-skin">
                                                        <div className="pho">

                                                            <img style={{ background: 'rgba(76, 175, 80, 0.1)' }} src={tag?.jewelryData?.default.path} alt="setting" />


                                                        </div>
                                                        <div className="cont">
                                                            <div className="heading"><h2 className="nostyle-heading">Setting</h2>
                                                                <div className="action help-tips">
                                                                    <div className="td-u bar-action">{tag?.jewelryData?.title}
                                                                        <aside>Price :${tag?.jewelryData?.setting_price?.toFixed(2)}</aside></div>
                                                                </div>
                                                                <div className="action double-action" style={{ display: 'flex' }}>
                                                                    {/* <div onClick={() => window.location.reload()}>
                                                                        <Link
                                                                            className="td-u bar-action"
                                                                            aria-current="page"
                                                                            style={{ textDecoration: "none",marginRight:10 }}

                                                                            to={process.env.PUBLIC_URL +`/Jewelry/${utf8_to_b64(tag?.shape_name?.id)}/${tag?.jewelryData?.title}`}
                                                                        >
                                                                            Change
                                                                        </Link>
                                                                    </div>
                                                                    <div onClick={() => window.location.reload()}>
                                                                        <Link
                                                                            className="td-u bar-action"
                                                                            aria-current="page"
                                                                            style={{ textDecoration: "none" }}

                                                                            to={process.env.PUBLIC_URL +`/JDetails/${utf8_to_b64(tag?.jewelryData?.id)}/${tag?.jewelryData?.title}`}
                                                                            >
                                                                            View
                                                                        </Link>
                                                                    </div> */}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        }
                                        {tag?.diamondData == '' ?
                                            <div className="cyo-bar-step step step-item ">
                                                <div className="node" >
                                                    <div className="node-skin">
                                                        <div className="pho">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/steps/diamonds.svg"} alt="diamond" />
                                                        </div>
                                                        <div className="cont">
                                                            <div className="action help-tips">
                                                                <a href="#" className="td-u bar-action line1-doted-2"></a>
                                                            </div>
                                                            <div className="heading">
                                                                <div className="action help-tips">
                                                                    <a href="#" className="td-u bar-action">Choose</a>
                                                                </div>
                                                                <h2 className="nostyle-heading">Diamond</h2>


                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            :
                                            <div className="cyo-bar-step step step-item  active-step keep-left">
                                                <div className="node" >
                                                    <div className="node-skin">
                                                        <div className="pho">
                                                            <img src={tag?.diamondData?.image} alt="diamond" style={{ backgroundColor: "white" }} />
                                                        </div>
                                                        <div className="cont">
                                                            <div className="action help-tips">
                                                                <a href="#" className="td-u bar-action line1-doted-2"></a>
                                                            </div>
                                                            <div className="heading">
                                                                <h2 className="nostyle-heading">Diamond</h2>
                                                                <div className="action help-tips">
                                                                    <div className="td-u bar-action">{tag?.diamondData?.carat} Carat {tag?.diamondData?.ShapeName} Diamond, {tag?.diamondData?.ColorName}-{tag?.diamondData?.ClarityName}
                                                                        <aside>Price :${tag?.diamondData?.amount}</aside></div>
                                                                </div>
                                                                <div className="action double-action" style={{ display: 'flex' }}>
                                                                    {/* <div onClick={() => window.location.reload()}>
                                                                        <Link
                                                                            className="td-u bar-action"
                                                                            aria-current="page"
                                                                            style={{ textDecoration: "none",marginRight:10 }}

                                                                            to={process.env.PUBLIC_URL +`/DiamondList/${tag?.diamondData?.carat} Carat ${tag?.diamondData?.ShapeName} Diamond, ${tag?.diamondData?.ColorName}-${tag?.diamondData?.ClarityName}`}
                                                                            >
                                                                            Change
                                                                        </Link>
                                                                    </div>
                                                                    <div onClick={() => window.location.reload()}>
                                                                        <Link
                                                                            className="td-u bar-action"
                                                                            aria-current="page"
                                                                            style={{ textDecoration: "none" }}

                                                                            to={process.env.PUBLIC_URL +`/DiamondDetails/${tag?.diamondData?.carat} Carat ${tag?.diamondData?.ShapeName} Diamond, ${tag?.diamondData?.ColorName}-${tag?.diamondData?.ClarityName}`}
                                                                        >
                                                                            View
                                                                        </Link>
                                                                    </div> */}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        }

                                        {tag?.diamondData != '' && tag?.jewelryData != '' ?
                                            <div className="step step-item invariant-color active-step keep-left">
                                                <div className="node">
                                                    <div className="node-skin">
                                                        <div className="pho">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/steps/ring.svg"} alt="ring" style={{ backgroundColor: "white" }} />
                                                        </div>
                                                        <div className="cont">
                                                            <div className="action help-tips">TOTAL</div>
                                                            <div className="heading"><h2 className="nostyle-heading">${(tag?.jewelryData?.setting_price + tag?.diamondData?.amount)?.toFixed(2)}</h2></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            :
                                            <div className="step step-item invariant-color">
                                                <div className="node">
                                                    <div className="node-skin">
                                                        <div className="pho">
                                                            <img src={process.env.PUBLIC_URL + "/assets/images/steps/ring.svg"} alt="ring" />
                                                        </div>
                                                        <div className="cont">
                                                            {/* <div className="action help-tips">Choose</div> */}
                                                            <div className="heading"><h2 className="nostyle-heading">TOTAL</h2></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        }
                                    </div>
                                </div>
                            </section>
                        )
                    })
                }


                <section className="jumbotron pt-3">
                    <div className="container container-main">
                        <div className="product-details">
                            <div className="row">

                                <div className="col-lg-6">
                                    <div className="thumbsider" id="sidebar">
                                        {
                                            selecteImage?.type == "Image" ?
                                                <div className="easyzoom easyzoom--overlay easyzoom--with-thumbnails boximg-shadot box-h-w mar-l-94">

                                                    <a href={selecteImage?.path}>
                                                        <img src={selecteImage?.path == null ? noimage : selecteImage?.path}
                                                            alt=""
                                                            className="img-w-100" />

                                                    </a>
                                                </div>
                                                :
                                                DiamondDetail?.video?.map((item, index) => {
                                                    return (
                                                        // <div
                                                        //     onMouseMove={handleMouseMove}
                                                        //     onMouseLeave={hanldeMouseLeave}
                                                        //     ref={playerContainerRef}
                                                        //     className={classes.playerWrapper}
                                                        //     // className="boximg-shadot box-h-w mar-l-94"
                                                        //      key={item.id}
                                                        // >
                                                        //     <ReactPlayer
                                                        //         ref={playerRef}
                                                        //         width="100%"
                                                        //         height="100%"
                                                        //         url="http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
                                                        //         pip={pip}
                                                        //         playing={playing}
                                                        //         controls={false}
                                                        //         light={light}
                                                        //         loop={loop}
                                                        //         playbackRate={playbackRate}
                                                        //         volume={volume}
                                                        //         muted={muted}
                                                        //         onProgress={handleProgress}
                                                        //         config={{
                                                        //             file: {
                                                        //                 attributes: {
                                                        //                     crossorigin: "anonymous",
                                                        //                 },
                                                        //             },
                                                        //         }}
                                                        //     />

                                                        //     <PlayerControls
                                                        //         ref={controlsRef}
                                                        //         onSeek={handleSeekChange}
                                                        //         onSeekMouseDown={handleSeekMouseDown}
                                                        //         onSeekMouseUp={handleSeekMouseUp}
                                                        //         onDuration={handleDuration}
                                                        //         onRewind={handleRewind}
                                                        //         onPlayPause={handlePlayPause}
                                                        //         onFastForward={handleFastForward}
                                                        //         playing={playing}
                                                        //         played={played}
                                                        //         elapsedTime={elapsedTime}
                                                        //         totalDuration={totalDuration}
                                                        //         onMute={hanldeMute}
                                                        //         muted={muted}
                                                        //         onVolumeChange={handleVolumeChange}
                                                        //         onVolumeSeekDown={handleVolumeSeekDown}
                                                        //         onChangeDispayFormat={handleDisplayFormat}
                                                        //         playbackRate={playbackRate}
                                                        //         onPlaybackRateChange={handlePlaybackRate}
                                                        //         onToggleFullScreen={toggleFullScreen}
                                                        //         volume={volume}
                                                        //     />
                                                        // </div>

                                                        <div className="boximg-shadot box-h-w mar-l-94" key={index}>
                                                            <iframe style={{ minWidth: "100%", minHeight: "350px" }} allow="autoplay"
                                                                src={item?.path == null ? noimage : item?.path}></iframe>
                                                        </div>
                                                    )
                                                })}

                                        <ul className="ul-start thumbnails add-active set-thumb" >
                                            {
                                                DiamondDetail?.images?.map((item, index) => {
                                                    return (
                                                        <li key={index} className={selecteImage?.id == item?.id ?
                                                            "active-bor-z" :
                                                            "boximg-shado"} onClick={() => selectionFun(item, index)}>
                                                            <a data-standard={item?.path} >
                                                                <img src={item?.path == null ? noimage : item?.path}
                                                                    alt="" />
                                                            </a>
                                                        </li>
                                                    )
                                                })}
                                            {
                                                DiamondDetail?.video?.map((item, index) => {
                                                    return (
                                                        <li key={index} className={selecteImage?.id == item?.id ?
                                                            "active-bor-z" : "boximg-shado"} >
                                                            <a href={item?.path} className="iframe-video-thumb"
                                                                onClick={() => selectionFun(item, index)}>
                                                                <img
                                                                    src="https://cdn.shopify.com/s/files/1/0057/0736/6467/files/prod-video.png?v=1611210220"
                                                                    alt="https://cdn.shopify.com/s/files/1/0057/0736/6467/files/prod-video.png?v=1611210220" />
                                                            </a>
                                                        </li>
                                                    )
                                                })}
                                        </ul>
                                    </div>

                                </div>
                                <div className="col-lg-6 pl-5 mob-pl-15 mob-mt-30">
                                    <div className="">

                                        <h4 className="lsp1 Hypatia-bold tit-color mb-3 pr-5">
                                            {DiamondDetail?.carat} Carat {DiamondDetail?.ShapeName} Diamond, {DiamondDetail?.ColorName}-{DiamondDetail?.ClarityName}
                                            <span className="hand details-heart-fixed" onClick={() => token == "" || token == undefined ? window.location.pathname = BASENAME + "Login" : CallAddtoWishlistApi()}>
                                                <svg width="24" height="21" viewBox="0 0 24 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M6.5 1C3.4629 1 1 3.36095 1 6.27377C1 8.62513 1.9625 14.2057 11.4368 19.8471C11.6065 19.9471 11.8013 20 12 20C12.1987 20 12.3935 19.9471 12.5632 19.8471C22.0375 14.2057 23 8.62513 23 6.27377C23 3.36095 20.5371 1 17.5 1C14.4629 1 12 4.19623 12 4.19623C12 4.19623 9.5371 1 6.5 1Z" stroke="#AB7C94" strokeOpacity="0.65" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
                                                </svg>
                                            </span>
                                        </h4>
                                        <h6 className="lists-h5 mb-3">
                                            <span className="t-color">SKU :</span> {DiamondDetail?.loatno}
                                        </h6>
                                        {FromSetting?.map((tag, index) => {
                                            return (
                                                tag?.jewelryData != '' ?
                                                    <div class="mt-4 mb-3 selected-boxdiv" key={index}><h3><b>Your Ring</b></h3>
                                                        <div class="row mt-3 mb-3" style={{ alignItems: "center" }}>
                                                            <div class="col-xl-2 col-lg-2 col-sm-1 col-2" style={{ paddingRight: "5px" }}>
                                                                {/* <img class="img-responsive product-image" src="https://bellamy.blob.core.windows.net/bellamy/M00245/M00245_0002.png" width="100%" alt=" 14K Rose Gold Comfort Fit Engagement Ring" /> */}
                                                                <img className='img-responsive product-image' style={{ background: 'rgba(76, 175, 80, 0.1)' }} src={tag?.jewelryData?.default.path} alt="setting" width="100%" />

                                                            </div>
                                                            <div class="col-xl-10 col-lg-10 col-sm-11 col-10">
                                                                <h6 class="lsp1 Hypatia-bold mb-2">{tag?.jewelryData?.metalstampname} {tag?.jewelryData?.metaltypename} Comfort Fit {tag?.jewelryData?.CategoryName}</h6>Ring Size : {tag?.SelectedringSize?.value}<br />Metal : {tag?.jewelryData?.metalstampname} {tag?.jewelryData?.metaltypename}<br />
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="column" >
                                                                <h6>Your Diamond </h6>
                                                                <h6>Your Ring </h6>
                                                                <h6>Total </h6>

                                                            </div>
                                                            <div class="column" >
                                                                <h6>: ${DiamondDetail?.amount}</h6>
                                                                <h6>: ${tag?.jewelryData?.setting_price}</h6>
                                                                <h6>: ${tag?.jewelryData?.setting_price + DiamondDetail?.amount}</h6>

                                                            </div>
                                                        </div>
                                                        {/* <div class="dflx mb-2 col-bl-600"><h6>Your Diamond : $ {DiamondDetail?.amount}</h6></div>
                                                        <div class="dflx mb-2 col-bl-600"><h6>Your Ring : $ {tag?.jewelryData?.setting_price}</h6></div>
                                                        <div class="dflx"><h6>Total : $ {tag?.jewelryData?.setting_price + DiamondDetail?.amount}</h6></div> */}
                                                    </div>
                                                    :
                                                    <h3 className="lists-h2-price">
                                                        ${DiamondDetail?.amount}
                                                    </h3>

                                            )
                                        })}

                                        <div className="mt-4">
                                            {dataFlow[0] == true ?
                                                FromSetting?.map((tag, index) => {
                                                    console.log("tag", tag.diamondData);
                                                    return (
                                                        <>
                                                            <div onClick={() => { AddStorageData(tag.diamondData.shape_name) }} onAuxClick={() => { AddStorageData(tag.diamondData.shape_name) }}>
                                                                <a href={process.env.PUBLIC_URL + `/Jewelry/${tag?.diamondData?.shape_name?.paraname}`} className="start-with-diamonds">
                                                                    Change Your Selection
                                                                </a>
                                                                {/* <Link
                                                            className="start-with-diamonds"
                                                            aria-current="page"
                                                            style={{ textDecoration: "none", marginRight: 10 }}

                                                            to=''
                                                        >
                                                            
                                                        </Link> */}
                                                            </div>

                                                            <div style={{ display: 'flex', }}>
                                                                <div onClick={() => token == "" || token == undefined ? window.location.pathname = BASENAME + "Login" : CallAddtoWishlistApi()}>
                                                                    {/* <Link
                                                                className="start-with-diamonds"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none", marginRight: 10 }}

                                                                to={process.env.PUBLIC_URL +`/Wishlist`}

                                                            >
                                                                Add to Wishlist
                                                            </Link> */}
                                                                    <a style={{ marginRight: 10 }} className="start-with-diamonds">
                                                                        Add to Wishlist
                                                                    </a>
                                                                </div>

                                                                <div onClick={() => token == "" || token == undefined ? window.location.pathname = BASENAME + "Login" : CallAddtoCart()}>
                                                                    {/* <Link
                                                                className="start-with-diamonds"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none", marginRight: 10 }}

                                                                to={process.env.PUBLIC_URL +`/Cart`}

                                                            >
                                                                Add to Cart
                                                            </Link> */}
                                                                    <a className="start-with-diamonds">
                                                                        Add to Cart
                                                                    </a>
                                                                </div>

                                                            </div>
                                                        </>
                                                    )
                                                })

                                                :
                                                Category.categoryName != "All" ?
                                                    <div style={{ display: 'flex' }}>
                                                        {FromSetting?.map((tag, index) => {
                                                            console.log("tag?.diamondData?", tag?.diamondData?.shape_name);
                                                            let shapename = {
                                                                "description"
                                                                    :
                                                                    tag?.diamondData?.shape_name?.description,
                                                                "id"
                                                                    :
                                                                    tag?.diamondData?.shape_name?.id,
                                                                "image"
                                                                    :
                                                                    tag?.diamondData?.shape_name?.image,
                                                                "name"
                                                                    :
                                                                    tag?.diamondData?.shape_name?.paraname
                                                            }
                                                            return (
                                                                <div key={index} onClick={() => localStorage.setItem('Shape', JSON.stringify([shapename]))}>
                                                                    {/* <Link
                                                                        className="start-with-diamonds"
                                                                        aria-current="page"
                                                                        style={{ textDecoration: "none", marginRight: 10 }}

                                                                        to={BASENAME + `Jewelry/${utf8_to_b64(tag?.diamondData?.shape_name?.id)}/${tag?.diamondData?.carat}`}

                                                                    >
                                                                        Choose Your Setting
                                                                    </Link> */}
                                                                    <a
                                                                        className="start-with-diamonds"
                                                                        aria-current="page"
                                                                        style={{ textDecoration: "none", marginRight: 10 }}

                                                                        href={process.env.PUBLIC_URL + `/Jewelry/${utf8_to_b64(tag?.diamondData?.shape_name?.id)}/${tag?.diamondData?.carat}`}
                                                                    >
                                                                        Choose Your Setting
                                                                    </a>
                                                                </div>
                                                            )
                                                        })}

                                                        <div onClick={() => token == "" || token == undefined ? window.location.pathname = BASENAME + "Login" : CallAddtoCart()}>
                                                            {/* <Link
                                                                className="start-with-diamonds"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none", marginRight: 10 }}

                                                                to={process.env.PUBLIC_URL +`/Cart`}

                                                            >
                                                                Add to Cart
                                                            </Link> */}
                                                            <a className="start-with-diamonds">
                                                                Add to Cart
                                                            </a>

                                                        </div>
                                                    </div>
                                                    :
                                                    <div onClick={() => token == "" || token == undefined ? window.location.pathname = BASENAME + "Login" : CallAddtoCart()}>
                                                        {/* <Link
                                                            className="start-with-diamonds"
                                                            aria-current="page"
                                                            style={{ textDecoration: "none", marginRight: 10 }}

                                                            to={process.env.PUBLIC_URL +`/Cart`}

                                                        >
                                                            Add to Cart
                                                        </Link> */}
                                                        <a className="start-with-diamonds">
                                                            Add to Cart
                                                        </a>

                                                    </div>
                                            }
                                        </div>
                                        <div>
                                            <p className="ptag-text">
                                                Whether for an engagement, anniversary, or a new family addition, this stunning Diora Adams Diamond will be a part of your moment Diora Adams. Personalize it with one of our options or purchase the affordable loose diamond individually.
                                            </p>
                                        </div>
                                        <div>
                                            <h6>
                                                About This Lab-Grown Diamond
                                            </h6>
                                            <div>
                                                <dl className="order-summary-me-2 pad-10-dd-me">
                                                    <dd>
                                                        Shape
                                                        <strong>{DiamondDetail?.originalShapeName}</strong>
                                                    </dd>
                                                    <dd>
                                                        Color
                                                        <strong>{DiamondDetail?.ColorName}</strong>
                                                    </dd>
                                                    <dd>
                                                        Clarity
                                                        <strong>{DiamondDetail?.ClarityName}</strong>
                                                    </dd>
                                                    <dd>
                                                        Carat
                                                        <strong>{DiamondDetail?.carat}</strong>
                                                    </dd>
                                                    <dd>
                                                        Certificate
                                                        <a href={DiamondDetail.cert_location} target="_blank" style={{ color: 'blue', float: "right" }}><>{DiamondDetail?.cert_no}</></a>
                                                    </dd>
                                                    <dd>
                                                        Cut
                                                        <strong>{DiamondDetail?.CutName}</strong>
                                                    </dd>
                                                    <dd>
                                                        Polish
                                                        <strong>{DiamondDetail?.PolishName}</strong>
                                                    </dd>
                                                    <dd>
                                                        Symmetry
                                                        <strong>{DiamondDetail?.SymName}</strong>
                                                    </dd>
                                                    <dd>
                                                        Measurement
                                                        <strong>{DiamondDetail?.measurement}</strong>
                                                    </dd>
                                                    <dd>
                                                        Depth
                                                        <strong>{DiamondDetail?.tabledepth}</strong>
                                                    </dd>
                                                    <dd>
                                                        Table
                                                        <strong>{DiamondDetail?.tablearea}</strong>
                                                    </dd>
                                                    <dd>
                                                        Lab
                                                        <strong>{DiamondDetail?.LabName}</strong>
                                                    </dd>
                                                </dl>
                                            </div>
                                        </div>
                                        <p className="ptag-text">
                                            The videos and images used are for presentations purposes only, for more information on this exact stone, please contact us
                                        </p>
                                        <div className="mt-3">
                                            <h5>
                                                Shipping
                                            </h5>
                                            <p className="ptag-text">
                                                Diora Adams Diamonds ships across the United States. Most pieces will ship within two business days, custom creations can take around three weeks. This item is boxed for safe keeping or gift giving, we understand that jewelry is often given as a special surprise and we want to maintain your surprise. All orders are packed in earth friendly packaging and the label doesn't give it away!
                                            </p>
                                            <p className="ptag-text">
                                                Shipments are 100% fully insured and require a signature upon arrival.
                                            </p>
                                            <p className="ptag-text">
                                                If you have any questions, please call customer service at (855) 456-4587 or chat with us.
                                            </p>
                                            <p className="ptag-text">
                                                We offer a range of settings, usually in the shape for a round diamond. However, each setting is made for the loose diamond shape you choose. Helpful hints for picking a diamond shape:
                                            </p>

                                            <ul className="ulli-list">
                                                <li className="ptag-text">
                                                    Round diamonds are by far the most popular choice due to their brilliance, fire, and offer maximum sparkle.
                                                </li>
                                                <li className="ptag-text">
                                                    Pear shaped cut diamonds are more distinctive shapes, and help fingers look long and slender due to their elongated appearance.
                                                </li>
                                                <li className="ptag-text">
                                                    Heart shaped diamonds reflect lots of light, the color of a heart shaped diamond is harder to distinguish but the not the universal symbol of romantic love.
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </section>
            </>


            <ToastContainer />

        </>
    )
}
export default DiamondDetails