import axios from 'axios'
import { useEffect, useState } from 'react'
import diamonds from '../assets/images/steps/diamonds.svg'
import ring from '../assets/images/steps/ring.svg'
import setting from '../assets/images/steps/setting.svg'

import drose1 from '../assets/images/diamond_icon/14k_rose.png'
import drose2 from '../assets/images/diamond_icon/18k_rose.png'

import dwhite1 from '../assets/images/diamond_icon/14k_white.png'
import dwhite2 from '../assets/images/diamond_icon/18k_white.png'

import dyellow1 from '../assets/images/diamond_icon/14k_yellow.png'
import dyellow2 from '../assets/images/diamond_icon/18k_yellow.png'

import dpla1 from '../assets/images/diamond_icon/14k_black.png'
import dpla2 from '../assets/images/diamond_icon/18k_black.png'

import dgold1 from '../assets/images/diamond_icon/14k_gold.png'
import dgold2 from '../assets/images/diamond_icon/18k_gold.png'

import moment from 'moment'
import { Link, Navigate } from 'react-router-dom'
import imageErrorSrc from '../assets/images/default.png'
import dAsscher from '../assets/images/diamond-shape/Asscher.png'
import dCushion from '../assets/images/diamond-shape/Cushion.png'
import dEmerald from '../assets/images/diamond-shape/Emerald.png'
import dHeart from '../assets/images/diamond-shape/Heart.png'
import dMarquise from '../assets/images/diamond-shape/Marquise.png'
import dOval from '../assets/images/diamond-shape/Oval.png'
import dPear from '../assets/images/diamond-shape/Pear.png'
import dPrincess from '../assets/images/diamond-shape/Princess.png'
import dRadiant from '../assets/images/diamond-shape/Radiant.png'
import dRound from '../assets/images/diamond-shape/Round.png'
import { BASENAME } from '../helpers/Utility'

const $ = window.$;

export default function JewelryTab() {

    const [metalStamp, setMetalStamp] = useState([
        { id: 109, id1: 417, name: '18k', type: 'metal', name1: 'Rose Gold', img: drose1 },
        { id: 110, id1: 417, name: '14k', type: 'metal', name1: 'Rose Gold', img: drose2 },
        { id: 109, id1: 424, name: '18k', type: 'metal', name1: 'White Gold', img: dwhite1 },
        { id: 110, id1: 424, name: '14k', type: 'metal', name1: 'White Gold', img: dwhite2 },
        { id: 109, id1: 421, name: '18k', type: 'metal', name1: 'Yellow Gold', img: dyellow1 },
        { id: 110, id1: 421, name: '14k', type: 'metal', name1: 'Yellow Gold', img: dyellow2 },
        { id: 109, id1: 426, name: '18k', type: 'metal', name1: 'Gold', img: dgold1 },
        { id: 110, id1: 426, name: '14k', type: 'metal', name1: 'Gold', img: dgold2 },
        { id: 109, id1: 427, name: '18k', type: 'metal', name1: 'Platinum', img: dpla1 },
        { id: 110, id1: 427, name: '14k', type: 'metal', name1: 'Platinum', img: dpla2 },
    ])
    const [metalType, setMetalType] = useState([
        { id: 417, name: 'Rose Gold', type: 'metal' },
        { id: 424, name: 'White Gold', type: 'metal' },
        { id: 421, name: 'Yellow Gold', type: 'metal' },
        { id: 426, name: 'Gold', type: 'metal' },
        { id: 427, name: 'Platinum', type: 'metal' },
    ])
    const [diamondType, setDiamondType] = useState([
        { id: 1, name: 'Round', type: 'diamond', img: dRound },
        { id: 9, name: 'Asscher', type: 'diamond', img: dAsscher },
        { id: 6, name: 'Cushion', type: 'diamond', img: dCushion },
        { id: 7, name: 'Emerald', type: 'diamond', img: dEmerald },
        { id: 3, name: 'Heart', type: 'diamond', img: dHeart },
        { id: 4, name: 'Princess', type: 'diamond', img: dPrincess },
        { id: 10, name: 'Radiant', type: 'diamond', img: dRadiant },
        { id: 5, name: 'Oval', type: 'diamond', img: dOval },
        { id: 8, name: 'Marquise', type: 'diamond', img: dMarquise },
        { id: 2, name: 'Pear', type: 'diamond', img: dPear },
    ])
    const [weight, setWeight] = useState([
        { match1: 2, match2: 2, name: 'Less Than 2 Grams', type: 'weight' },
        { match1: 2, match2: 4, name: '2 Grams To 4 Grams', type: 'weight' },
        { match1: 4, match2: 6, name: '4 Grams To 6 Grams', type: 'weight' },
        { match1: 6, match2: 100, name: '6 Grams And Above', type: 'weight' },
    ])
    const [settingType, setSettingType] = useState([
        { id: 187, name: 'Prong', type: 'setting' },
        { id: 193, name: 'Channel', type: 'setting' },
        { id: 203, name: 'Micro Pave', type: 'setting' },
        { id: 188, name: 'Bezel', type: 'setting' },
        { id: 206, name: 'Pre-pave', type: 'setting' },
        { id: 207, name: 'Pressure', type: 'setting' },
        { id: 189, name: 'Three Stone', type: 'setting' },
        { id: 190, name: 'Pave', type: 'setting' },
        { id: 191, name: 'Side Stone', type: 'setting' },
        { id: 192, name: 'Tension', type: 'setting' },
        { id: 194, name: 'Vintage', type: 'setting' },
        { id: 195, name: 'Halo', type: 'setting' },
        { id: 196, name: 'Solitaire', type: 'setting' },
        { id: 197, name: 'Classic', type: 'setting' },
        { id: 202, name: 'Nick', type: 'setting' },
    ])
    const [price, setPrice] = useState([
        { match1: 0, match2: 100, name: 'Under $100', type: 'price' },
        { match1: 100, match2: 200, name: '$100 To $200', type: 'price' },
        { match1: 200, match2: 300, name: '$200 To $300', type: 'price' },
        { match1: 300, match2: 400, name: '$300 To $400', type: 'price' },
        { match1: 400, match2: 500, name: '$400 To $500', type: 'price' },
    ])
    const [MTStampResult, setMTStampResult] = useState([])
    const [MTresult, setMTResult] = useState([])
    const [DTresult, setDTResult] = useState([])
    const [margeMT, setMargeMT] = useState([])
    const [WMatchresult, setWMatchResult] = useState([])
    const [Wresult, setWResult] = useState([])
    const [STresult, setSTResult] = useState([])
    const [matchResult, setMatchResult] = useState([])
    const [Presult, setPResult] = useState([])
    const [jewellryData, setJewellryData] = useState([])
    const [alljewelleryData, setAllJewellryData] = useState([])
    const [allNames, setAllNames] = useState([])
    const [finalResult, setFinalResult] = useState([])
    const [Diamondnames, setDiamondnames] = useState([])
    const [sortResult, setSortResult] = useState([])



    useEffect(() => {
        getJewellryData()
        $(function () {

            var $cache = $('#getFixed');
            var $head = $('.header-fixscroll');
            function fixDiv() {
                if ($(window).scrollTop() > 100){
                     
                  return(
                    $cache.css({
                        
                        'position': 'fixed',
                        'top': '0px',
                        'width': '100%',
                        'z-index': '1045',
                        'background': '#fff',
                        'box-shadow': '#656565 0px 1px 20px -8px',
                        'padding-bottom': '5px',
                        'padding-top': '5px',
                    }),
                        $head.css({
                            'display': 'none'
                        })
                  )
                    }
                else{
                    return(
                    $cache.css({
                        'position': 'relative',
                        'top': 'auto',
                        'z-index': 'inherit',
                        'box-shadow': 'none',
                        'padding-bottom': 'auto',
                        'background': 'transparent',
                    }),
                        $head.css({
                            'display': 'block'
                        })
                    )
            }
        }
            var lastScrollTop = 0;
            $(window).scroll(function () {
                fixDiv();
                var st = $(this).scrollTop();
                if (st > lastScrollTop) {
                    $('.header-fixscroll').hide();
                    $('#getFixed').show();
                } else {
                    $('.header-fixscroll').show();
                    $('#getFixed').hide();
                }
                lastScrollTop = st;
                if (st == 0) {
                    $('#getFixed').show();
                }
            });


            if ($(window).width() < 991) {
                $('.filterdiv').addClass('f1div');
                $('#filter-modal').addClass('modal fade search-modal modal-bg-fff');
                $('.f2div').addClass('modal-dialog momodel modal-fluid');
                $('.f3div').addClass('modal-content');
                $('.f4div').addClass('modal-body');
                $('.more-fix').addClass('more-filterbtn-div pad-0lf');
                $('.header-set').removeClass('header-set');
            } else {
                $('.filterdiv').removeClass('f1div');
                $('#filter-modal').removeClass('modal fade search-modal modal-bg-fff');
                $('.f2div').removeClass('modal-dialog momodel modal-fluid');
                $('.f3div').removeClass('modal-content');
                $('.f4div').removeClass('modal-body');
                $('label').removeClass('click-shape click-price click-color click-carat click-quality');
                $('.more-fix').removeClass('more-filterbtn-div pad-0lf');
            }

            $(document).ready(function () {
                $('.selectpicker').selectpicker('toggle');
            });

            $('.f-click').on({
                'click': function () {
                    // $('.change-image').attr('src','images/product/p1.png');
                    $(this).parent().closest('.find-img').find('.change-image').attr('src', $(this).data('src'));
                    // $(this).toggleClass('active-1');
                    $(this).addClass("active-1").siblings().removeClass("active-1");
                }
            });

        })
        $(function () {
            window.$('.selectpicker').selectpicker('toggle')
            window.addEventListener('scroll', handleScroll, true);

            // Remove the event listener
            return () => {
                window.removeEventListener('scroll', handleScroll, true);
            };
        })



    }, [])

    useEffect(() => {
        filterFun()
    }, [MTresult, DTresult, Wresult, STresult, Presult])


    const filterFun = () => {

        let pricenames = price.filter(o1 => Presult.some(o2 => matchResult.some(o3 => o1.match1 == o2 && o1.match2 == o3)))

        let Diamondnames = diamondType.filter(o1 => DTresult.some(o2 => o2 == o1.id))
        let weightnames = weight.filter(o1 => Wresult.some(o2 => WMatchresult.some(o3 => o1.match1 == o2 && o1.match2 == o3)))

        let settingnames = settingType.filter(o1 => STresult.some(o2 => o1.id == o2))

        let allNames = [margeMT, pricenames, Diamondnames, weightnames, settingnames].flat();

        setAllNames([...allNames])

        let MTData = alljewelleryData?.filter(o1 => MTresult.some(o2 => MTStampResult.some(o3 => o1.metaltype == o2 && o1.metalstamp == o3)));
        let PriceData = alljewelleryData?.filter(o1 => Presult.some(o2 => matchResult.some(o3 => o1.offerprice == null ? o1.price >= o2 && o1.price <= o3 : o1.offerprice >= o2 && o1.offerprice <= o3)));
        let WeightData = alljewelleryData?.filter(o1 => Wresult.some(o2 => WMatchresult.some(o3 => o1.metalweight >= o2 && o1.metalweight <= o3)));
        let DiamondData = alljewelleryData?.filter(o1 => DTresult.some(o2 => o1.jewelry_diamonds.shape == o2));
        let STData = alljewelleryData?.filter(o1 => STresult.some(o2 => o1.settingtype == o2));

        let copyFinal = []

        if (MTData.length > 0 || margeMT?.length > 0) {
            copyFinal.push(MTData)
        };

        if (PriceData.length > 0 || pricenames?.length > 0) {
            copyFinal.push(PriceData)
        }

        if (WeightData.length > 0 || weightnames?.length > 0) {
            copyFinal.push(WeightData)
        }

        if (DiamondData.length > 0 || Diamondnames?.length > 0) {
            copyFinal.push(DiamondData)
        }

        if (STData.length > 0 || settingnames?.length > 0) {
            copyFinal.push(STData)
        }




        let commonResult = copyFinal?.shift()?.filter(function (v) {
            return copyFinal.every(function (a) {
                return a.indexOf(v) !== -1;
            });
        });



        if (commonResult?.length > 0) {
            setJewellryData([...commonResult])
        } else {
            setJewellryData([])
        }
        if (allNames.length == 0) {
            setJewellryData([...alljewelleryData])
        }
    }

    const getJewellryData = () => {
        const baseURL = "https://laravel.weingenious.in/bellamy/api/jewelry/All";
        axios
            .post(baseURL)
            .then((response) => {
                setJewellryData(response.data.data)
                setAllJewellryData(response.data.data)
            });
    }

    const resultMTFun = (e) => {
        var options = e.target.options;
        var value = [];
        var stamp = [];
        let marge = [];
        for (var i = 0, l = options.length; i < l; i++) {
            if (options[i].selected) {
                value.push(options[i].value);
                stamp.push(options[i].id);
                let data = metalStamp.filter(o1 => o1.id1 == options[i].value && o1.id == options[i].id)
                data.map((item, index) => {
                    marge.push({ id: item.id + " " + item.id1, name: item.name + " " + item.name1, type: 'metal' })
                })
            }
        }
        setMargeMT(marge)
        setMTResult(value)
        setMTStampResult(stamp)
    }

    const resultDTFun = (e) => {
        var options = e.target.options;
        var value = [];
        for (var i = 0, l = options.length; i < l; i++) {
            if (options[i].selected) {
                value.push(options[i].value);
            }
        }
        setDTResult(value)
    }

    const resultWFun = (e) => {
        var options = e.target.options;
        var value = [];
        var match = [];
        for (var i = 0, l = options.length; i < l; i++) {
            if (options[i].selected) {
                weight.map((item, index) => {
                    if (item.match1 == options[i].value && item.match2 == options[i].id) {
                        weight[index] = { ...weight[index], flag: true }
                    }
                })
                setWeight([...weight])
                value.push(options[i].value);
                match.push(options[i].id);
            }
        }
        setWResult(value)
        setWMatchResult(match)
    }

    const resultSTFun = (e) => {
        var options = e.target.options;
        var value = [];
        for (var i = 0, l = options.length; i < l; i++) {
            if (options[i].selected) {
                value.push(options[i].value);
            }
        }
        setSTResult(value)
    }

    const resultPFun = (e) => {
        var options = e.target.options;
        var value = [];
        var match = []
        for (var i = 0, l = options.length; i < l; i++) {
            if (options[i].selected) {
                value.push(options[i].value);
                match.push(options[i].id)
            }
        }
        setPResult(value)
        setMatchResult(match)
    }

    const handleSort = ascending => {
        let array = []
        ascending ?
            array = jewellryData.sort((a, b) => (parseFloat(a.offerprice == null ? a.price : a.offerprice) - parseFloat(b.offerprice == null ? b.price : b.offerprice)))
            :
            array = jewellryData.sort((a, b) => (parseFloat(b.offerprice == null ? b.price : b.offerprice) - parseFloat(a.offerprice == null ? a.price : a.offerprice)))
        setJewellryData([...array])
    }

    const sortingFun = (e) => {
        var value = e.target.value
        if (value == 1) {
            handleSort(true)
        } else if (value == 2) {
            handleSort(false)
        } else if (value == 3) {
            let sortedNew = jewellryData.sort((a, b) => moment(a.created_at.replace("\[UTC\]", "")) - moment(b.created_at.replace("\[UTC\]", "")));
            setJewellryData(sortedNew)
        }
    }

    const removeData = (item, index) => {
        let t = item.name;
        const elements = Array.from(document.getElementsByClassName("dropdown-item"));
        elements.map(function (item, i) {
            if (item.childNodes[1].innerText == t) {
                item.click()
            }
        })
        if (allNames[index].type == "metal") {
            let Id = allNames[index].id
            let splitId = Id.split(" ")
            let indexData = jewellryData.findIndex((j => j.metalstamp == splitId[0] && j.metaltype == splitId[1]))
            jewellryData.splice(indexData, 1)
        }
        if (allNames[index].type == "diamond") {
            let indexData = jewellryData.findIndex((j => j.jewelry_diamonds.shape == allNames[index].id))
            jewellryData.splice(indexData, 1)
        }
        if (allNames[index].type == "weight") {
            let indexData = jewellryData.findIndex((j => j.metalweight == allNames[index].id))
            jewellryData.splice(indexData, 1)
            let findWeight = weight.findIndex(e => e.name == allNames[index].name)
            if (findWeight > -1) {
                weight[findWeight] = { ...weight[findWeight], flag: false }
                setWeight([...weight])
            }
        }
        if (allNames[index].type == "setting") {
            let indexData = jewellryData.findIndex((j => j.settingtype == allNames[index].id))
            jewellryData.splice(indexData, 1)
        }
        if (allNames[index].type == "price") {
            let indexData = jewellryData.findIndex((j => j.offerprice == null ? j.price == allNames[index].id : j.offerprice == allNames[index].id))
            jewellryData.splice(indexData, 1)
        }
        allNames.splice(index, 1)
        setAllNames([...allNames])
        if (allNames.length > 0) {
            setJewellryData([...jewellryData])
        } else {
            setJewellryData([...alljewelleryData])
        }
    }

    const removeAllData = () => {
        const elements = Array.from(document.getElementsByClassName("dropdown-item"));
        elements.map(function (item, i) {
            if (item.classList.contains('selected')) {
                item.click()
            }
        })
        setAllNames([])
        setJewellryData(alljewelleryData)
    }

    const handleScroll = () => {
        // var dropdowns = 
        // document.getElementsByClassName("dropdown-menu");
        // console.log("dropdowns",dropdowns);
        // var i;
        // for (i = 0; i < dropdowns.length; i++) {
        //     var openDropdown = dropdowns[i];
        //     console.log("openDropdown",openDropdown.classList);
        //     if (openDropdown.classList.contains('show')) {
        //        openDropdown.classList.remove('show');
        //     }
        // }
    }




    return (
        <div className="mycontainer" >

            <div>
                <div className="container container-main">
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><a href={"/"}><i className="fa fa-home" aria-hidden="true"></i></a></li>
                            <li className="breadcrumb-item"><Link to={"/JewelryTab"}>JewelryTab</Link></li>
                            <li className="breadcrumb-item active" aria-current="page">All</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div>
                <section className="mobile-view-none">
                    <div className="container container-main">
                        <div className="wizard2-steps mb-3">
                            <div className="step wizard2-steps-heading">
                                <div className="node">
                                    <div className="node-skin">
                                        <div className="cont">
                                            <h2 className="nostyle-heading">Build Your Own Ring</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="cyo-bar-step step step-item active-step keep-left">
                                <div className="node" style={{ cursor: 'pointer' }}>
                                    <div className="node-skin">
                                        <div className="pho">
                                            <img src={setting} alt="setting" />
                                        </div><div className="cont">
                                            <div className="action help-tips">
                                                <a href="#" className="td-u bar-action">Choose</a>
                                            </div>
                                            <div className="heading"><h2 className="nostyle-heading">Setting</h2></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="cyo-bar-step step step-item">
                                <div className="node" style={{ cursor: 'pointer' }}>
                                    <div className="node-skin">
                                        <div className="pho">
                                            <img src={diamonds} alt="diamond" />
                                        </div>
                                        <div className="cont">
                                            <div className="action help-tips">
                                                <a href="#" className="td-u bar-action line1-doted-2">0.33-Carat Round Cut</a>
                                            </div>
                                            <div className="heading">
                                                <h2 className="nostyle-heading">Diamond</h2>
                                            </div>
                                            <div className="action double-action">
                                                <a href="#" className="td-u bar-action">View</a>
                                                <a href="#" className="td-u bar-action">Change</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="step step-item invariant-color">
                                <div className="node">
                                    <div className="node-skin">
                                        <div className="pho">
                                            <img src={ring} alt="ring" />
                                        </div>
                                        <div className="cont">
                                            <div className="action help-tips">Choose</div>
                                            <div className="heading"><h2 className="nostyle-heading">Ring Size</h2></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div className='filters-data'>
                <div className="list-filter list-filter-with" id="getFixed">
                    <div style={{ display: 'flex', }} >
                        <div style={{ flex: 1, }} >
                            <select title="Metal Type" className="selectpicker drop-w-200" onChange={resultMTFun} multiple>
                                {metalStamp?.map((item2, index2) => {
                                    return (
                                        <option data-content={"<img src='" + item2?.img + "' className='mr-1' width='23'>" + item2?.name + " " + item2?.name1 + ""} key={index2} id={item2?.id} value={item2?.id1}>{item2?.name} {item2?.name1}</option>
                                    )
                                })}
                            </select>
                            <select title="Diamonds Type" className="selectpicker drop-w-200" id="23" onChange={resultDTFun} multiple>
                                {diamondType?.map((item, index) => {
                                    return (
                                        <option data-content={"<img src='" + item?.img + "' className='mr-1' width='23'>" + item?.name + ""} key={index} value={item?.id}>{item?.name}</option>
                                    )
                                })}
                            </select>
                            <select title="Weight" className="selectpicker drop-w-200" id="24" onChange={resultWFun} multiple>
                                {weight?.map((item, index) => {
                                    return (
                                        <option
                                            //style={{ color: item.flag == undefined || item.flag == false ? 'black' : 'green' }}
                                            key={index} id={item?.match2} value={item?.match1}>{item?.name}</option>
                                    )
                                })}
                            </select>
                            <select title="Setting Type" className="selectpicker drop-w-200" id="25" onChange={resultSTFun} multiple>
                                {settingType?.map((item, index) => {
                                    return (
                                        <option key={index} value={item.id}>{item.name}</option>
                                    )
                                })}
                            </select>
                            <select title="Price" className="selectpicker drop-w-200" id="26" onChange={resultPFun} multiple>
                                {price?.map((item, index) => {
                                    return (
                                        <option key={index} id={item.match2} value={item.match1}>{item.name}</option>
                                    )
                                })}
                            </select>
                        </div>
                        <div style={{ display: 'contents' }}>
                            <select title="Sorting" className="selectpicker drop-w-200" defaultValue={0} id="27" onChange={sortingFun}>
                                <option value={0}>Sorting</option>
                                <option value={1}>Low To High</option>
                                <option value={2}>High To Low</option>
                                <option value={3}>Newest</option>
                            </select>
                        </div>
                    </div>
                    <div className="container container-main">
                        <div className="d-none d-lg-block">
                            <ul className="selcet-filter">
                                <li className="bg-none">
                                    <span style={{ color: '#23282D' }}>Results({jewellryData.length == 0 ? jewellryData.length : jewellryData.length})</span>
                                </li>
                                {allNames.map((item, index) => {
                                    return (
                                        <li key={index}>
                                            <span>{item.name}</span>
                                            <a className="select-span-a hand" onClick={() => removeData(item, index)}>✖</a>
                                        </li>
                                    )
                                })}
                                {allNames.length > 0 ?
                                    <li className="clearall hand">
                                        <a onClick={() => removeAllData()}>Clear all</a>
                                    </li> : null}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <section className="jumbotron pt-3" >
                <div className="container container-main" >
                    <div className="product-page-div">
                        {jewellryData?.map((item, index) => {
                            return (
                                <div key={index} className="product-div find-img">
                                    <div className="product-div-div">
                                        <div className="product-div-box">
                                            <span className="heart-span hand">
                                                <svg width="24" height="21" viewBox="0 0 24 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M6.5 1C3.4629 1 1 3.36095 1 6.27377C1 8.62513 1.9625 14.2057 11.4368 19.8471C11.6065 19.9471 11.8013 20 12 20C12.1987 20 12.3935 19.9471 12.5632 19.8471C22.0375 14.2057 23 8.62513 23 6.27377C23 3.36095 20.5371 1 17.5 1C14.4629 1 12 4.19623 12 4.19623C12 4.19623 9.5371 1 6.5 1Z" stroke="#f1ecf0" strokeOpacity="0.65" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
                                                </svg>
                                            </span>
                                            <div className="product-div-list">
                                                <img src={item.get_default_img.path} style={{ height: '100%', width: '100%' }} onError={(e) => { e.target.onerror = null; e.target.src = imageErrorSrc; e.target.style = 'height:100px;width:100px' }}
                                                    className="inner-img-product change-image" />
                                            </div>
                                            <div className="text-center show-viewbtn">
                                                <h5 className="product-title pt-3 line1-doted-3">
                                                    {item.title}
                                                </h5>
                                                <p className="product-title-price mb-0">
                                                    $ {item.offerprice == null ? item.price : item.offerprice}
                                                </p>
                                                <div className="pt-3 hide-view-btn">
                                                    <Link className="view-details-btn" to={`/JDetails`}>
                                                        <span className="span-link">
                                                            View Details
                                                        </span>
                                                        <span>&nbsp;
                                                            <svg width="8" height="11" viewBox="0 0 8 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 10L6 5.5L1 1" stroke="#23282D" strokeWidth="1.5" strokeLinecap="round" /></svg>
                                                        </span>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </div>
            </section>

            <div className="modal fade mobile-more-filter" id="more-filter" role="dialog">
                <div className="modal-dialog modal-dialog-centered modal-lg">

                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">More Filters</h5>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div className="modal-body">
                            <div className="row">
                                <div className="col-20 col-lg-4">
                                    <p className="m-tit">
                                        Gender
                                    </p>
                                    <div className="max-125-m mCustomScrollbar light">
                                        <ul className="m-ul">
                                            <li>
                                                <label className="chk-filter">Male
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Female
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Other
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="col-20 col-lg-4">
                                    <p className="m-tit">
                                        Category
                                    </p>
                                    <div className="max-125-m mCustomScrollbar light">
                                        <ul className="m-ul">
                                            <li>
                                                <label className="chk-filter">Ring
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Necklace
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Earring
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Pendant
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Solitaire
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Hoop
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Stud
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="col-20 col-lg-4">
                                    <p className="m-tit">
                                        Collection
                                    </p>
                                    <div className="max-125-m mCustomScrollbar light">
                                        <ul className="m-ul">
                                            <li>
                                                <label className="chk-filter">Anniversary
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Birthday
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Wedding
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Enagagement
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Baby Birth
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Valentine
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Mother's Day
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Women's Day
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                            <li>
                                                <label className="chk-filter">Festive Gift
                                                    <input type="checkbox" />
                                                    <span className="checkmark-filter"></span>
                                                </label>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div >
    )
}
