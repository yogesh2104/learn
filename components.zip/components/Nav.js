import React, { useEffect, useState } from "react";
import { Link, NavLink, useNavigate } from 'react-router-dom';


import AOS from 'aos';
import menuclose from '../assets/images/icons/menu-close.svg';
import menuopen from '../assets/images/icons/menu-open.svg';
import logo from '../assets/images/logo-img.svg';
import menuimg1 from '../assets/images/menu-img1.png';
import black from '../assets/images/menu-shape/color/black.png';
import blue from '../assets/images/menu-shape/color/blue.png';
import green from '../assets/images/menu-shape/color/green.png';
import olive from '../assets/images/menu-shape/color/olive.png';
import orange from '../assets/images/menu-shape/color/orange.png';
import pink from '../assets/images/menu-shape/color/pink.png';
import purple from '../assets/images/menu-shape/color/purple.png';
import smoky from '../assets/images/menu-shape/color/smoky.png';
import white from '../assets/images/menu-shape/color/white.png';
import yellow from '../assets/images/menu-shape/color/yellow.png';
import whasscher from '../assets/images/menu-shape/white-shape/asscher.png';
import whcushion from '../assets/images/menu-shape/white-shape/cushion.png';
import whemerald from '../assets/images/menu-shape/white-shape/emerald.png';
import whheart from '../assets/images/menu-shape/white-shape/heart.png';
import whmarquise from '../assets/images/menu-shape/white-shape/marquise.png';
import whoval from '../assets/images/menu-shape/white-shape/oval.png';
import whpear from '../assets/images/menu-shape/white-shape/pear.png';
import whprincess from '../assets/images/menu-shape/white-shape/princess.png';
import whradiant from '../assets/images/menu-shape/white-shape/radiant.png';
import whround from '../assets/images/menu-shape/white-shape/round.png';
import whsquare from '../assets/images/menu-shape/white-shape/square.png';
import startdiamond from '../assets/images/start-diamond.png';
import startring from '../assets/images/start-ring.png';
import { useSelector, useDispatch } from 'react-redux'
import { addToken, logout } from "../reducers/userReducers";
import { fetch2 } from "../helpers/fetch";
import { BASE_URL, GetAPIUrl } from "../API/APIUrl";
import { ShowErrorMessage, ShowMessage } from "../module/Tostify";
import LoadingSpinner from "../module/LoadingSpinner";
import { ToastContainer } from 'react-toastify'
import Cookies from "universal-cookie";
import axios from "axios";
import { SearchModal } from "../module/SearchModal";
import { ButtonMailto, Buttontelto, getAPIHeader, utf8_to_b64 } from "../helpers/Utility";

const $ = window.$;

export default function Nav(props) {



    const user = useSelector((state) => state?.user?.data)
    const token = useSelector((state) => state?.user?.token)
    const [Shapes, setShapes] = useState([])

    const dispatch = useDispatch()

    let navigate = useNavigate();
    const [Loading, setLoading] = useState(false)
    const cookies = new Cookies();
    const [metalType, setMetalType] = useState([])
    const [settingType, setSettingType] = useState([])
    const [diamondType, setDiamondType] = useState([])
    const [IsFilterLoading, setIsFilterLoading] = useState(true);
    const [modalOpen, setModalOpen] = useState(false);

    const [engagmentStyle, setEngagmentStyle] = useState(true);
    const [weddingStyle, SetWeddingStyle] =useState(true);
    const [diamondStyle, SetDiamondStyle] =useState(true);
    const [jewelryStyle, SetJewelryStyle] = useState(true);
    const [aboutStyle, SetAboutStyle] = useState(true)


    const userData = useSelector(state => state.user.data)


    const Remember = cookies.get('email') == undefined ? false : true

    useEffect(() => {
        dispatch(addToken())
        if (Shapes != []) {
            CallFiltersApi()
        }
        CallCategoryListApi()
    }, [])
    const authenticate = async event => {
        event.preventDefault()
        setLoading(true)

        await axios.post(BASE_URL + GetAPIUrl.LOGOUT_URL, null, {
            headers: {
                'Accept': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data?.success == true) {
                    if (Remember == false) {
                        cookies.remove('email', { path: "/" });
                        cookies.remove('password', { path: "/" });
                    }
                    navigate('/Login')
                    dispatch(logout())
                    ShowMessage(response.data.message)
                    setLoading(false)
                    // window.location.pathname = '/Login'

                } else {
                    ShowErrorMessage(response.data.message)
                    setLoading(false)
                }
            }).catch(error => {
                // ShowErrorMessage(error.message)
            }).finally(() => {
                setIsFilterLoading(false)
            })
    }
    const CallFiltersApi = () => {
        axios.get(BASE_URL + GetAPIUrl.JEWELRY_FILTER_URL)
            .then(response => {
                if (response.data.success == true) {
                    setShapes(response.data.data.Shape);

                    setMetalType(response.data.data.Metal_Type)
                    setSettingType(response.data.data.Setting_Type)
                }
            }).catch(error => {
                // ShowErrorMessage(error.message)
            }).finally(() => {
                setIsFilterLoading(false)
            })
    }
    const [subcategoryList, setSubcategoryList] = useState([])

    var activeIds = [2, 5, 6, 8]

    let filteredArray = subcategoryList.filter(function (item) {
        return activeIds.indexOf(item.id) !== -1

    })

    const CallCategoryListApi = async () => {

        await axios.post(BASE_URL + GetAPIUrl.CATEGORY_URL, null, {
            headers: {
                'Accept': 'application/json',
            }
        })
            .then(response => {
                if (response.data.success == true) {
                    setSubcategoryList(response?.data?.data);
                }
            }).catch(error => {
                // ShowErrorMessage(error.message)
            }).finally(() => {

            })
    }

    // const CallCategoryListApi = async () => {

    //     await axios.post(BASE_URL +  ( GetAPIUrl.CATEGORY_URL, {
    //         mode: 'no-cors',
    //         withCredentials: true,
    //         credentials: 'same-origin',
    //         headers: {
    //             'Access-Control-Allow-Origin': '*',
    //             'Accept': 'application/json',
    //             'Content-Type': 'application/json',
    //         }
    //     })
    //         .then(response => {

    //             if (response.data.success == true) {
    //                 setSubcategoryList(response?.data?.data);
    //             }
    //         });


    // }

    const removeStorageData = () => {
        localStorage.removeItem('Subcategory')
        localStorage.removeItem('Shape');
        localStorage.removeItem('MetalType')
        localStorage.removeItem('JewelryId')
        localStorage.removeItem('DiamondId')
        localStorage.removeItem('Category')
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '',SelectedringSize: '', diamondData: '' }]));
    }

    const removeStorageShopAllData = () => {
        localStorage.removeItem('Subcategory')
        localStorage.removeItem('Shape');
        localStorage.removeItem('MetalType')
        localStorage.removeItem('JewelryId')
        localStorage.removeItem('DiamondId')
        localStorage.removeItem('Category')
        localStorage.setItem('All', 'true');
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '',SelectedringSize: '', diamondData: '' }]));
    }

    const addNewKey = () => {
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '',SelectedringSize: '', diamondData: '' }]));
        localStorage.removeItem('Shape');
        localStorage.removeItem('MetalType')
        localStorage.removeItem('All')
        localStorage.removeItem('Subcategory')
    }
    const AddStorageData = (item) => {
        localStorage.setItem('Shape', JSON.stringify([item]));
        // localStorage.removeItem('Shape');
        localStorage.removeItem('Category')
        localStorage.removeItem('MetalType')
        localStorage.removeItem('All')
        localStorage.removeItem('Subcategory')
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '',SelectedringSize: '', diamondData: '' }]));
    }
    const AddMetalStorageData = (item) => {
        localStorage.setItem('MetalType', JSON.stringify([item]));
        localStorage.removeItem('Category')
        localStorage.removeItem('All')
        localStorage.removeItem('Shape')
        localStorage.removeItem('Subcategory')

        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '',SelectedringSize: '', diamondData: '' }]));
        // window.location.reload(false);
    }
    const AddSubcategoryStorageData = (item) => {
        localStorage.setItem('Subcategory', JSON.stringify(item));
        localStorage.removeItem('MetalType')
        localStorage.removeItem('Category')
        localStorage.removeItem('All')
        localStorage.removeItem('Shape')
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '',SelectedringSize: '', diamondData: '' }]));
        // window.location.reload(false);
    }



    $(function () {
        $(".carousel").swipe({
            swipe: function (event, direction, distance, duration, fingerCount, fingerData) {
                if (direction == 'left') $(this).carousel('next');
                if (direction == 'right') $(this).carousel('prev');
            },
            allowPageScroll: "vertical"
        });

        $('[data-aos]').parent().addClass('hideOverflowOnMobile')

        $(document).ready(function () {

            // ------effect tag-------
            AOS.init({
                duration: 500,
                // disable: 'mobile'
            });

            $(".menu-toggle span i").click(function () {
                $(this).toggleClass('fa-times');
                // $(".mobile-header").toggleClass('fix-header');
            });
            $(".menu-toggle").click(function () {
                $(".mobile-header").toggleClass("mobilefix-header");
                // $(this).addClass("fix-header");
            });
        });

        $(window).on('load', function () {
            $("#diamond-shapeslider").owlCarousel({
                dots: false,
                nav: false,
                items: 10,
                responsive: {
                    0: {
                        items: 3
                    },

                    600: {
                        items: 7
                    },

                    1024: {
                        items: 9
                    },

                    1366: {
                        items: 10
                    }
                }
            });
            $("#shape-slider").owlCarousel({
                nav: false,
                dots: false,
                items: 9,
                margin: 30,
                loop: false,
                responsive: {
                    0: {
                        items: 3
                    },

                    600: {
                        items: 5
                    },

                    1024: {
                        items: 7
                    },
                    1200: {
                        items: 9
                    },

                    1366: {
                        items: 9
                    }
                }
            });

            $("#explore-slider").owlCarousel({
                nav: true,
                dots: false,
                items: 4,
                margin: 20,
                loop: true,
                navText: ["<img src='images/explore-slider/left.svg'/>", "<img src='images/explore-slider/right.svg'/>"],
                responsive: {
                    0: {
                        items: 2
                    },

                    600: {
                        items: 3
                    },

                    1024: {
                        items: 4
                    },
                    1200: {
                        items: 4
                    },

                    1366: {
                        items: 4,
                        stagePadding: 40
                    }
                }
            });

            $("#collection-slider").owlCarousel({
                nav: true,
                dots: false,
                items: 4,
                margin: 20,
                loop: true,
                navText: ["<img src='images/explore-slider/left.svg'/>", "<img src='images/explore-slider/right.svg'/>"],
                responsive: {
                    0: {
                        items: 2
                    },

                    600: {
                        items: 2
                    },

                    1024: {
                        items: 3
                    },
                    1200: {
                        items: 3
                    },

                    1366: {
                        items: 3
                    }
                }
            });

            $("#new-arrivals-slider").owlCarousel({
                nav: false,
                dots: false,
                items: 4,
                margin: 20,
                loop: true,
                navText: ["<img src='images/explore-slider/left.svg'/>", "<img src='images/explore-slider/right.svg'/>"],
                responsive: {
                    0: {
                        items: 2
                    },

                    600: {
                        items: 3,
                        stagePadding: 30
                    },

                    1024: {
                        items: 4,
                        stagePadding: 40
                    },
                    1200: {
                        items: 4,
                        stagePadding: 40
                    },

                    1366: {
                        items: 4,
                        stagePadding: 60
                    }
                }
            });



        });

        $(window).on('load', function () {
            $(window).scroll(function () {
                var scroll = $(window).scrollTop();
                if (scroll >= 200) {
                    $("header").addClass("fix-header");
                }
                else {
                    $("header").removeClass("fix-header");
                }
            });

        });

    })
    $(function () {
        $(".dropdown-menu-sel li a").click(function () {
            var selText = $(this).text();
            $(this).parents('.cur-drop').find('.dropdown-toggle1').html(selText + ' <span className="caret"></span>');
        });


        $(".open-search").click(function () {
            $(".search-full").toggleClass("open");
        });

        $(".close-search").click(function () {
            $(".search-full").toggleClass("open");
        });

        $('.carousel').carousel({
            // interval: false,
            interval: false,
        });


        $(".box-filter-desig1").click(function () {
            $(this).toggleClass("selected1-filter");
        });

        $(".toggle-filter-div").on("click", function () {
            $(this).next(".toggle-div").toggle();
            $(this).find(".addright-icon i").toggleClass("fa-plus");
        });


        $(".mob-open-filter").on("click", function () {
            $(".filter-to-left").addClass("active");
        });

        $(".mob-close-filter").on("click", function () {
            $(".filter-to-left").removeClass("active");
        });


        $(document).ready(function () {
            setTimeout(function () {
                $(".loader-test").addClass("in");
            }, 300);
        });


        $(".show-td").click(function () {
            $(".div-toggle").toggle();
            $(".show-td .spanp").toggleClass("fa-angle-up");
            $(".show-td .spanp").toggleClass("fa-angle-down");
            $(this).toggleClass("borbotnone");
        });

        $(".show-certi").click(function () {
            $(".div-toggle-certi").toggle();
            $(".show-certi .spanp").toggleClass("fa-angle-up");
            $(this).toggleClass("borbotnone");
        });



        $(".submenu-edu").hide();
        $(".submenu").hide();

        $(".kml-navgation li").hover(
            function () {
                $(this).addClass("open");
            },
            function () {
                $(this).removeClass("open");
            }
        );


        $(".faq-div").on('click', function () {
            $(".show-div").hide();
            $(".sp").removeClass('fa-minus');
            $(this).next(".show-div").toggle();
            $(this).find(".sp").addClass('fa-plus' ? 'fa-minus' : 'fa-plus');
            // $(this).next().toggleClass('hide-div');
            // alert("hi");
        });


        if ($(window).width() < 900) {
            $(".a-rm").each(function () {
                if ($(this).hasClass("disabled1")) {
                    $(this).removeAttr("href");
                }
            });

            $(".submenu").hide();
            $('.click-menu').click(function () {
                $(this).toggleClass('menu-drop-toggle');
                $(this).next(".submenu").slideToggle();
                $(".submenu-edu").hide();
            });


            $(".submenu-edu").hide();
            $('.click-menu-edu').click(function () {
                $(this).toggleClass('menu-drop-toggle-edu');
                $(this).next(".submenu-edu").slideToggle();
                $(".submenu").hide();
            });

        };




        if ($(window).width() > 1023) {

            $(".menu-hover").click(function () {
                $(".menuifxed").toggle();
                $(".menu-hover").toggleClass("menu-close");
            });

            $(".menuifxed").mouseleave(function () {
                $(this).hide();
                $(".menu-hover").removeClass("menu-close");
                $(".menuli-click").removeClass("active");
            });

            $(".desktop-menu").mouseleave(function () {
                $(".menuifxed").hide();
            });

            $(".menuli-click").hover(function () {
                $(".menuifxed").show();
                $(".menuli-click").removeClass("active");
                $(this).addClass("active");
                var datact = $(this).data('value');
                $(".main-div-menu").hide();
                $("#" + datact).show();
            });
        }

        // if ($(window).width() < 1023) {
        //     $(".mobile-menu-toggle").click(function () {
        //         $(this).next(".mob-menu-div").slideToggle();
        //     });
        // }

        if ($(window).width() < 992) {
            $(".menuifxed").remove();
        }
        if ($(window).width() >= 992) {
            $(".mobmenu-hidein-desktop").remove();
        }
    })
    $(function () {

        $(document).ready(function () {
            $(".menu-hover").click(function () {
                $(".menuifxed").toggle();
                $(".menu-hover").toggleClass("menu-close");
            });

            $(".menuifxed").mouseleave(function () {
                $(this).hide();
                $(".menu-hover").removeClass("menu-close");
            });

            $('.responsive-sld').slick({
                dots: true,
                infinite: true,
                speed: 1000,
                slidesToShow: 1,
                slidesToScroll: 1,
                autoplay: false,
                arrows: false,
                prevArrow: "<button type='button' className='slick-prev pull-left'><i className='fa fa-chevron-left home-slick-arrow' aria-hidden='true'></i></button>",
                nextArrow: "<button type='button' className='slick-next pull-right'><i className='fa fa-chevron-right home-slick-arrow' aria-hidden='true'></i></button>",
            });
        });


        $(document).ready(function () {
            $(window).scroll(function () {
                var scroll = $(window).scrollTop();
                if (scroll >= 1) {
                    $(".header-rc").addClass("fixed");
                    $(".dove-navgation-mobile").addClass("fixed");
                    $(".dove-header").addClass("sticky");
                }
                else {
                    $(".header-rc").removeClass("fixed");
                    $(".dove-header").removeClass("sticky");
                    $(".dove-navgation-mobile").removeClass("fixed");
                }
            });

            var headerHeight = $('.dove-navgation-mobile').outerHeight();
            $('.open-mobile-menu-list').css('top', headerHeight);

            $('.open-m-menu').click(function () {
                $(".open-mobile-menu").toggleClass('active-menu');
                // $(".main-div").toggleClass('open-m-menu');
            });

            $('.click-menu').click(function () {
                $(this).next(".mobile-submenu").slideToggle();
                $(this).toggleClass('bor-bot-0');
                $(this).toggleClass('menu-drop-toggle');
            });

        });

        // $(document).scroll(function () {
        //     $(this).scrollTop() > 500 ? $(".back-to-top").fadeIn() : $(".back-to-top").fadeOut()
        // });
        $(".back-to-top").click(function () {
            return $("html, body").animate({
                scrollTop: 0
            }, 1500), !1
        });


        $(".click-toggle").click(function () {
            $(this).toggleClass('roted-90');
            $(this).next().toggle();
        });


        $(".faq-click-toggle").click(function () {
            $(this).toggleClass('roted-90');
            $(this).parent().toggleClass('active-bg-faq');
            $(this).next().toggle();
        });


        $(".clickselect-li").click(function () {
            $(".clickselect-li").removeClass("active-tab");
            $(this).addClass("active-tab");
            var datact = $(this).data('value');
            $(".main-div").hide();
            $("#" + datact).show();
        });


        $(".menuli-click").hover(function () {
            $(".menuli-click").removeClass("active");
            $(this).addClass("active");
            var datact = $(this).data('value');
            $(".main-div-menu").hide();
            $("#" + datact).show();
        });


        $(".mission-click").click(function () {
            $(".mission-click").removeClass("active-mission");
            $(this).addClass("active-mission");
            var datact = $(this).data('value');
            $(".main-div-mission").hide();
            $("#" + datact).show();
        });



        $(document).ready(function () {
            $(".add-new-address").show();
            $(".coupon_question").click(function () {
                if ($(this).is(":checked")) {
                    $(".add-new-address").show();
                } else {
                    $(".add-new-address").hide();
                }
            });

            $(".add-new-shippingaddress").hide();
            $(".checked-shiping-add").click(function () {
                if ($(this).is(":checked")) {
                    $(".add-new-shippingaddress").hide();
                } else {
                    $(".add-new-shippingaddress").show();
                }
            });
        });


        function PassowrdView(IdCls) {
            if ($('#' + IdCls).attr('type') == 'password') {
                $('#' + IdCls).attr('type', 'text');
                $('.' + IdCls).removeClass('fa-eye');
                $('.' + IdCls).addClass('fa-eye-slash');
            } else {
                $('#' + IdCls).attr('type', 'password');
                $('.' + IdCls).removeClass('fa-eye-slash');
                $('.' + IdCls).addClass('fa-eye');
            }
        }


        $(window).on("load", function () {
            if ($(window).width() < 421) {
                $(".diamond-click-toggle").click(function () {
                    $(this).toggleClass('roted-90');
                    $(this).next().toggle();
                });

                $(".set-filter-click").click(function () {
                    $(this).toggleClass('minus-ico');
                    $(this).next().toggle();
                });
            }
        });

        $(".images-thumb-click-img").click(function () {
            $(".thumb-videos").hide();
            $(".thumb-images").show();
        });

        $(".iframe-video-thumb").click(function () {
            $(".thumb-videos").show();
            $(".thumb-images").hide();
        });


        $(document).ready(function () {
            setTimeout(function () {
                if ($(window).width() > 901) {
                    $("#explore-collection").owlCarousel({
                        nav: false,
                        navText: ["<span>&#8592;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 3,
                        margin: 30,
                        // stagePadding: 210,
                        loop: false,
                        responsive: {
                            0: {
                                items: 2
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 4
                            }
                        }
                    });
                    $("#recommended-items").owlCarousel({
                        nav: true,
                        navText: ["<span>&#10229;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 4,
                        margin: 30,
                        loop: true,
                        responsive: {
                            0: {
                                items: 1
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 4
                            }
                        }
                    });
                    $("#new-arrival").owlCarousel({
                        nav: true,
                        navText: ["<span>&#10229;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 4,
                        margin: 30,
                        loop: true,
                        responsive: {
                            0: {
                                items: 2
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 4
                            }
                        }
                    });
                }
                if ($(window).width() < 900) {
                    $("#explore-collection").owlCarousel({
                        nav: false,
                        navText: ["<span>&#8592;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 3,
                        margin: 15,
                        // stagePadding: 40,
                        loop: false,
                        responsive: {
                            0: {
                                items: 2
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 3
                            }
                        }
                    });

                    $("#recommended-items").owlCarousel({
                        nav: true,
                        navText: ["<span>&#10229;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 4,
                        margin: 15,
                        loop: true,
                        responsive: {
                            0: {
                                items: 2
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 4
                            }
                        }
                    });

                    $("#new-arrival").owlCarousel({
                        nav: true,
                        navText: ["<span>&#10229;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 4,
                        margin: 15,
                        loop: true,
                        responsive: {
                            0: {
                                items: 2
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 4
                            }
                        }
                    });
                }
            }, 100);
        });
    })

    return (
        <>
            {Loading == true &&

                <LoadingSpinner />
            }
            <div className="header-top hide-900">
                <div className="">
                    <div className="top-header-flex">
                        <div className="header-top-ul">
                            <ul>
                                <li>
                                    {/* <a href="#" className="hand top-link">
                                        +91 8160325633
                                    </a> */}
                                    <li>
                                        {/* <a href="#" className="hand top-link">
                                        weingenious@gmail.com
                                    </a> */}
                                        <Buttontelto label=" +91 8160325633" telto="tel:+91 8160325633" />
                                    </li>
                                </li>
                                <li>
                                    {/* <a href="#" className="hand top-link">
                                        weingenious@gmail.com
                                    </a> */}
                                    <ButtonMailto label="weingenious@gmail.com" mailto="mailto:weingenious@gmail.com" />
                                </li>
                                <li>
                                    <a href="#" className="hand top-link f-11 f11-fonts">
                                        Free Shipping, Free Returns
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div>
                            <span className="col-fff">One Day Only! Free Gift on All Purchases.</span>
                        </div>
                        <div className="header-top-ul">
                            <ul>
                                <li>
                                    <a href="#" className="hand top-link" style={{}}>
                                        FAQs
                                    </a>
                                </li>
                                <li>
                                    <a href="#" className="hand top-link" style={{}}>
                                        Support
                                    </a>
                                </li>
                                <li>
                                    <a href="#" className="hand top-link" style={{}}>
                                        Career
                                    </a>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            {/* mobile-header myHeader fix-header */}
            {/* desktop-header myHeader desktop-menu */}
            <header className="mobile-header myHeader" id="myHeader">
                <div className="container-fluid-lg pad-0lf">
                    <nav className="navbar navbar-expand-lg navbar-dark pad-0lf">
                        <div className="pad-lf-10px-mob d-lg-none" style={{ width: "100%" }}>
                            <button className="navbar-toggler menu-toggle" type="button" data-toggle="collapse" data-target="#navbarToggle" aria-controls="navbarToggle" aria-expanded="false" aria-label="Toggle navigation"> <span className="navbar-toggler-icon"><i className="icon-open-menu" aria-hidden="true"></i></span>
                            </button>
                            <a className="navbar-brand d-lg-none" href={process.env.PUBLIC_URL + "/"}>
                                <img src={logo} className="logo-max-170" width="120" height="auto" />
                            </a>
                            <div className="f-mob-right">

                                <a href="#">
                                    <label className="pad-mob-cart-menu mar-b-0">
                                        <svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M16 16L12.4584 12.4521M14.4211 7.71053C14.4211 9.49027 13.7141 11.1971 12.4556 12.4556C11.1971 13.7141 9.49027 14.4211 7.71053 14.4211C5.93078 14.4211 4.22394 13.7141 2.96547 12.4556C1.707 11.1971 1 9.49027 1 7.71053C1 5.93078 1.707 4.22394 2.96547 2.96547C4.22394 1.707 5.93078 1 7.71053 1C9.49027 1 11.1971 1.707 12.4556 2.96547C13.7141 4.22394 14.4211 5.93078 14.4211 7.71053Z" stroke="#4A4A4A" strokeWidth="1.5" strokeLinecap="round" />
                                        </svg>
                                    </label>
                                </a>
                                <a href="#">
                                    <label className="pad-mob-cart-menu mar-b-0">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4A4A4A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                                    </label>
                                </a>
                                <a href="#">
                                    <label className="pad-mob-cart-menu mar-b-0">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4a4a4a" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="feather feather-shopping-cart pe-2"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
                                    </label>
                                </a>
                                <a href="#">
                                    <label className="pad-mob-cart-menu mar-b-0">
                                        <svg width="18" height="18" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M11.5292 9.79296C11.2282 9.11936 10.7914 8.50749 10.2431 7.99146C9.69641 7.47393 9.04886 7.06131 8.33616 6.77638C8.32977 6.77337 8.32339 6.77186 8.31701 6.76884C9.31115 6.09045 9.95742 4.98543 9.95742 3.73869C9.95742 1.67337 8.18616 0 6 0C3.81384 0 2.04258 1.67337 2.04258 3.73869C2.04258 4.98543 2.68885 6.09045 3.68299 6.77035C3.67661 6.77337 3.67023 6.77487 3.66385 6.77789C2.94896 7.06281 2.30747 7.47136 1.75694 7.99297C1.20914 8.5094 0.772382 9.12116 0.470781 9.79447C0.174489 10.4536 0.0146918 11.1604 3.99029e-05 11.8764C-0.000386007 11.8925 0.00260125 11.9085 0.00882574 11.9235C0.0150502 11.9384 0.024386 11.9521 0.0362829 11.9636C0.0481797 11.9751 0.0623971 11.9843 0.0780971 11.9905C0.0937971 11.9968 0.110662 12 0.127699 12H1.08514C1.15535 12 1.2112 11.9472 1.2128 11.8824C1.24471 10.7186 1.73939 9.62864 2.61385 8.80251C3.51863 7.94774 4.72022 7.47739 6 7.47739C7.27978 7.47739 8.48137 7.94774 9.38615 8.80251C10.2606 9.62864 10.7553 10.7186 10.7872 11.8824C10.7888 11.9487 10.8446 12 10.9149 12H11.8723C11.8893 12 11.9062 11.9968 11.9219 11.9905C11.9376 11.9843 11.9518 11.9751 11.9637 11.9636C11.9756 11.9521 11.9849 11.9384 11.9912 11.9235C11.9974 11.9085 12.0004 11.8925 12 11.8764C11.984 11.1558 11.826 10.4548 11.5292 9.79296V9.79296ZM6 6.33166C5.26756 6.33166 4.5782 6.06181 4.05959 5.57186C3.54097 5.08191 3.25534 4.43065 3.25534 3.73869C3.25534 3.04673 3.54097 2.39548 4.05959 1.90553C4.5782 1.41558 5.26756 1.14573 6 1.14573C6.73244 1.14573 7.4218 1.41558 7.94041 1.90553C8.45903 2.39548 8.74466 3.04673 8.74466 3.73869C8.74466 4.43065 8.45903 5.08191 7.94041 5.57186C7.4218 6.06181 6.73244 6.33166 6 6.33166Z" fill="#4A4A4A"></path>
                                        </svg>
                                    </label>
                                </a>
                            </div>
                        </div>
                        <div className="collapse navbar-collapse justify-content-between mobilemenubg mobile-menu" id="navbarToggle" >

                            {/* <Link
                                className="navbar-brand d-none d-lg-block"
                                aria-current="page"
                                style={{ textDecoration: "none" }}

                                to='/'

                            > */}
                            <a href={process.env.PUBLIC_URL + '/'}>
                                <img src={logo} className="logo-max-170 lg-logo" width="200" height="auto" />
                                <img src={logo} className="sm-logo" width="120" height="auto" />
                            </a>

                            {/* </Link> */}
                            <ul className="navbar-nav parent-menu kml-navgation">
                                <li className="nav-item" onClick={()=>setEngagmentStyle(!engagmentStyle)}>
                                    <a className="nav-link hand t-link-primary u-relative menu-drop menuli-click mobile-menu-toggle" data-value="mega-menu1">
                                        Engagment Ring
                                        <span className="caret-mobile"></span>
                                    </a>
                                    <div className="mobile-megamenu main-div-menu mob-menu-div mobmenu-hidein-desktop" style={{ display:engagmentStyle? "none":'' }}>
                                        <div className="container container-menu">
                                            <div className="row desktop-megamenu-list">
                                                <div className="col-lg-3 mb-3">
                                                    <h6 className="desk-top-title"> DESIGN YOUR OWN ENGAGEMENT RING </h6>
                                                    <ul className="menu-ul-list mb-3">
                                                        <li className="li-list" >
                                                            <a
                                                                className="desk-top-title-sm a-taglink"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + `/Jewelry/${utf8_to_b64("21")}`}
                                                            // state={data2}

                                                            >

                                                                <img src={startring} />&nbsp; Start With a Settings


                                                            </a>
                                                        </li>
                                                        <li className="li-list" onClick={() => removeStorageData()} onAuxClick={() => removeStorageData()}>
                                                            <a
                                                                className="desk-top-title-sm a-taglink"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}
                                                                href={process.env.PUBLIC_URL + `/DiamondList/W==/Natural`}

                                                            >
                                                                <img src={startdiamond} alt="start-diamond" />&nbsp; Start with a Diamond</a>
                                                        </li>
                                                        <li className="li-list" onClick={() => removeStorageData()} onAuxClick={() => removeStorageData()}>
                                                            <a
                                                                className="desk-top-title-sm a-taglink"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + `/DiamondList` }

                                                            >
                                                                <img src={startdiamond} alt="start-diamond" />&nbsp; Start with Lab Diamond
                                                            </a>
                                                        </li>
                                                        <li className="li-list" onClick={() => removeStorageShopAllData()} onAuxClick={() => removeStorageShopAllData()}>
                                                            <a
                                                                className="desk-top-title-sm a-taglink"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + '/Jewelry/onlysetting'}

                                                            >
                                                                Buy only Setting (without diamond)
                                                            </a>
                                                        </li>

                                                    </ul>
                                                    <ul className="menu-ul-list mb-3">

                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                <h6 className="desk-top-title">FIND YOUR RING SIZE </h6>
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                <h6 className="desk-top-title">JEWELRY CARE </h6>
                                                            </a>
                                                        </li>



                                                    </ul>
                                                </div>
                                                <div className="col-lg-4 mb-3">
                                                    <div>
                                                        <h6 className="desk-top-title"> SHOP BY SHAPE </h6>
                                                    </div>
                                                    <ul className="menu-ul-list menu-2-left" >
                                                        {Shapes?.map((item, index) => {
                                                            return (
                                                                <li className="li-list" key={index}
                                                                    onAuxClick={() => AddStorageData(item)}
                                                                    onClick={() => AddStorageData(item)}>
                                                                    <a
                                                                        className="desk-top-title-sm a-taglink"
                                                                        aria-current="page"
                                                                        style={{ textDecoration: "none" }}

                                                                        href={process.env.PUBLIC_URL + `/Jewelry/${item?.name}`}
                                                                    >
                                                                        <img src={item?.image} />&nbsp; {item.name}
                                                                    </a>
                                                                </li>
                                                            )
                                                        })}
                                                    </ul>
                                                </div>
                                                <div className="col-lg-2 mb-3">
                                                    <h6 className="desk-top-title"> Shop By Style </h6>
                                                    <ul className="menu-ul-list">
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Solitaire Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Halo Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Pave Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Sidestone Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Three Stone Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Channel Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Bridal Sets </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div className="col-lg-2" >
                                                    <h6 className="desk-top-title">SHOP BY METAL </h6>
                                                    <ul className="menu-ul-list" >

                                                        {metalType?.map((item, index) => {
                                                            return (
                                                                <li className="li-list" key={index}
                                                                    onAuxClick={() => AddMetalStorageData(item)}
                                                                    onClick={() => AddMetalStorageData(item)}>

                                                                    <a
                                                                        className="desk-top-title-sm a-taglink"
                                                                        aria-current="page"
                                                                        style={{ textDecoration: "none" }}

                                                                        href={process.env.PUBLIC_URL + `/Jewelry/${item.name}`}
                                                                    >
                                                                        {item.name}
                                                                    </a>
                                                                </li>
                                                            )
                                                        })}

                                                    </ul>
                                                </div>
                                                <div className="col-lg-2">
                                                    <div>
                                                        <img src={menuimg1} width="100%" height="auto" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li className="nav-item" onClick={()=>SetWeddingStyle(!weddingStyle)} >
                                    <a className="nav-link hand t-link-primary u-relative menu-drop menuli-click mobile-menu-toggle" data-value="mega-menu2">
                                        Wedding Ring
                                        <span className="caret-mobile"></span>
                                    </a>
                                    <div className="mobile-megamenu main-div-menu mob-menu-div mobmenu-hidein-desktop" style={{ display:weddingStyle? "none" :''}}>
                                        <div className="container container-menu">
                                            <div className="row desktop-megamenu-list">
                                                <div className="col-lg-4 mb-3">
                                                    <div>
                                                        <h6 className="desk-top-title"> SHOP BY SHAPE </h6>
                                                    </div>
                                                    <ul className="menu-ul-list menu-2-left" >
                                                        {Shapes?.map((item, index) => {
                                                            return (
                                                                <li className="li-list" key={index}
                                                                    onAuxClick={() => AddStorageData(item)}
                                                                    onClick={() => AddStorageData(item)}>
                                                                    <a
                                                                        className="desk-top-title-sm a-taglink"
                                                                        aria-current="page"
                                                                        style={{ textDecoration: "none" }}

                                                                        href={process.env.PUBLIC_URL + `/Jewelry/${item.name}`}
                                                                    >
                                                                        <img src={item.image} />&nbsp; {item.name}
                                                                    </a>
                                                                </li>
                                                            )
                                                        })}
                                                    </ul>
                                                </div>
                                                <div className="col-lg-2 mb-3">
                                                    <h6 className="desk-top-title"> Shop By Style </h6>
                                                    <ul className="menu-ul-list">
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Solitaire Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Halo Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Pave Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Sidestone Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Three Stone Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Channel Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Bridal Sets </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div className="col-lg-2" >
                                                    <h6 className="desk-top-title">SHOP BY METAL </h6>
                                                    <ul className="menu-ul-list" >

                                                        {metalType?.map((item, index) => {
                                                            return (
                                                                <li className="li-list" key={index}
                                                                    onAuxClick={() => AddMetalStorageData(item)}
                                                                    onClick={() => AddMetalStorageData(item)}>

                                                                    <a
                                                                        className="desk-top-title-sm a-taglink"
                                                                        aria-current="page"
                                                                        style={{ textDecoration: "none" }}

                                                                        href={process.env.PUBLIC_URL + `/Jewelry/${item.name}`}
                                                                    >
                                                                        <span className="title-span"> {item.name}</span>

                                                                    </a>
                                                                </li>
                                                            )
                                                        })}

                                                    </ul>
                                                </div>
                                                <div className="col-lg-2">
                                                    <div>
                                                        <img src={menuimg1} width="100%" height="auto" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li className="nav-item" onClick={()=>SetDiamondStyle(!diamondStyle)} >
                                    <a className="nav-link hand t-link-primary u-relative menu-drop menuli-click mobile-menu-toggle" data-value="mega-menu3">
                                        Diamonds
                                        <span className="caret-mobile"></span>
                                    </a>
                                    <div className="mobile-megamenu main-div-menu mob-menu-div mobmenu-hidein-desktop" style={{ display: diamondStyle?"none":"" }}>
                                        <div className="container container-menu">
                                            <div className="row desktop-megamenu-list">

                                                <div className="col-lg-4 mb-3">
                                                    <h6 className="desk-top-title"> SHOP BY SHAPE </h6>
                                                    <ul className="menu-ul-list menu-2-left" >
                                                        {Shapes?.map((item, index) => {
                                                            return (
                                                                <li className="li-list" key={index}
                                                                    onAuxClick={() => { AddStorageData(item); localStorage.removeItem('Shape'); }}
                                                                    onClick={() => { AddStorageData(item); localStorage.removeItem('Shape'); }}>
                                                                    <a
                                                                        className="desk-top-title-sm a-taglink"
                                                                        aria-current="page"
                                                                        style={{ textDecoration: "none" }}

                                                                        href={process.env.PUBLIC_URL + `/DiamondList/${item.name}`}
                                                                    >
                                                                        <img src={item.image} />&nbsp; {item.name}
                                                                    </a>
                                                                </li>
                                                            )
                                                        })}
                                                    </ul>
                                                </div>
                                                <div className="col-lg-3 mb-3">
                                                    <h6 className="desk-top-title"> CREATE YOUR OWN </h6>
                                                    <ul className="menu-ul-list mb-3">
                                                        <li className="li-list" onClick={() => removeStorageShopAllData()} onAuxClick={() => removeStorageShopAllData()}>
                                                            <a
                                                                className="desk-top-title-sm a-taglink"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + '/Jewelry'}
                                                            >

                                                                <img src={startring} />&nbsp; Start With a Settings
                                                            </a>
                                                        </li>
                                                        <li className="li-list" onClick={() => removeStorageData()} onAuxClick={() => removeStorageData()}>
                                                            <a href={process.env.PUBLIC_URL + '/DiamondList'} className="desk-top-title-sm a-taglink">
                                                                <img src={startdiamond} alt="start-diamond" />&nbsp; Start with a Diamond </a>
                                                        </li>
                                                        <li className="li-list" onClick={() => removeStorageData()} onAuxClick={() => removeStorageData()}>
                                                            <a href={process.env.PUBLIC_URL + '/DiamondList'} className="desk-top-title-sm a-taglink">
                                                                <img src={startdiamond} alt="start-diamond" />&nbsp; Start with a Lab Diamond </a>
                                                        </li>
                                                    </ul>

                                                </div>
                                                <div className="col-lg-2">
                                                    <h6 className="desk-top-title"> EDUCATION </h6>
                                                    <ul className="menu-ul-list mb-3">
                                                        <li className="li-list">
                                                            <a
                                                                className=""
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + '/DiamondList'}

                                                            >
                                                                Diamond Guide
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a
                                                                className=""
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + '/LabGrow'}

                                                            >
                                                                Lab Grown Diamonds
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a
                                                                className=""
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}
                                                                href={process.env.PUBLIC_URL + '/DiamondList'}
                                                            >
                                                                Diamond Sustainabilty

                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a
                                                                className=""
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + '/'}
                                                            >
                                                                Conflict Free Diamonds
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div className="col-lg-2">
                                                    <div>
                                                        <img src={menuimg1} width="100%" height="auto" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li className="nav-item" onClick={()=>SetJewelryStyle(!jewelryStyle)}>
                                    <a className="nav-link hand t-link-primary u-relative menu-drop menuli-click mobile-menu-toggle" data-value="mega-menu4">
                                        Jewelry
                                        <span className="caret-mobile"></span>
                                    </a>
                                    <div className="mobile-megamenu main-div-menu mob-menu-div mobmenu-hidein-desktop" style={{ display: jewelryStyle ? "none" : ""}}>
                                        <div className="container container-menu">
                                            <div className="row desktop-megamenu-list">

                                                <div className="col-lg-2">
                                                    <h6 className="desk-top-title"> Rings </h6>
                                                    <ul className="menu-ul-list">

                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Diamond Rings
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Gold Rings
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Design your Own
                                                            </a>
                                                        </li>


                                                        <li className="li-list" onClick={() => removeStorageShopAllData()} onAuxClick={() => removeStorageShopAllData()}>

                                                            <a
                                                                className="desk-top-title-sm a-taglink"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + '/Jewelry'}
                                                            >  <h6 style={{ fontWeight: 'bold' }}> Shop All </h6>
                                                            </a>
                                                        </li>

                                                    </ul>
                                                    <h6 className="desk-top-title">Bracelets </h6>

                                                    <ul className="menu-ul-list mb-3">
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Diamond Bracelets
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Tennis Bracelets
                                                            </a>
                                                        </li>
                                                        <li className="li-list" onClick={() => removeStorageShopAllData()} onAuxClick={() => removeStorageShopAllData()}>

                                                            <a
                                                                className="desk-top-title-sm a-taglink"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + '/Jewelry'}
                                                            ><h6 style={{ fontWeight: 'bold' }}> Shop All </h6>
                                                            </a>
                                                        </li>


                                                    </ul>
                                                </div>
                                                <div className="col-lg-2">
                                                    <h6 className="desk-top-title"> Earrings </h6>

                                                    <ul className="menu-ul-list mb-3">
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Diamond Earrings
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Stud Earrings
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Hoop Earrings
                                                            </a>
                                                        </li>
                                                        <li className="li-list" onClick={() => removeStorageShopAllData()} onAuxClick={() => removeStorageShopAllData()}>

                                                            <a
                                                                className="desk-top-title-sm a-taglink"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + '/Jewelry'}
                                                            ><h6 style={{ fontWeight: 'bold' }}> Shop All </h6>
                                                            </a>
                                                        </li>


                                                    </ul>
                                                    <h6 className="desk-top-title"> Pendants </h6>
                                                    <ul className="menu-ul-list">
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Design your Own
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Diamond Necklaces
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Gold Necklaces
                                                            </a>
                                                        </li>

                                                        <li className="li-list" onClick={() => removeStorageShopAllData()} onAuxClick={() => removeStorageShopAllData()}>

                                                            <a
                                                                className="desk-top-title-sm a-taglink"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + '/Jewelry'}
                                                            > <h6 style={{ fontWeight: 'bold' }}> Shop All </h6>
                                                            </a>
                                                        </li>

                                                    </ul>



                                                </div>
                                                <div className="col-lg-2">
                                                    <h6 className="desk-top-title"> SILVER JEWELRY </h6>

                                                    <ul className="menu-ul-list">

                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Earrings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Pendants </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Bracelets </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Necklaces </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Gemstone Jewelry </a>
                                                        </li>

                                                        <li className="li-list" onClick={() => removeStorageShopAllData()} onAuxClick={() => removeStorageShopAllData()}>

                                                            <a
                                                                className="desk-top-title-sm a-taglink"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                href={process.env.PUBLIC_URL + '/Jewelry'}
                                                            ><h6 style={{ fontWeight: 'bold' }}> Shop All </h6>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                    <ul className="menu-ul-list mb-3">
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Bespoke Jewelry
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href={process.env.PUBLIC_URL +'/ContactUs'} className="desk-top-title-sm a-taglink">
                                                                Get in touch with us
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div className="col-lg-2">
                                                    <div>
                                                        <img src={menuimg1} width="100%" height="auto" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>


                                <li className="nav-item" onClick={()=>SetAboutStyle(!aboutStyle)}>
                                    <a className="nav-link hand t-link-primary u-relative menu-drop menuli-click mobile-menu-toggle" data-value="mega-menu5">
                                        About us
                                        <span className="caret-mobile"></span>
                                    </a>
                                    <div className="mobile-megamenu main-div-menu mob-menu-div mobmenu-hidein-desktop" style={{ display: aboutStyle? "none":""}}>
                                        <div className="container container-menu">
                                            <div className="row desktop-megamenu-list">
                                                <div className="col-lg-2">
                                                    <h6 className="desk-top-title"> ABOUT US </h6>
                                                    <ul className="menu-ul-list">

                                                        <li className="li-list">
                                                            <a href={process.env.PUBLIC_URL + "/Aboutus"} className="desk-top-title-sm a-taglink">
                                                                Why Diora Adams
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Blogs
                                                            </a>
                                                        </li>

                                                    </ul>
                                                </div>
                                                <div className="col-lg-2">
                                                    <h6 className="desk-top-title"> Diamond Education  </h6>

                                                    <ul className="menu-ul-list">

                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Diamond Guide</a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a  href={process.env.PUBLIC_URL + '/LabGrow'} className="desk-top-title-sm a-taglink"> Lab Grown Diamonds </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Diamond Sustainabilty
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Conflict Free Diamonds
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div className="col-lg-2">
                                                    <h6 className="desk-top-title"> Jewelry Education </h6>

                                                    <ul className="menu-ul-list">

                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Find Your Ring Size </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> JEWELRY CARE </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Lorem Ipsum
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div className="col-lg-2">
                                                    <div>
                                                        <img src={menuimg1} width="100%" height="auto" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li className="nav-item">
                                    <a href={process.env.PUBLIC_URL +'/ContactUs'} className="nav-link hand t-link-primary u-relative mobile-menu-toggle" data-value="mega-menu4">
                                        Get in touch with us
                                        <span className="caret-mobile"></span>
                                    </a>

                                </li>
                            </ul>

                            <ul className="rightsideicon-menu">
                                {/* <div>
                                    <div className="container show-search header_search">
                                        <div className="col-md-12" id="search" style={{padding: "5px 2px 10px 2px"}}>
                                            <button type="button" className="close">×</button>
                                            <form name="SearchForm" autocomplete="off" id="SearchForm" className="centered clearfix">
                                                <input type='text' placeholder='Search here...' className=' search-text' data-min-length='1' list='SearchProducts' name='SearchProduct' id='SearchProduct' />
                                                <datalist id="SearchProducts">
                                                </datalist>
                                            </form>
                                        </div>
                                    </div>
                                </div> */}
                                <li className="nav-item d-none d-lg-block" >
                                    <div className="t-compare search_btn" style={{ textDecoration: "none" }}
                                        onClick={() => {
                                            setModalOpen(true);
                                        }}>
                                        <div className="cart-media">
                                            <div className="cart-icon">
                                                <svg width="17" height="17" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M16 16L12.4584 12.4521M14.4211 7.71053C14.4211 9.49027 13.7141 11.1971 12.4556 12.4556C11.1971 13.7141 9.49027 14.4211 7.71053 14.4211C5.93078 14.4211 4.22394 13.7141 2.96547 12.4556C1.707 11.1971 1 9.49027 1 7.71053C1 5.93078 1.707 4.22394 2.96547 2.96547C4.22394 1.707 5.93078 1 7.71053 1C9.49027 1 11.1971 1.707 12.4556 2.96547C13.7141 4.22394 14.4211 5.93078 14.4211 7.71053Z" stroke="#4A4A4A" strokeWidth="1.5" strokeLinecap="round" />
                                                </svg>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                {token != '' && token != null && token != undefined &&
                                    <>
                                        <li className="nav-item d-none d-lg-block" >
                                            {/* <NavLink
                                        // className="nav-link t"

                                        // aria-current="page"
                                        to={"/Cart"}
                                        // style={{ textDecoration: "none" }}
                                        style={({ isActive }) => ({
                                            color: isActive ? 'greenyellow' : 'white',
                                            textDecoration: "none"
                                        })}> */}
                                            {/* <NavLink to="/Wishlist"
                                        className="nav-link t"
                                        style={({ isActive }) => ({
                                            color: isActive ? '#4A4A4A' : 'black'
                                        })}> */}

                                            <a className="nav-link t" style={{ textDecoration: "none" }} href={process.env.PUBLIC_URL + "/Wishlist"}>

                                                <div className="cart-media">
                                                    <div className="cart-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="20"
                                                            height="20"
                                                            viewBox="0 0 24 24"
                                                            fill="none"
                                                            stroke="#4A4A4A"
                                                            strokeWidth="2"
                                                            strokeLinecap="round"
                                                            strokeLinejoin="round"
                                                            className="feather feather-heart"
                                                        >
                                                            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z">
                                                            </path>
                                                        </svg>
                                                        <span className="label label-theme sm-circle-value rounded-pill addtowishlistCount">{token ? JSON.parse(localStorage.getItem('wishlistcount')) : 0}</span>
                                                    </div>
                                                </div>
                                            </a>
                                            {/* </NavLink> */}
                                            {/* <div style={{ margin: '10px' }}>
                                            <NavLink to="/"
                                                style={({ isActive }) => ({
                                                    color: isActive ? 'greenyellow' : 'white'
                                                })}>
                                                Home
                                            </NavLink>
                                        </div> */}
                                        </li>
                                        <li className="nav-item d-none d-lg-block" >
                                            {/* <NavLink
                                        className="nav-link t"
                                        aria-current="page"
                                        style={{ textDecoration: "none" }}
                                        to={"/Cart"}
                                    > */}
                                            <a className="nav-link t" style={{ textDecoration: "none" }} href={process.env.PUBLIC_URL + "/Cart"}>
                                                <div className="cart-media">
                                                    <div className="cart-icon">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="20"
                                                            height="20" viewBox="0 0 24 24" fill="none"
                                                            stroke="#4A4A4A" strokeWidth="2" strokeLinecap="round"
                                                            strokeLinejoin="round" className="feather feather-shopping-cart pe-2">
                                                            <circle cx="9" cy="21" r="1"></circle>
                                                            <circle cx="20" cy="21" r="1"></circle>
                                                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                                                        </svg>
                                                        <span className="label label-theme sm-circle-value rounded-pill addtocartCount">{token ? JSON.parse(localStorage.getItem('cartcount')) : 0}</span>

                                                    </div>
                                                </div>
                                            </a>
                                            {/* </NavLink> */}
                                            <a href="#" className="t" style={{ textDecoration: "none" }}>


                                            </a>
                                        </li>
                                    </>

                                }
                                {/* <li className="nav-item d-none d-lg-block showsmall-cart cart-dropdown">
                                    <a href="#" className="t" style={{ textDecoration: "none" }}>
                                        <span className="btn-solid-default btn-spacing">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="feather feather-shopping-cart pe-2"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
                                        </span>
                                    </a>
                                </li> */}

                                <li className="nav-item d-none d-lg-block account-list" style={{ marginLeft: 20 }}>
                                    <a className="hand searchbtn btn btn-solid-default btn-spacing t-hov">
                                        <svg width="18" height="18" viewBox="0  0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M11.5292 9.79296C11.2282 9.11936 10.7914 8.50749 10.2431 7.99146C9.69641 7.47393 9.04886 7.06131 8.33616 6.77638C8.32977 6.77337 8.32339 6.77186 8.31701 6.76884C9.31115 6.09045 9.95742 4.98543 9.95742 3.73869C9.95742 1.67337 8.18616 0 6 0C3.81384 0 2.04258 1.67337 2.04258 3.73869C2.04258 4.98543 2.68885 6.09045 3.68299 6.77035C3.67661 6.77337 3.67023 6.77487 3.66385 6.77789C2.94896 7.06281 2.30747 7.47136 1.75694 7.99297C1.20914 8.5094 0.772382 9.12116 0.470781 9.79447C0.174489 10.4536 0.0146918 11.1604 3.99029e-05 11.8764C-0.000386007 11.8925 0.00260125 11.9085 0.00882574 11.9235C0.0150502 11.9384 0.024386 11.9521 0.0362829 11.9636C0.0481797 11.9751 0.0623971 11.9843 0.0780971 11.9905C0.0937971 11.9968 0.110662 12 0.127699 12H1.08514C1.15535 12 1.2112 11.9472 1.2128 11.8824C1.24471 10.7186 1.73939 9.62864 2.61385 8.80251C3.51863 7.94774 4.72022 7.47739 6 7.47739C7.27978 7.47739 8.48137 7.94774 9.38615 8.80251C10.2606 9.62864 10.7553 10.7186 10.7872 11.8824C10.7888 11.9487 10.8446 12 10.9149 12H11.8723C11.8893 12 11.9062 11.9968 11.9219 11.9905C11.9376 11.9843 11.9518 11.9751 11.9637 11.9636C11.9756 11.9521 11.9849 11.9384 11.9912 11.9235C11.9974 11.9085 12.0004 11.8925 12 11.8764C11.984 11.1558 11.826 10.4548 11.5292 9.79296V9.79296ZM6 6.33166C5.26756 6.33166 4.5782 6.06181 4.05959 5.57186C3.54097 5.08191 3.25534 4.43065 3.25534 3.73869C3.25534 3.04673 3.54097 2.39548 4.05959 1.90553C4.5782 1.41558 5.26756 1.14573 6 1.14573C6.73244 1.14573 7.4218 1.41558 7.94041 1.90553C8.45903 2.39548 8.74466 3.04673 8.74466 3.73869C8.74466 4.43065 8.45903 5.08191 7.94041 5.57186C7.4218 6.06181 6.73244 6.33166 6 6.33166Z" fill="#4A4A4A"></path>
                                        </svg>
                                        {userData != null &&
                                            <div style={{ color: 'black' }}>&nbsp;&nbsp;{"hy" + " " + userData?.firstname}</div>
                                        }
                                    </a>

                                    <div className="dropdown-menu dropdown-menu-login" id="user_login">
                                        <div className="dropdown-menu-inner" id="login-dropdown-context" style={{ background: '#fff' }}>
                                            <div id="user_authenticated">
                                                {token != null || token != undefined ?
                                                    <ul className="list-unstyled lh-28 mb15 user-menu-afterlogin">
                                                        <li>
                                                            <a
                                                                className="nav-link t"
                                                                style={{ textDecoration: "none" }}
                                                                aria-current="page"
                                                                href={process.env.PUBLIC_URL + "/Gallery"}
                                                            >Gallery
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a
                                                                className="nav-link t"
                                                                style={{ textDecoration: "none" }}
                                                                aria-current="page"
                                                                href={process.env.PUBLIC_URL + "/Myaccount"}
                                                            >My Account
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href={process.env.PUBLIC_URL + "/"} className="nav-link t" onClick={authenticate}>
                                                                Log Out
                                                            </a>
                                                            {/* <Link
                                                                className="nav-link t"
                                                                style={{ textDecoration: "none" }}
                                                                aria-current="page"
                                                                to={"/"}
                                                            >Log Out
                                                            </Link> */}
                                                            {/* <a href="/SignupB2B">
                                                            Sign up B2B
                                                        </a> */}
                                                        </li>
                                                    </ul>
                                                    :
                                                    <ul className="list-unstyled lh-28 mb15 user-menu-afterlogin">
                                                        <li>
                                                            <a
                                                                className="nav-link t"
                                                                style={{ textDecoration: "none" }}
                                                                aria-current="page"
                                                                href={process.env.PUBLIC_URL + "/Login?Loginid=W@W"}
                                                            >Login
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a
                                                                className="nav-link t"
                                                                style={{ textDecoration: "none" }}
                                                                aria-current="page"
                                                                href={process.env.PUBLIC_URL + "/Gallery"}
                                                            >Gallery
                                                            </a>
                                                        </li>
                                                    </ul>
                                                }
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>

                            <div className="d-lg-none text-center" style={{ padding: 13, display: 'flex' }}>
                                <a href="#" className="text-center mobile-bot-10 shop-now-btn hand Hypatia" style={{ color: "#fff", width: "48%" }}>
                                    Login
                                </a>
                                &nbsp; <a href="#" className="anone text-center mobile-bot-10 shop-now-btn hand Hypatia" style={{ width: "48%" }}>
                                    Sign up
                                </a>
                            </div>
                        </div>

                    </nav>
                </div>
                <div className="menuifxed" style={{ display: "none" }}>
                    <div id="mega-menu1" className="desktop-megamenu main-div-menu" style={{ display: "none" }}>
                        <div className="container container-menu">
                            <div className="row desktop-megamenu-list">
                                <div className="col-lg-2">
                                    <h6 className="desk-top-title"> CREATE YOUR OWN </h6>
                                    <ul className="menu-ul-list mb-3">
                                        <li className="li-list" onAuxClick={() => { addNewKey(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "21" })) }}
                                            onClick={() => { addNewKey(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "21" })) }} >
                                            <a
                                                className="desk-top-title-sm a-taglink"
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}
                                                href={process.env.PUBLIC_URL + `/Jewelry/${utf8_to_b64("21")}`}
                                            // state={data2}
                                            // 
                                            >
                                                <img src={startring} />&nbsp; Start with a Setting
                                            </a>
                                            {/* <a href="#" className="desk-top-title-sm a-taglink">
                                                <img src={startring} alt="start-ring" />&nbsp; Start with a Setting </a> */}
                                        </li>

                                        <li className="li-list" onAuxClick={() => { removeStorageData(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "21" })) }}
                                            onClick={() => { removeStorageData(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "21" })) }}>
                                            <a
                                                className="desk-top-title-sm a-taglink"
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}

                                                href={process.env.PUBLIC_URL + `/DiamondList/W==/Natural`}

                                            >
                                                <img src={startdiamond} alt="start-diamond" />&nbsp; Start with a Diamond</a>
                                        </li>
                                        <li className="li-list" onAuxClick={() => { removeStorageData(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "21" })) }}
                                            onClick={() => { removeStorageData(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "21" })) }}>
                                            <a
                                                className="desk-top-title-sm a-taglink"
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}

                                                href={process.env.PUBLIC_URL + `/DiamondList`}

                                            >
                                                <img src={startdiamond} alt="start-diamond" />&nbsp; Start with Lab Diamond
                                            </a>
                                        </li>
                                        <li className="li-list" onAuxClick={() => { removeStorageShopAllData(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "21" })) }}
                                            onClick={() => { removeStorageShopAllData(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "21" })) }}>
                                            <a
                                                className="desk-top-title-sm a-taglink"
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}

                                                href={process.env.PUBLIC_URL + '/Jewelry/onlysetting'}

                                            >
                                                Buy only Setting (without diamond)
                                            </a>
                                        </li>

                                    </ul>
                                    <ul className="menu-ul-list mb-3">

                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                <h6 className="desk-top-title">FIND YOUR RING SIZE </h6>
                                            </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                <h6 className="desk-top-title">JEWELRY CARE </h6>
                                            </a>
                                        </li>

                                        {/*   <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                New Arrivals
                                            </a>
                                        </li> */}

                                    </ul>
                                </div>
                                <div className="col-lg-2">
                                    <h6 className="desk-top-title"> SHOP BY SHAPE </h6>
                                    <ul className="menu-ul-list menu-2-left" >
                                        {Shapes?.map((item, index) => {
                                            return (
                                                <li className="li-list" key={index}
                                                    onAuxClick={() => { AddStorageData(item); localStorage.setItem('Category', JSON.stringify({ categoryName: "Shape", categoryId: "21" })) }}
                                                    onClick={() => { AddStorageData(item); localStorage.setItem('Category', JSON.stringify({ categoryName: "Shape", categoryId: "21" })) }}
                                                >
                                                    <a
                                                        className="desk-top-title-sm a-taglink"
                                                        aria-current="page"
                                                        style={{ textDecoration: "none" }}

                                                        href={process.env.PUBLIC_URL + `/Jewelry/${item.name}`}
                                                    >
                                                        <img className="shapeImg" src={item.image} />&nbsp; {item.name}
                                                    </a>
                                                </li>
                                            )
                                        })}
                                    </ul>
                                </div>
                                <div className="col-lg-2" >
                                    <h6 className="desk-top-title">SHOP BY STYLE </h6>
                                    <ul className="menu-ul-list">
                                        {subcategoryList?.map((item, index) => {
                                            let selected = []
                                            if (item.id == "21") {
                                                selected = item.subcategory
                                            }
                                            return (
                                                <div className="item" key={index}>

                                                    {selected.map((tag) => {
                                                        // console.log("tag",tag);
                                                        return (
                                                            <li className="li-list" key={index} onClick={() => { AddSubcategoryStorageData(tag); localStorage.setItem('Category', JSON.stringify({ categoryName: "Category", categoryId: item?.id })) }}
                                                                onAuxClick={() => { AddSubcategoryStorageData(tag); localStorage.setItem('Category', JSON.stringify({ categoryName: "Category", categoryId: item?.id })) }}>
                                                                <a href={process.env.PUBLIC_URL + `/Jewelry/${tag?.name}`} className="desk-top-title-sm a-taglink"> {tag?.name} </a>
                                                            </li>
                                                        )
                                                    })
                                                    }

                                                </div>
                                            )
                                        })
                                        }



                                    </ul>
                                </div>

                                <div className="col-lg-2" >
                                    <h6 className="desk-top-title">SHOP BY METAL </h6>
                                    <ul className="menu-ul-list" >

                                        {metalType?.map((item, index) => {
                                            return (
                                                <li className="li-list" key={index}
                                                    onAuxClick={() => { AddMetalStorageData(item); localStorage.setItem('Category', JSON.stringify({ categoryName: "Metal", categoryId: "21" })) }}
                                                    onClick={() => { AddMetalStorageData(item); localStorage.setItem('Category', JSON.stringify({ categoryName: "Metal", categoryId: "21" })) }}>

                                                    <a
                                                        className="desk-top-title-sm a-taglink"
                                                        aria-current="page"
                                                        style={{ textDecoration: "none" }}

                                                        href={process.env.PUBLIC_URL + `/Jewelry/${item.name}`}
                                                    >
                                                        {item.name}
                                                    </a>
                                                </li>
                                            )
                                        })}

                                    </ul>
                                </div>
                                <div className="col-lg-2">
                                    <div>
                                        <img src={menuimg1} width="100%" height="auto" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="mega-menu2" className="desktop-megamenu main-div-menu" style={{ display: "none" }}>
                        <div className="container container-menu">

                            <div className="row desktop-megamenu-list">
                                <div className="col-lg-4">
                                    <h6 className="desk-top-title"> SHOP BY SHAPE </h6>
                                    <ul className="menu-ul-list menu-2-left" >
                                        {Shapes?.map((item, index) => {
                                            return (
                                                <li className="li-list" key={index}
                                                    onAuxClick={() => { AddStorageData(item); localStorage.setItem('Category', JSON.stringify({ categoryName: "Shape", categoryId: "41" })) }}
                                                    onClick={() => { AddStorageData(item); localStorage.setItem('Category', JSON.stringify({ categoryName: "Shape", categoryId: "41" })) }}>
                                                    <a
                                                        className="desk-top-title-sm a-taglink"
                                                        aria-current="page"
                                                        style={{ textDecoration: "none" }}

                                                        href={process.env.PUBLIC_URL + `/Jewelry/${item.name}`}
                                                    >
                                                        <img className="shapeImg" src={item.image} />&nbsp; {item.name}
                                                    </a>
                                                </li>
                                            )
                                        })}
                                    </ul>
                                </div>
                                <div className="col-lg-2">
                                    <h6 className="desk-top-title"> SHOP BY STYLE </h6>
                                    <ul className="menu-ul-list">
                                        {subcategoryList?.map((item, index) => {
                                            let selected = []
                                            if (item.id == "41") {
                                                selected = item.subcategory
                                            }
                                            return (
                                                <div className="item" key={index}>

                                                    {selected.map((tag) => {
                                                        // console.log("tag",tag);
                                                        return (
                                                            <li className="li-list" key={index} onClick={() => { AddSubcategoryStorageData(tag); localStorage.setItem('Category', JSON.stringify({ categoryName: "Category", categoryId: item?.id })) }}
                                                                onAuxClick={() => { AddSubcategoryStorageData(tag); localStorage.setItem('Category', JSON.stringify({ categoryName: "Category", categoryId: item?.id })) }}>
                                                                <a href={process.env.PUBLIC_URL + `/Jewelry/${tag?.name}`} className="desk-top-title-sm a-taglink"> {tag?.name} </a>
                                                            </li>
                                                        )
                                                    })
                                                    }



                                                </div>
                                            )
                                        })
                                        }

                                        <li className="li-list" onClick={() => { removeStorageShopAllData(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "41" })) }}
                                            onAuxClick={() => { removeStorageShopAllData(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "41" })) }}>

                                            <a
                                                className="desk-top-title-sm a-taglink"
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}
                                                href={process.env.PUBLIC_URL + '/Jewelry'}
                                            > <h6 style={{ fontWeight: 'bold' }}> Shop All </h6>
                                            </a>
                                        </li>
                                    </ul>
                                    <ul className="menu-ul-list mb-3">

                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                <h6 className="desk-top-title">FIND YOUR RING SIZE </h6>
                                            </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                <h6 className="desk-top-title">JEWELRY CARE </h6>
                                            </a>
                                        </li>

                                        {/*   <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                New Arrivals
                                            </a>
                                        </li> */}

                                    </ul>
                                </div>
                                <div className="col-lg-2" >
                                    <h6 className="desk-top-title">SHOP BY METAL </h6>
                                    <ul className="menu-ul-list" >

                                        {metalType?.map((item, index) => {
                                            return (
                                                <li className="li-list" key={index}
                                                    onAuxClick={() => { AddMetalStorageData(item); localStorage.setItem('Category', JSON.stringify({ categoryName: "Metal", categoryId: "41" })) }}
                                                    onClick={() => { AddMetalStorageData(item); localStorage.setItem('Category', JSON.stringify({ categoryName: "Metal", categoryId: "41" })) }}>

                                                    <a
                                                        className="desk-top-title-sm a-taglink"
                                                        aria-current="page"
                                                        style={{ textDecoration: "none" }}

                                                        href={process.env.PUBLIC_URL + `/Jewelry/${item.name}`}
                                                    >
                                                        {item.name}
                                                    </a>
                                                </li>
                                            )
                                        })}

                                    </ul>
                                </div>

                                <div className="col-lg-2">
                                    <div>
                                        <img src={menuimg1} width="100%" height="auto" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="mega-menu3" className="desktop-megamenu main-div-menu" style={{ display: "none" }}>
                        <div className="container container-menu">
                            <div className="row desktop-megamenu-list">

                                <div className="col-lg-4">
                                    <h6 className="desk-top-title"> SHOP BY SHAPE </h6>
                                    <ul className="menu-ul-list menu-2-left" >
                                        {Shapes?.map((item, index) => {
                                            return (
                                                <li className="li-list" key={index}
                                                    onAuxClick={() => { AddStorageData(item); localStorage.removeItem('Shape'); localStorage.setItem('Category', JSON.stringify({ categoryName: "All", categoryId: "" })) }}
                                                    onClick={() => { AddStorageData(item); localStorage.removeItem('Shape'); localStorage.setItem('Category', JSON.stringify({ categoryName: "All", categoryId: "" })) }}>
                                                    <a
                                                        className="desk-top-title-sm a-taglink"
                                                        aria-current="page"
                                                        style={{ textDecoration: "none" }}

                                                        href={process.env.PUBLIC_URL + `/DiamondList/${utf8_to_b64(item?.id)}`}
                                                    >
                                                        <img className="shapeImg" src={item.image} />&nbsp; {item.name}
                                                    </a>
                                                </li>
                                            )
                                        })}
                                    </ul>
                                </div>
                                <div className="col-lg-2">
                                    <h6 className="desk-top-title"> CREATE YOUR OWN </h6>
                                    <ul className="menu-ul-list mb-3">
                                        <li className="li-list" onAuxClick={() => { removeStorageData(); }}
                                            onClick={() => { removeStorageData(); }}>
                                            <a
                                                className="desk-top-title-sm a-taglink"
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}

                                                href={process.env.PUBLIC_URL + '/DiamondList/W==/Natural'}
                                                // state={{ fromDashboard: false }}
                                                onAuxClick={() => addNewKey()}
                                                onClick={() => addNewKey()}
                                            >
                                                <img src={startdiamond} alt="start-diamond" />&nbsp; Start with a Diamond</a>

                                        </li>
                                        <li className="li-list" onAuxClick={() => { removeStorageData(); }}
                                            onClick={() => { removeStorageData(); }}>
                                            <a
                                                className="desk-top-title-sm a-taglink"
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}

                                                href={process.env.PUBLIC_URL + `/DiamondList`}
                                            // state={{ fromDashboard: false }}
                                            >
                                                <img src={startdiamond} alt="start-diamond" />&nbsp; Start with Lab Diamond
                                            </a>
                                        </li>
                                        <li className="li-list" onAuxClick={() => addNewKey()} onClick={() => addNewKey()}>

                                            <a href={process.env.PUBLIC_URL + '/Jewelry'} style={{ textDecoration: "none" }} className="desk-top-title-sm a-taglink">
                                                <img src={startring} />&nbsp; Start with a Setting
                                            </a>

                                            {/* <a href="#" className="desk-top-title-sm a-taglink">
                                                <img src={startring} alt="start-ring" />&nbsp; Start with a Setting </a> */}
                                        </li>



                                    </ul>
                                </div>
                                <div className="col-lg-2">
                                    <h6 className="desk-top-title"> EDUCATION </h6>
                                    <ul className="menu-ul-list mb-3">
                                        <li className="li-list">
                                            <a
                                                className=""
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}

                                                href={process.env.PUBLIC_URL + '/DiamondList'}

                                            >
                                                Diamond Guide
                                            </a>
                                        </li>
                                        <li className="li-list">
                                            <a
                                                className=""
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}

                                                href={process.env.PUBLIC_URL + '/LabGrow'}

                                            >
                                                Lab Grown Diamonds
                                            </a>
                                        </li>
                                        <li className="li-list">
                                            <a
                                                className=""
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}

                                                href={process.env.PUBLIC_URL + '/DiamondList'}
                                            // state={data2}

                                            >
                                                Diamond Sustainabilty

                                            </a>
                                            {/* <a href="#" className="desk-top-title-sm a-taglink">
                                                <img src={startring} alt="start-ring" />&nbsp; Start with a Setting </a> */}
                                        </li>
                                        <li className="li-list">
                                            <a
                                                className=""
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}

                                                href={process.env.PUBLIC_URL + '/'}

                                            >
                                                Conflict Free Diamonds
                                            </a>
                                        </li>


                                    </ul>
                                </div>

                                <div className="col-lg-2">
                                    <div>
                                        <img src={menuimg1} width="100%" height="auto" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="mega-menu4" className="desktop-megamenu main-div-menu" style={{}}>
                        <div className="container container-menu">
                            <div className="row desktop-megamenu-list">
                                <div className="row col-lg-6">
                                    {
                                        filteredArray?.map((item, index) => {
                                            return (
                                                <div className="col-lg-6" key={index}>
                                                    <h6 className="desk-top-title"> {item?.name} </h6>
                                                    <ul className="menu-ul-list">

                                                        <div className="item" key={index} >

                                                            {item.subcategory.map((tag, i) => {
                                                                // console.log("tag",tag);
                                                                return (
                                                                    <li className="li-list" key={i} onClick={() => {
                                                                        // removeStorageData(item)
                                                                        removeStorageShopAllData();
                                                                        localStorage.setItem('Category', JSON.stringify({ categoryName: tag?.name, categoryId: tag?.id }))
                                                                    }}
                                                                        onAuxClick={() => {
                                                                            // removeStorageData(item)
                                                                            removeStorageShopAllData();
                                                                            localStorage.setItem('Category', JSON.stringify({ categoryName: tag?.name, categoryId: tag?.id }))
                                                                        }}>
                                                                        <a
                                                                            className="desk-top-title-sm a-taglink"
                                                                            aria-current="page"
                                                                            style={{ textDecoration: "none" }}
                                                                            href={process.env.PUBLIC_URL + `/Jewelry/${tag?.name}`}
                                                                        >{tag?.name}</a>
                                                                    </li>
                                                                )
                                                            })
                                                            }
                                                            <li className="li-list" onClick={() => {
                                                                removeStorageShopAllData()
                                                                localStorage.setItem('Category', JSON.stringify({ categoryName: item?.name, categoryId: item?.id }))
                                                            }}
                                                                onAuxClick={() => {
                                                                    removeStorageShopAllData()
                                                                    localStorage.setItem('Category', JSON.stringify({ categoryName: item?.name, categoryId: item?.id }))
                                                                }} >
                                                                <a
                                                                    className="desk-top-title-sm a-taglink"
                                                                    aria-current="page"
                                                                    style={{ textDecoration: "none" }}

                                                                    href={process.env.PUBLIC_URL + `/Jewelry/${item?.name}`}
                                                                ><h6 style={{ fontWeight: 'bold' }}> Shop All </h6>
                                                                </a>
                                                            </li>
                                                        </div>
                                                    </ul>
                                                </div>

                                            )
                                        })
                                    }
                                </div>
                                <div className="col-lg-3">
                                    <h6 className="desk-top-title">SILVER JEWELRY </h6>

                                    <ul className="menu-ul-list">

                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink"> Rings </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink"> Earrings </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink"> Pendants </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink"> Bracelets </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink"> Necklaces </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink"> Gemstone Jewelry </a>
                                        </li>

                                        <li className="li-list" onClick={() => removeStorageShopAllData()} onAuxClick={() => removeStorageShopAllData()}>

                                            <a
                                                className="desk-top-title-sm a-taglink"
                                                aria-current="page"
                                                style={{ textDecoration: "none" }}

                                                to={process.env.PUBLIC_URL + '/Jewelry'}
                                            ><h6 style={{ fontWeight: 'bold' }}> Shop All </h6>
                                            </a>
                                        </li>
                                    </ul>
                                    <ul className="menu-ul-list mb-3">
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                Bespoke Jewelry
                                            </a>
                                        </li>
                                        <li className="li-list">
                                            <a href={process.env.PUBLIC_URL +'/ContactUs'} className="desk-top-title-sm a-taglink">
                                                Get in touch with us
                                            </a>
                                        </li>
                                    </ul>

                                </div>
                                <div className="row col-lg-3">
                                    <img src={menuimg1} width="100%" height="auto" />
                                </div>
                                {/* <div className="col-lg-2">
                                                    <h6 className="desk-top-title"> SILVER JEWELRY </h6>

                                                    <ul className="menu-ul-list">

                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Rings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Earrings </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Pendants </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Bracelets </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Necklaces </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink"> Gemstone Jewelry </a>
                                                        </li>

                                                        <li className="li-list" onClick={() => removeStorageShopAllData()} >

                                                            <Link
                                                                className="desk-top-title-sm a-taglink"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}

                                                                to='/Jewelry'
                                                            ><h6 style={{ fontWeight: 'bold' }}> Shop All </h6>
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                    <ul className="menu-ul-list mb-3">
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Bespoke Jewelry
                                                            </a>
                                                        </li>
                                                        <li className="li-list">
                                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                                Get in touch with us
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div className="col-lg-2">
                                                    <div>
                                                        <img src={menuimg1} width="100%" height="auto" />
                                                    </div>
                                                </div> */}
                            </div>

                        </div>
                    </div>
                    <div id="mega-menu5" className="desktop-megamenu main-div-menu" style={{ display: "none" }}>
                        <div className="container container-menu">
                            <div className="row desktop-megamenu-list">
                                <div className="col-lg-2">
                                    <h6 className="desk-top-title"> ABOUT US </h6>
                                    <ul className="menu-ul-list">

                                        <li className="li-list">
                                            <a href={process.env.PUBLIC_URL + "/Aboutus"} className="desk-top-title-sm a-taglink">
                                                Why Diora Adams
                                            </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                Blogs
                                            </a>
                                        </li>

                                    </ul>
                                </div>
                                <div className="col-lg-2">
                                    <h6 className="desk-top-title"> Diamond Education  </h6>

                                    <ul className="menu-ul-list">

                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink"> Diamond Guide</a>
                                        </li>
                                        <li className="li-list">
                                            <a href={process.env.PUBLIC_URL + '/LabGrow'} className="desk-top-title-sm a-taglink"> Lab Grown Diamonds </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                Diamond Sustainabilty
                                            </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                Conflict Free Diamonds
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div className="col-lg-2">
                                    <h6 className="desk-top-title"> Jewelry Education </h6>

                                    <ul className="menu-ul-list">

                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink"> Find Your Ring Size </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink"> JEWELRY CARE </a>
                                        </li>
                                        <li className="li-list">
                                            <a href="#" className="desk-top-title-sm a-taglink">
                                                Lorem Ipsum
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <div className="col-lg-2">
                                    <div>
                                        <img src={menuimg1} width="100%" height="auto" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </header >

            <div className="mobile-menu">
                <div id="bellamy-navgation-mobile" className="bellamy-navgation-mobile bellamy-header-wrapper">
                    <div className="navbar">
                        <div className="navbar-header">

                            <div className="item">
                                <button type="button" className="navbar-toggle open-m-menu menu-hover" id="hamburger">

                                    <img src={menuopen} className="menu-i" height="30" />
                                    <img src={menuclose} className="close-i" height="30" />
                                </button>
                            </div>
                            <div className="item">
                                <a id="header-telephone-xs" className="phone_click" href="#" style={{ display: 'flex', alignItems: 'center' }}>
                                    <svg width="16" height="19" viewBox="0 0 13 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2.22109 0.370488L3.14473 0.0926834C3.65071 -0.0598927 4.19491 -0.0231635 4.6758 0.196017C5.15669 0.415198 5.5414 0.801856 5.75816 1.28384L6.47206 2.87152C6.65842 3.2861 6.71032 3.74861 6.62047 4.19417C6.53062 4.63974 6.30353 5.04599 5.97106 5.35594L4.78861 6.45845C4.75404 6.49066 4.73215 6.53418 4.72687 6.58113C4.69205 6.89534 4.90495 7.50715 5.39566 8.35798C5.75262 8.97611 6.07633 9.41063 6.35097 9.65361C6.5425 9.82377 6.64777 9.86018 6.69288 9.84752L8.28373 9.36076C8.71817 9.22788 9.18331 9.23427 9.61394 9.37904C10.0446 9.52382 10.4191 9.79971 10.685 10.1681L11.6989 11.5737C12.0072 12.0012 12.15 12.526 12.1006 13.0507C12.0513 13.5755 11.8132 14.0645 11.4306 14.4269L10.7294 15.0918C10.3572 15.4442 9.90008 15.6943 9.40256 15.8176C8.90503 15.9409 8.38406 15.9332 7.89037 15.7954C5.71067 15.1868 3.75654 13.3474 2.00581 10.3153C0.25271 7.27921 -0.36226 4.6642 0.204431 2.46946C0.331996 1.97585 0.584561 1.52342 0.937783 1.15578C1.29101 0.788142 1.73297 0.517688 2.22109 0.370488ZM2.56379 1.50783C2.27101 1.59604 2.00587 1.75816 1.79392 1.97857C1.58197 2.19898 1.43034 2.47025 1.35364 2.76626C0.877178 4.61196 1.4225 6.93017 3.03393 9.72167C4.64298 12.5092 6.3755 14.1396 8.21012 14.6525C8.50624 14.735 8.81866 14.7394 9.11699 14.6653C9.41532 14.5913 9.6894 14.4413 9.91257 14.2299L10.6146 13.565C10.7886 13.4002 10.8968 13.1779 10.9192 12.9393C10.9417 12.7007 10.8767 12.4621 10.7365 12.2678L9.72341 10.863C9.60252 10.6953 9.43217 10.5698 9.23628 10.5039C9.04039 10.4381 8.82879 10.4352 8.63118 10.4957L7.03638 10.9841C6.11036 11.2595 5.26982 10.5147 4.36755 8.95158C3.7597 7.89892 3.47636 7.08371 3.5468 6.44975C3.584 6.1205 3.73675 5.81657 3.97894 5.59021L5.16139 4.4877C5.31258 4.34683 5.41586 4.16216 5.45674 3.9596C5.49762 3.75704 5.47405 3.54676 5.38933 3.35828L4.67543 1.77059C4.57691 1.55168 4.40215 1.37606 4.18372 1.27646C3.9653 1.17685 3.71811 1.16007 3.48823 1.22923L2.56379 1.50783Z" fill="black" />
                                    </svg>
                                </a>
                            </div>
                            <div className="item item-logo">
                                <div id="site-logo">
                                    <a href="index.html" aria-label="Home">
                                        <img width="110" alt="Logo Image" src={logo} />
                                    </a>
                                </div>
                            </div>

                            <div className="item">
                                <a href="#">
                                    <svg width="18" height="16" viewBox="0 0 16 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M4.5 1C2.5673 1 1 2.49112 1 4.33081C1 5.81587 1.6125 9.34047 7.6416 12.9034C7.7496 12.9666 7.87358 13 8 13C8.12642 13 8.2504 12.9666 8.3584 12.9034C14.3875 9.34047 15 5.81587 15 4.33081C15 2.49112 13.4327 1 11.5 1C9.5673 1 8 3.01867 8 3.01867C8 3.01867 6.4327 1 4.5 1Z" stroke="black" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
                                    </svg>
                                </a>
                            </div>

                            <div className="item">
                                <a href="#">
                                    <svg width="20" height="20" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.2486 7.9856L13.9941 3.88612C14.0037 3.83311 14.0016 3.77863 13.9878 3.72653C13.9741 3.67443 13.9491 3.62599 13.9145 3.58462C13.88 3.54326 13.8368 3.50998 13.788 3.48714C13.7392 3.46431 13.686 3.45247 13.6321 3.45246H3.63729L3.31946 1.70484C3.28358 1.50702 3.17936 1.32809 3.02499 1.19927C2.87062 1.07045 2.6759 0.99992 2.47483 1H1.36793C1.27035 1 1.17676 1.03876 1.10776 1.10775C1.03876 1.17674 1 1.2703 1 1.36787C1 1.46543 1.03876 1.559 1.10776 1.62799C1.17676 1.69698 1.27035 1.73574 1.36793 1.73574H2.47477C2.5035 1.7357 2.53134 1.74576 2.55342 1.76416C2.57549 1.78256 2.59039 1.80814 2.59551 1.83641L4.29164 11.1642C4.05181 11.3575 3.87309 11.616 3.77708 11.9087C3.68106 12.2013 3.67187 12.5154 3.7506 12.8132C3.82933 13.1109 3.99262 13.3795 4.22073 13.5864C4.44884 13.7934 4.73202 13.9298 5.03603 13.9793C5.34004 14.0288 5.65188 13.9891 5.93386 13.8652C6.21583 13.7413 6.45588 13.5384 6.62498 13.281C6.79409 13.0236 6.88501 12.7227 6.88677 12.4148C6.88853 12.1068 6.80105 11.8049 6.63489 11.5456H10.3274C10.1369 11.8438 10.0511 12.1969 10.0835 12.5493C10.116 12.9017 10.2648 13.2332 10.5065 13.4917C10.7482 13.7501 11.0691 13.9208 11.4186 13.9767C11.768 14.0326 12.1262 13.9707 12.4365 13.8006C12.7469 13.6305 12.9917 13.3619 13.1326 13.0373C13.2734 12.7127 13.3021 12.3504 13.2143 12.0076C13.1264 11.6649 12.9269 11.3611 12.6473 11.1442C12.3676 10.9274 12.0237 10.8097 11.6698 10.8099H4.97518L4.66306 9.09313H11.9214C12.2373 9.09326 12.5433 8.98245 12.7859 8.78003C13.0284 8.5776 13.1922 8.29644 13.2486 7.9856ZM6.15095 12.404C6.15095 12.5737 6.1006 12.7397 6.00627 12.8808C5.91194 13.022 5.77786 13.132 5.62099 13.197C5.46412 13.262 5.29151 13.2789 5.12498 13.2458C4.95844 13.2127 4.80547 13.131 4.68541 13.0109C4.56535 12.8909 4.48359 12.7379 4.45046 12.5714C4.41734 12.4049 4.43434 12.2323 4.49932 12.0755C4.56429 11.9186 4.67433 11.7846 4.81551 11.6903C4.95668 11.5959 5.12266 11.5456 5.29246 11.5456C5.52006 11.5459 5.73827 11.6364 5.89922 11.7973C6.06016 11.9582 6.15069 12.1764 6.15095 12.404ZM12.5283 12.404C12.5283 12.5737 12.478 12.7397 12.3836 12.8808C12.2893 13.022 12.1552 13.132 11.9984 13.197C11.8415 13.262 11.6689 13.2789 11.5023 13.2458C11.3358 13.2127 11.1828 13.131 11.0628 13.0109C10.9427 12.8909 10.861 12.7379 10.8278 12.5714C10.7947 12.4049 10.8117 12.2323 10.8767 12.0755C10.9417 11.9186 11.0517 11.7846 11.1929 11.6903C11.3341 11.5959 11.5 11.5456 11.6698 11.5456C11.8974 11.5459 12.1156 11.6364 12.2766 11.7973C12.4375 11.9582 12.5281 12.1764 12.5283 12.404ZM3.77109 4.1882H13.1912L12.5246 7.85403C12.499 7.99531 12.4246 8.1231 12.3143 8.2151C12.204 8.3071 12.065 8.35746 11.9214 8.35739H4.5292L3.77109 4.1882Z" fill="black" />
                                    </svg>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
                <div className="open-mobile-menu">
                    <div id="mobile-menu-id" className="open-mobile-menu-list">
                        <ul className="ul-menu-list">
                            <li className="list">
                                <a className="alist click-menu menu-drop" href="index.html">
                                    Home
                                </a>
                            </li>
                            <li className="list">
                                <a className="alist click-menu menu-drop">
                                    ENGAGEMENT RINGS <span className="caret-mobile"></span>
                                </a>
                                <div className="mobile-submenu" style={{ display: 'none' }}>
                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                DESIGN YOUR OWN ENGAGEMENT RING
                                            </h6>
                                        </div>
                                        <ul>
                                            <li>
                                                <a
                                                    className="desk-top-title-sm a-taglink"
                                                    aria-current="page"
                                                    style={{ textDecoration: "none" }}

                                                    href={process.env.PUBLIC_URL + '/Jewelry'}
                                                // state={data2}

                                                >
                                                    <img src={startring} />&nbsp; Start With a Settings
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    <img src={startdiamond} />&nbsp; Start with a NATURAL DIAMOND
                                                </a>
                                            </li>

                                        </ul>
                                    </div>

                                    <div>
                                        <div>
                                            <h6 className="desk-top-title"> SHOP BY SHAPE </h6>
                                        </div>
                                        <ul className="menu-ul-list menu-2-left" >
                                            {Shapes?.map((item, index) => {
                                                return (
                                                    <li className="li-list" key={index}
                                                        onAuxClick={() => AddStorageData(item)}
                                                        onClick={() => AddStorageData(item)}>
                                                        <a
                                                            className="desk-top-title-sm a-taglink"
                                                            aria-current="page"
                                                            style={{ textDecoration: "none" }}

                                                            href={process.env.PUBLIC_URL + `/Jewelry/${item.name}`}
                                                        >
                                                            <img className="shapeImg" src={item.image} />&nbsp; {item.name}
                                                        </a>
                                                    </li>
                                                )
                                            })}
                                        </ul>

                                    </div>
                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                Shop By Stylessss
                                            </h6>
                                        </div>
                                        <ul>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    SOLITAIRE RINGS
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    HALO RINGS
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    HIDDEN HALO RINGS
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    PAVÉ RINGS
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    SIDESTONE RINGS
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    THREE STONE RINGS
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    CHANNEL RINGS
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    BRIDAL SETS
                                                </a>
                                            </li>

                                        </ul>
                                    </div>

                                </div>
                            </li>
                            <li className="list">
                                <div>
                                    <h6 className="submenu-main-title">
                                        Shop By Style
                                    </h6>
                                </div>
                                <ul className="menu-ul-list" >

                                    {metalType?.map((item, index) => {
                                        return (
                                            <li className="li-list" key={index}
                                                onAuxClick={() => AddStorageData(item)}
                                                onClick={() => AddStorageData(item)}>

                                                <a
                                                    className="alist-sub"
                                                    aria-current="page"
                                                    style={{ textDecoration: "none" }}

                                                    href={process.env.PUBLIC_URL + `/Jewelry/${item.name}`}
                                                >
                                                    {item.name}
                                                </a>
                                            </li>
                                        )
                                    })}

                                </ul>
                            </li>

                            <li className="list">
                                <a className="alist click-menu menu-drop">
                                    WEDDING RINGS <span className="caret-mobile"></span>
                                </a>
                                <div className="mobile-submenu" style={{ display: 'none' }}>
                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                WOMEN'S RINGS
                                            </h6>
                                        </div>
                                        <ul>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    CLASSIC
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    DIAMOND
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    ANNIVERSARY
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    ETERNITY
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    STACKABLES
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    BEZEL
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    PAVE
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    CHANNEL
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    SPECIAL
                                                </a>
                                            </li>
                                        </ul>
                                    </div>

                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                MEN'S RINGS
                                            </h6>
                                        </div>
                                        <ul>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    CLASSIC
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    DIAMOND
                                                </a>
                                            </li>
                                        </ul>
                                    </div>

                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                METAL TYPE
                                            </h6>
                                        </div>
                                        <ul>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    WHITE GOLD 14K
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    WHITE GOLD 18K
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    YELLOW GOLD 14K
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    YELLOW GOLD 18K
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    ROSE GOLD 14K
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    ROSE GOLD 18K
                                                </a>
                                            </li>
                                            <li>
                                                <a className="alist-sub">
                                                    PLATINUM
                                                </a>
                                            </li>
                                        </ul>
                                    </div>

                                </div>
                            </li>

                            <li className="list">
                                <a className="alist click-menu menu-drop">
                                    DIAMONDS <span className="caret-mobile"></span>
                                </a>
                                <div className="mobile-submenu" style={{ display: 'none' }}>
                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                <a href="#">
                                                    SHOP NATURAL DIAMOND
                                                </a>
                                            </h6>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                <a href="#">
                                                    SHOP LAB DIAMONDS
                                                </a>
                                            </h6>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                <a href="#">
                                                    SHOP COLOR DIAMONDS
                                                </a>
                                            </h6>
                                        </div>
                                    </div>
                                    <div>
                                        <div>
                                            <h6 className="desk-top-title"> SHOP BY SHAPE </h6>
                                        </div>
                                        <ul className="menu-ul-list menu-2-left" >
                                            {Shapes?.map((item, index) => {
                                                return (
                                                    <li className="li-list" key={index}
                                                        onAuxClick={() => AddStorageData(item)}
                                                        onClick={() => AddStorageData(item)}>
                                                        <a
                                                            className="desk-top-title-sm a-taglink"
                                                            aria-current="page"
                                                            style={{ textDecoration: "none" }}

                                                            href={process.env.PUBLIC_URL + `/Jewelry/${item.name}`}
                                                        >
                                                            <img className="shapeImg" src={item.image} />&nbsp; {item.name}
                                                        </a>
                                                    </li>
                                                )
                                            })}
                                        </ul>
                                    </div>

                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                Shop By Color
                                            </h6>
                                        </div>
                                        <ul>
                                            <li className="li-list">
                                                <a href="#" className="desk-top-title-sm a-taglink">
                                                    <img src={white} />&nbsp; White
                                                </a>
                                            </li>
                                            <li className="li-list">
                                                <a href="#" className="desk-top-title-sm a-taglink">
                                                    <img src={yellow} />&nbsp; Yellow
                                                </a>
                                            </li>
                                            <li className="li-list">
                                                <a href="#" className="desk-top-title-sm a-taglink">
                                                    <img src={purple} />&nbsp; Purple
                                                </a>
                                            </li>
                                            <li className="li-list">
                                                <a href="#" className="desk-top-title-sm a-taglink">
                                                    <img src={smoky} />&nbsp; Smoky
                                                </a>
                                            </li>
                                            <li className="li-list">
                                                <a href="#" className="desk-top-title-sm a-taglink">
                                                    <img src={pink} />&nbsp; Pink
                                                </a>
                                            </li>
                                            <li className="li-list">
                                                <a href="#" className="desk-top-title-sm a-taglink">
                                                    <img src={orange} />&nbsp; Orange
                                                </a>
                                            </li>
                                            <li className="li-list">
                                                <a href="#" className="desk-top-title-sm a-taglink">
                                                    <img src={olive} />&nbsp; Olive
                                                </a>
                                            </li>
                                            <li className="li-list">
                                                <a href="#" className="desk-top-title-sm a-taglink">
                                                    <img src={green} />&nbsp; Green
                                                </a>
                                            </li>
                                            <li className="li-list">
                                                <a href="#" className="desk-top-title-sm a-taglink">
                                                    <img src={blue} />&nbsp; Blue
                                                </a>
                                            </li>
                                            <li className="li-list">
                                                <a href="#" className="desk-top-title-sm a-taglink">
                                                    <img src={black} />&nbsp; Black
                                                </a>
                                            </li>
                                        </ul>
                                    </div>

                                </div>
                            </li>

                            <li className="list">
                                <a className="alist click-menu menu-drop">
                                    JEWELRY <span className="caret-mobile"></span>
                                </a>
                                <div className="mobile-submenu" style={{ display: 'none' }}>
                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                Shop Jewelry
                                            </h6>
                                        </div>
                                        <ul>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    Rings
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    Earrings
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    Pendant
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    Bracelets
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    Rings
                                                </a>
                                            </li>
                                        </ul>
                                    </div>

                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                CREATE YOUR OWN
                                            </h6>
                                        </div>
                                        <ul>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    Diamond Ring
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    Diamond Earrings
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    Diamond PENDANT
                                                </a>
                                            </li>
                                        </ul>
                                    </div>

                                    <div>
                                        <div>
                                            <h6 className="submenu-main-title">
                                                EARRING COLLECTION
                                            </h6>
                                        </div>
                                        <ul>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    DIAMOND EARRINGS
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    VINTAGE EARRINGS
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    HOOP EARRINGS
                                                </a>
                                            </li>
                                            <li>
                                                <a href="diamond.html" className="alist-sub">
                                                    FASHION EARRINGS
                                                </a>
                                            </li>
                                        </ul>
                                    </div>

                                </div>
                            </li>

                            <li className="list">
                                <a className="alist">
                                    ABOUT US
                                </a>
                            </li>
                        </ul>
                        <div className="pt-5">
                            <div className="text-center">
                                <a className="mobile-login-btn">
                                    Sign Up
                                </a>
                                <a className="mobile-login-btn">
                                    Login
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <ToastContainer />
            {modalOpen && <SearchModal setOpenModal={setModalOpen} />}
        </>
    );
}

