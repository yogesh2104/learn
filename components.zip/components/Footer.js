import axios from "axios";
import React, { useState } from "react";
import { BASE_URL, GetAPIUrl } from "../API/APIUrl";
import logo from '../assets/images/logo-img.svg'
import { ShowErrorMessage, ShowMessage } from "../module/Tostify";



const $ = window.$;

export default function Nav(props) {
    const [email, setEmail] = useState('')

    const CallEmailApi = async () => {
        let data = {
            "email": email
        }
        await axios.post(BASE_URL + GetAPIUrl.HOME_SUBSCRIBE_URL, data, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            }
        }).then(response => {
            console.log("response", response);

            if (response.data.success == true) {
                ShowMessage(response.data.message)
            } else {
                ShowErrorMessage(response.errors.email)
            }
        }).catch(error => {
            ShowErrorMessage(error.response.data.errors.email[0])
        })
    }

    return (
        <div>
            <section className="footer jumbotron footer-border">
                <div className="container insta-container">
                    <div className="row">
                        <div className="col-lg-7 col-sm-12">
                            <div className="row">
                                <div className="col-lg-4 col-sm-4">
                                    <div className="mobile-mb-30 text-center mob-left-right-auto" style={{ maxWidth: '75%' }}>
                                        <img src={logo} width="130" />
                                        <div className="pt-4">
                                            <div className="footer-social so-icon-none">
                                                <p>
                                                    <a href="#">
                                                        <i className="fa fa-instagram" aria-hidden="true"></i>
                                                    </a>
                                                    <a href="#">
                                                        <i className="fa fa-facebook-square" aria-hidden="true"></i>
                                                    </a>
                                                    <a href="#">
                                                        <i className="fa fa-twitter" aria-hidden="true"></i>
                                                    </a>
                                                    <a href="#">
                                                        <i className="fa fa-pinterest-p" aria-hidden="true"></i>
                                                    </a>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-4 col-sm-4">
                                    <div className="mobile-mb-30">
                                        <label className="footer-title text-upp">About Us</label>
                                        <ul className="footer-ul">
                                            <li>
                                                <a href="#">
                                                    Our Story
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Why Diora Adams
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Careers
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Blog
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Shipping Policy
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    FAQs
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Delivery & Returns
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Give Us Your Feedback
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="col-lg-4 col-sm-4">
                                    <div className="mobile-mb-30">
                                        <label className="footer-title text-upp">Shop Online</label>
                                        <ul className="footer-ul">
                                            <li>
                                                <a href="#">
                                                    Engagement Rings
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Wedding
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Jewellery
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Bespoke
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Loose Diamonds
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Consult With An Expert
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Ready To Wear
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <div className="col-lg-5  col-sm-12">
                            <div className="row">
                                <div className="col-lg-6 col-sm-6">
                                    <div>
                                        <label className="footer-title text-upp">Guides & Education</label>
                                        <ul className="footer-ul">
                                            {/* <li>
                                                <a href="#">
                                                    Engagement Ring Guide
                                                </a>
                                            </li> */}
                                            <li>
                                                <a href="#">
                                                    Diamond Guide
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Jewellry Care
                                                </a>
                                            </li>
                                            {/* <li>
                                                <a href="#">
                                                    Coloured Gemstone Guide
                                                </a>
                                            </li> */}
                                            <li>
                                                <a href="#">
                                                    Lab-grown Diamond Guide
                                                </a>
                                            </li>
                                        </ul>

                                    </div>
                                </div>
                                <div className="col-lg-6 col-sm-6">
                                    <div>
                                        <label className="footer-title text-upp">CONTACT US</label>
                                        <ul className="footer-ul">
                                            <li>
                                                <a href="#">
                                                    Book Virtual Appointment
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    9898989898
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Email Us
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Live Chat
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    Track Your Order
                                                </a>
                                            </li>
                                        </ul>

                                    </div>
                                </div>
                            </div>
                            <div className="offer-input-div mobile-mt-30">
                                <label className="footer-title text-upp">GET EXCLUSIVE OFFERS AND NEWS</label>
                                <div>
                                    <input className="submit-input" placeholder="Your Email"
                                        type="text" name=""
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                    />
                                    <button onClick={() => CallEmailApi()} className="btn submit-btn">Subscribe</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div className="last-footer-div">
                <div className="container">
                    <div>
                        ©2022 Diora Adams All Rights Reserved | Developed &amp; Managed by <a className="white-link" target="_blank" href="https://www.weingenious.com">Weingenious Technocrats.</a>
                    </div>
                </div>
            </div>
        </div>
    );
}

