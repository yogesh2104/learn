import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link, Navigate, useNavigate } from 'react-router-dom'

import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import { BASE_URL, GetAPIUrl } from '../API/APIUrl'
import { Colors } from '../constant/Constant'
import { fetch2 } from '../helpers/fetch'
import LoadingSpinner from '../module/LoadingSpinner'
import { ShowErrorMessage, ShowMessage } from '../module/Tostify'
import { signupB2CUser } from '../reducers/userReducers'


const Signup = ({ authorized }) => {

    const [firstName, setFirstName] = useState('')
    const [lastName, setLastName] = useState('')
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    const [confirmPassword, setConfirmPassword] = useState('')
    const [showPassShow, setShowPassShow] = useState(false)
    const [showConfiPassShow, setShowConfiPassShow] = useState(false)

    const dispatch = useDispatch()
    const userDetails = useSelector(state => state.user)
    const [SignupData, setSignupData] = useState([])
    let navigate = useNavigate();
    const [Loading, setLoading] = useState(false)

    const authenticate = async event => {
        event.preventDefault()
        setLoading(true)
        // dispatch(signupB2CUser({ firstName, lastName, email, password, confirmPassword }))
        let data = {
            "firstname": firstName,
            "lastname": lastName,
            "email": email,
            "password": password,
            "confirm_password": confirmPassword,
        }
        const result = await fetch2(BASE_URL + GetAPIUrl.B2CSIGNUP_URL, data, userDetails.token)
        if (result?.success == true) {
            navigate('/Login')
            setLoading(false)
        } else {
            ShowErrorMessage(result.message)
            setSignupData(result.errors)
            setLoading(false)
        }
    }
    if (authorized) {
        return <Navigate to={process.env.PUBLIC_URL + "/"} />;
    }
    return (
        <>
            {Loading == true &&

                <LoadingSpinner />
            }

            <div>
                <div className="container container-main">
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item">
                                <Link to={'/'}><i className="fa fa-home" aria-hidden="true"></i></Link>
                            </li>
                            <li className="breadcrumb-item active" aria-current="page">Signup</li>
                        </ol>
                    </nav>
                </div>
            </div>

            <section className="jumbotron">
                <div className="limiter">
                    <div className="container-login100">
                        <div className="wrap-login100">
                            <form className="login100-form validate-form">
                                <span className="login100-form-title p-b-34">Sign Up</span>
                                <div className="">
                                    <div className="row pad-col-5">
                                        <div className="col-xl-6">
                                            <div className="form-group">
                                                <label className="lblmy lblmy-active">First Name</label>
                                                <input
                                                    value={firstName}
                                                    onChange={e => setFirstName(e.target.value)}
                                                    type="text" className="form-control my-textbox" placeholder="Enter First Name" />
                                                <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                    {SignupData.firstname != undefined && SignupData?.firstname?.map((key, i) => key)}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="col-xl-6">
                                            <div className="form-group">
                                                <label className="lblmy">Last Name</label>
                                                <input
                                                    value={lastName}
                                                    onChange={e => setLastName(e.target.value)}
                                                    type="text" className="form-control my-textbox" placeholder="Enter Last Name" />
                                                <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                    {SignupData.lastname != undefined && SignupData?.lastname?.map((key, i) => key)}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="col-xl-12">
                                            <div className="form-group">
                                                <label className="lblmy">Email Id</label>
                                                <input
                                                    value={email}
                                                    onChange={e => setEmail(e.target.value)}
                                                    type="text"
                                                    className="form-control my-textbox"
                                                    placeholder="Enter Email Id" />
                                                <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                    {SignupData.email != undefined && SignupData?.email?.map((key, i) => key)}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="col-xl-12">
                                            <div className="form-group">
                                                <label className="lblmy">Password</label>
                                                <input
                                                style={{ font: showPassShow && "small-caption", }}
                                                    value={password}
                                                    type={showPassShow ? "text" : 'password'}
                                                    id="showpassword"
                                                    onChange={e => setPassword(e.target.value)}
                                                    className="form-control my-textbox" placeholder="Enter Password" />
                                                <span className="show-pass hand" title={showPassShow ? "show password" : "Hide password"} onClick={() => setShowPassShow(!showPassShow)}
                                                    style={{ paddingLeft: 5, paddingRight: 5 }} >
                                                    <i className={showPassShow ? "fa fa-eye-slash" : 'fa fa-eye showpassword'} aria-hidden="true"></i>
                                                </span>
                                                <p style={{ color: Colors.red, height: 15, padding: 4 }}>

                                                    {SignupData.password != undefined && SignupData?.password?.map((key, i) => key)}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="col-xl-12">
                                            <div className="form-group">
                                                <label className="lblmy">Confirm Password</label>
                                                <input
                                                    style={{ font: showConfiPassShow && "small-caption", }}
                                                    value={confirmPassword}
                                                    type={showConfiPassShow ? "text" : 'password'}
                                                    id="showconfipassword"
                                                    onChange={e => setConfirmPassword(e.target.value)}
                                                    className="form-control my-textbox" placeholder="Enter Confirm Password" />
                                                <span className="show-pass hand" title={showConfiPassShow ? "show password" : "Hide password"} onClick={() => setShowConfiPassShow(!showConfiPassShow)}
                                                    style={{ paddingLeft: 5, paddingRight: 5 }} >
                                                    <i className={showConfiPassShow ? "fa fa-eye-slash" : 'fa fa-eye showpassword'} aria-hidden="true"></i>
                                                </span>
                                                <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                    {SignupData.confirm_password != undefined && SignupData?.confirm_password?.map((key, i) => key)}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="col-xl-12 text-center">
                                            <br />
                                            <button onClick={authenticate}
                                                className="login-me btn-shadow-me min-w-200"
                                            >Sign up</button>
                                        </div>
                                        <div className="w-100">
                                            <div className="col-xl-12 mt-2">
                                                <p className="text-center" style={{ fontWeight: "600" }}>
                                                    {"Have an account ?" + " "}
                                                    <Link
                                                        className="login-link"
                                                        aria-current="page"
                                                        to={'/Login'}
                                                    >
                                                        Log in
                                                    </Link>
                                                </p>
                                            </div>
                                            <div className="col-xl-12 mt-2">
                                                <p className="text-center" style={{ fontWeight: "600" }}>
                                                    {" Own a Business ?" + " "}
                                                    <Link
                                                        className="login-link"
                                                        aria-current="page"
                                                        to={'/SignupB2B'}
                                                    >
                                                        Register here
                                                    </Link>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div className="login100-more d-none d-xl-block d-lg-block" style={{ backgroundImage: `url('./assets/images/login/login-banner.jpg')` }}></div>
                        </div>
                    </div>
                </div>
            </section>
            <ToastContainer />
        </>
    )
}

export default Signup