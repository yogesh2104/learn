import axios from 'axios'
import { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { Link, useLocation, useParams } from 'react-router-dom'
import { ToastContainer } from 'react-toastify'
import { BASE_URL, GetAPIUrl } from '../API/APIUrl'
import callimg from '../assets/images/icons/callimg.png'
import email from '../assets/images/icons/emailimg.png'
import hours from '../assets/images/icons/hoursimg.png'
import p1 from '../assets/images/product-details/thumb/p1.jpg'
import LoadingSpinner from '../module/LoadingSpinner'
import { ShowErrorMessage, ShowMessage } from '../module/Tostify'
import noimage from "../assets/images/product-details/noimage.jpg";
import { b64_to_utf8, BASENAME, utf8_to_b64 } from '../helpers/Utility'
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
import { CallCartCountApi } from '../reducers/userReducers'
import { Colors } from '../constant/Constant'

const $ = window.$;

export default function JewellryDetails() {
    const location = useLocation();


    let { jid, slug } = useParams();

    const JewelryId = jid == undefined ? "" : b64_to_utf8(jid)
    const DiamondId = localStorage.getItem('DiamondId')



    const token = useSelector((state) => state?.user?.token)
    // let { slug } = useParams();

    const [jewelryDetail, setjewelryDetail] = useState('')
    const [jewelryVariants, setjewelryVariants] = useState([])
    const [ringSize, setRingSize] = useState([])
    const [SelectedringSize, setSelectedRingSize] = useState('')
    const [Category, setCategory] = useState(localStorage.getItem('Category') ? JSON.parse(localStorage.getItem('Category')) : '')

    const [defaultVariant, setDefaultVariant] = useState('')
    const [selectedImage, setselectedImage] = useState('')
    const [recommended, setRecommended] = useState([])
    const [message, setmessage] = useState(false)

    // const Images = location?.state?.jewelryData?.images
    // const get_default_img = location?.state?.jewelryData?.get_default_img

    // console.log("Images", Images);

    const [IsLoading, setIsLoading] = useState(false)
    const [IsWishlistLoading, setIsWishlistLoading] = useState(false)
    const [IsCartLoading, setIsCartLoading] = useState(false)


    const selectionFun = (item, index) => {
        const object = jewelryDetail.zoom.find(obj => obj.id === item.id);
        setselectedImage(object)
    }
    const selectVariant = (item, index) => {
        setDefaultVariant(item.metal_type.id)
        setjewelryDetail(item)
        setselectedImage(item.default)
        FromSetting?.map(tag => {
            localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: item, SelectedringSize: SelectedringSize, diamondData: tag.diamondData }]))
        })
        resetZoom()
    }


    const FromSetting = JSON.parse(localStorage.getItem('FromSetting'))

    if (FromSetting == null) {

        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '', SelectedringSize: SelectedringSize, diamondData: '' }]));
    }
    useEffect(() => {
        FromSetting?.map((tag, i) => {
            return (
                setSelectedRingSize(tag?.SelectedringSize == '' ? '' : tag?.SelectedringSize)
            )
        })
        CalljewelryDetailApi()
        // setselectedImage(location?.state?.jewelryData?.get_default_img)
    }, [])

    const CalljewelryDetailApi = async () => {
        const controller = new AbortController();

        setIsLoading(true)
        await axios.get(BASE_URL + GetAPIUrl.JEWELRYDETAIL_URL + `/${JewelryId}`)
            .then(response => {
                if (response.data.success == true) {
                    setRecommended(response?.data?.data?.recommended)
                    setselectedImage(response?.data?.data?.default)
                    setjewelryDetail(response?.data?.data);
                    setjewelryVariants(response?.data?.data?.variants);
                    setDefaultVariant(response?.data?.data?.metal_type?.id)

                    setRingSize(response?.data?.data?.ringSize);
                } else {
                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                ShowErrorMessage(error.message)
            }).finally(() => {
                setIsLoading(false)
            })
        controller.abort()
    }



    const addNewKey = (item) => {
        FromSetting?.map((tag) => {
            // localStorage.setItem('JewelryId', item.id)
            localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: item, SelectedringSize: tag?.SelectedringSize, diamondData: tag.diamondData }]))
            window.location.reload(false);

        })

    }


    let dataFlow = FromSetting?.map(item => item?.jewelryData != '' && item?.diamondData != '')
    const [getAllData, setGetAllData] = useState(JSON.parse(localStorage.getItem('All')) ? JSON.parse(localStorage.getItem('All')) : '')

    const removeStorageData = () => {
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '', SelectedringSize: '', diamondData: '' }]));
    }

    const Cartvalidation = () => {
        if (SelectedringSize == '') {
            setmessage(true)

        } else {
            setmessage(false)
        }
        if (SelectedringSize != '') {
            FromSetting?.map((tag) => {
                localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: tag.jewelryData, SelectedringSize: SelectedringSize, diamondData: tag.diamondData }]))
            })
            CallAddtoCart()
        }
    }

    const CallAddtoCart = async () => {
        setIsCartLoading(true)
        const controller = new AbortController();
        let DiamondId = FromSetting?.map(item => { return item?.diamondData?.id })

        var form = new FormData();
        form.append("jewelryid", JewelryId == null ? "" : JewelryId);
        form.append("diamondid", DiamondId == null ? "" : DiamondId);
        form.append("ringsize", SelectedringSize.id)

        await axios.post(BASE_URL + GetAPIUrl.ADDTOCART_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.success == true) {
                    ShowMessage(response.data.message)
                    CallCartCountApi(token)
                    setmessage(false)
                    // window.location.pathname = '/Cart'
                } else {
                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                ShowErrorMessage(error.message)
            }).finally(() => {
                setIsCartLoading(false)
            })
        controller.abort()
    }

    const validation = () => {
        if (SelectedringSize == '') {
            setmessage(true)

        } else {
            setmessage(false)
        }
        if (SelectedringSize != '') {
            FromSetting?.map((tag) => {
                localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: tag.jewelryData, SelectedringSize: SelectedringSize, diamondData: tag.diamondData }]))
            })
            CallAddtoWishlistApi(jewelryDetail?.id)
        }
    }
    const ChooseDiamondvalidation = (type, mincaret, maxcaret, tag) => {

        if (SelectedringSize == '') {
            setmessage(true)

        } else {
            setmessage(false)
        }
        if (SelectedringSize != '') {
            FromSetting?.map((tag) => {
                localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: tag.jewelryData, SelectedringSize: SelectedringSize, diamondData: tag.diamondData }]))
            })
            window.location.pathname = BASENAME + `DiamondList/${utf8_to_b64(type)}/${utf8_to_b64(mincaret)}/${utf8_to_b64(maxcaret)}/${tag?.jewelryData?.title}`
            localStorage.setItem('Shape', JSON.stringify([type]))
        }
    }


    const CallAddtoWishlistApi = async (JewelryId) => {

        const controller = new AbortController();
        setIsWishlistLoading(true)
        let DiamondId = FromSetting?.map(item => { return item?.diamondData?.id })

        var form = new FormData();

        form.append("jewelryid", JewelryId == null ? "" : JewelryId);
        form.append("diamondid", DiamondId == null ? "" : DiamondId);
        form.append("ringsize", SelectedringSize.id)

        await axios.post(BASE_URL + GetAPIUrl.WISHLIST_URL, form, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token
            }
        })
            .then(response => {
                if (response.data.success == true) {
                    setIsWishlistLoading(false)
                    ShowMessage(response.data.message)
                    CallCartCountApi(token)
                    setmessage(false)
                    // window.location.pathname = 'Wishlist'
                } else {
                    setIsWishlistLoading(false)
                    ShowErrorMessage(response.data.message)
                }
            })
            .catch(error => {
                console.error('There was an error!', error);
                setIsWishlistLoading(false)
                ShowErrorMessage(error.message)
            });
        controller.abort()

    }
    const resetZoom = () => {
        var $easyzoom = $('.easyzoom').easyZoom();
        var api1 = $easyzoom.filter('.easyzoom--with-thumbnails').data('easyZoom');
        var $this = $('.thumbnails .active-bor-z a');
        api1.swap($this.data('standard'), $this.attr('href'));
    }
    $(function () {
        $('.f-click').on({
            'click': function () {
                // $('.change-image').attr('src','images/product/p1.png');
                $(this).parent().closest('.find-img').find('.change-image').attr('src', $(this).data('src'));
                // $(this).toggleClass('active-1');
                $(this).addClass("active-1").siblings().removeClass("active-1");
            }
        });
        // Instantiate EasyZoom instances
        var $easyzoom = $('.easyzoom').easyZoom();
        // Setup thumbnails example
        var api1 = $easyzoom.filter('.easyzoom--with-thumbnails').data('easyZoom');

        $('.thumbnails').on('click', 'a', function (e) {
            var $this = $(this);
            e.preventDefault();
            // Use EasyZoom's `swap` method
            api1.swap($this.data('standard'), $this.attr('href'));
        });
        // Setup toggles example
        var api2 = $easyzoom.filter('.easyzoom--with-toggle').data('easyZoom');

        $('.toggle').on('click', function () {
            var $this = $(this);

            if ($this.data("active") === true) {
                $this.text("Switch on").data("active", false);
                api2.teardown();
            } else {
                $this.text("Switch off").data("active", true);
                api2._init();
            }
        });

        $(".add-active li").click(function () {
            $("li").removeClass("active-bor-z");
            $(this).addClass("active-bor-z");
        });
        $(window).scroll(function () {
            var pos = $(window).scrollTop();
            if (pos >= 100) {
                var explorefix = $('.myHeader').css("height");
                $(".thumbsider").css({
                    position: 'sticky',
                });
                $('.thumbsider').css("top", parseInt(explorefix) + 10);
            }
            else {
                $(".thumbsider").css({
                    position: 'inherit',
                    top: '0px'
                });

            }
        })
    });

    $(function () {
        $(".click-tab-li2").click(function () {
            $(".click-tab-li2").removeClass("activelitab2");
            $(this).addClass("activelitab2");
            var datact = $(this).data('value');
            $(".main-div2").hide();
            $("#" + datact).show();
        });
    });

    const handleRingsize = (e) => {
        const { name, value } = e.target
        const index = e.target.selectedIndex;
        const el = e.target.childNodes[index]
        const option = el.getAttribute('id');

        setSelectedRingSize({ id: option, value: value })
    }
    return (
        <div>
            {IsLoading || IsWishlistLoading || IsCartLoading ?
                <LoadingSpinner />

                :
                null
            }
            <div>
                <div>
                    <div className="container container-main">
                        <nav aria-label="breadcrumb">
                            <ol className="breadcrumb">
                                {/* <li className="breadcrumb-item"><a href={process.env.PUBLIC_URL + "/"}><i className="fa fa-home" aria-hidden="true"></i></a></li>
                                <li className="breadcrumb-item">{Category == '' ? "Setting" : Category?.categoryId == "21" && "Engagment Ring" || Category?.categoryId == "41" && "Wedding Ring"}</li>
                                <li className="breadcrumb-item active" aria-current="page">{Category == '' ? "Setting" : Category?.categoryName}</li> */}

                            </ol>
                        </nav>
                    </div>
                </div>
                <div>
                    {getAllData == '' &&
                        FromSetting?.map((tag, i) => {
                            return (
                                <section className="mobile-view-none" key={i}>
                                    <div className="container container-main">
                                        <div className="wizard2-steps mb-3">
                                            <div className="step wizard2-steps-heading">
                                                <div className="node">
                                                    <div className="node-skin">
                                                        <div className="cont">
                                                            <h2 className="nostyle-heading">Build Your Own Ring</h2>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            {tag?.jewelryData == '' ?
                                                <div className="cyo-bar-step step step-item  active-step keep-left">
                                                    <div className="node" >
                                                        <div className="node-skin">
                                                            <div className="pho">
                                                                <img src={process.env.PUBLIC_URL + "/assets/images/steps/setting.svg"} alt="setting" style={{ backgroundColor: "white" }} />
                                                            </div>
                                                            <div className="cont">
                                                                <div className="action help-tips">
                                                                    <a href="#" className="td-u bar-action line1-doted-2"></a>
                                                                </div>
                                                                <div className="heading">
                                                                    <div className="action help-tips">
                                                                        <a href="#" className="td-u bar-action">Choose</a>
                                                                    </div>
                                                                    <h2 className="nostyle-heading">setting</h2>


                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                :
                                                <div className="cyo-bar-step step step-item active-step keep-left">
                                                    <div className="node" >
                                                        <div className="node-skin">
                                                            <div className="pho">

                                                                <img style={{ background: 'rgba(76, 175, 80, 0.1)' }} src={tag?.jewelryData?.default.path} alt="setting" />


                                                            </div>
                                                            <div className="cont">
                                                                <div className="heading"><h2 className="nostyle-heading">Setting</h2>
                                                                    <div className="action help-tips">
                                                                        <div className="td-u bar-action">{tag?.jewelryData?.title}
                                                                            <aside>Price :${tag?.jewelryData?.setting_price?.toFixed(2)}</aside>
                                                                        </div>
                                                                    </div>
                                                                    <div className="action double-action" style={{ display: 'flex' }}>
                                                                        {/* <div onClick={() => window.location.reload()}>
                                                                            <Link
                                                                                className="td-u bar-action"
                                                                                aria-current="page"
                                                                                style={{ textDecoration: "none", marginRight: 10 }}

                                                                                to={process.env.PUBLIC_URL +`/Jewelry/${tag?.jewelryData?.title}`}
                                                                            >
                                                                                Change
                                                                            </Link>
                                                                        </div>
                                                                        <div onClick={() => window.location.reload()}>
                                                                            <Link
                                                                                className="td-u bar-action"
                                                                                aria-current="page"
                                                                                style={{ textDecoration: "none" }}

                                                                                to={process.env.PUBLIC_URL +`/JDetails/${utf8_to_b64(tag?.jewelryData?.id)}/${tag?.jewelryData?.title}`}
                                                                            >
                                                                                View
                                                                            </Link>
                                                                        </div> */}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            }
                                            {tag?.diamondData == '' ?
                                                <div className="cyo-bar-step step step-item ">
                                                    <div className="node" >
                                                        <div className="node-skin">
                                                            <div className="pho">
                                                                <img src={process.env.PUBLIC_URL + "/assets/images/steps/diamonds.svg"} alt="diamond" />
                                                            </div>
                                                            <div className="cont">
                                                                <div className="action help-tips">
                                                                    <a href="#" className="td-u bar-action line1-doted-2"></a>
                                                                </div>
                                                                <div className="heading">
                                                                    <div className="action help-tips">
                                                                        <a href="#" className="td-u bar-action">Choose</a>
                                                                    </div>
                                                                    <h2 className="nostyle-heading">Diamond</h2>


                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                :
                                                <div className="cyo-bar-step step step-item  active-step keep-left">
                                                    <div className="node" >
                                                        <div className="node-skin">
                                                            <div className="pho">
                                                                <img src={tag?.diamondData?.image} alt="diamond" style={{ backgroundColor: "white" }} />
                                                            </div>
                                                            <div className="cont">
                                                                <div className="action help-tips">
                                                                    <a href="#" className="td-u bar-action line1-doted-2"></a>
                                                                </div>
                                                                <div className="heading">
                                                                    <h2 className="nostyle-heading">Diamond</h2>
                                                                    <div className="action help-tips">
                                                                        <div className="td-u bar-action">{tag?.diamondData?.carat} Carat {tag?.diamondData?.ShapeName} Diamond, {tag?.diamondData?.ColorName}-{tag?.diamondData?.ClarityName}
                                                                            <aside>Price :${tag.diamondData.amount}</aside></div>
                                                                    </div>
                                                                    <div className="action double-action" style={{ display: 'flex' }}>
                                                                        {/* <div onClick={() => window.location.reload()}>
                                                                            <Link
                                                                                className="td-u bar-action"
                                                                                aria-current="page"
                                                                                style={{ textDecoration: "none", marginRight: 10 }}

                                                                                to={process.env.PUBLIC_URL +`/DiamondList/${tag?.jewelryData?.jewelry_diamonds?.shape}/${tag?.diamondData?.carat} Carat ${tag?.diamondData?.ShapeName} Diamond, ${tag?.diamondData?.ColorName}-${tag?.diamondData?.ClarityName}`}
                                                                            >
                                                                                Change
                                                                            </Link>
                                                                        </div>
                                                                        <div onClick={() => window.location.reload()}>
                                                                            <Link
                                                                                className="td-u bar-action"
                                                                                aria-current="page"
                                                                                style={{ textDecoration: "none" }}

                                                                                to={process.env.PUBLIC_URL +`/DiamondDetails/${tag?.diamondData?.carat} Carat ${tag?.diamondData?.ShapeName} Diamond, ${tag?.diamondData?.ColorName}-${tag?.diamondData?.ClarityName}`}
                                                                            >
                                                                                View
                                                                            </Link>
                                                                        </div> */}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            }

                                            {tag?.diamondData != '' && tag?.jewelryData != '' ?
                                                <div className="step step-item invariant-color active-step keep-left">
                                                    <div className="node">
                                                        <div className="node-skin">
                                                            <div className="pho">
                                                                <img src={process.env.PUBLIC_URL + "/assets/images/steps/ring.svg"} alt="ring" style={{ backgroundColor: "white" }} />
                                                            </div>
                                                            <div className="cont">
                                                                <div className="action help-tips">TOTAL</div>
                                                                <div className="heading"><h2 className="nostyle-heading">${(tag?.jewelryData?.setting_price + tag?.diamondData?.amount)?.toFixed(2)}</h2></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                :
                                                <div className="step step-item invariant-color">
                                                    <div className="node">
                                                        <div className="node-skin">
                                                            <div className="pho">
                                                                <img src={process.env.PUBLIC_URL + "/assets/images/steps/ring.svg"} alt="ring" />
                                                            </div>
                                                            <div className="cont">
                                                                {/* <div className="action help-tips">Choose</div> */}
                                                                <div className="heading"><h2 className="nostyle-heading">TOTAL</h2></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            }
                                        </div>
                                    </div>
                                </section>

                            )
                        })
                    }
                </div>
                <section className="jumbotron pt-3">
                    <div className="container container-main">
                        <div className="product-details">
                            <div className="row">
                                <div className="col-lg-6">
                                    <div className="thumbsider" id="sidebar">
                                        {selectedImage?.type == "Image" ?
                                            // <div className="easyzoom easyzoom--overlay easyzoom--with-thumbnails boximg-shadot box-h-w mar-l-94">

                                            //     <a href={selectedImage?.path}>
                                            //         <img src={selectedImage?.path}
                                            //             alt=""
                                            //             className="img-w-100" />

                                            //     </a>
                                            // </div>
                                            jewelryDetail?.zoom?.map((item, index) => {
                                                let selected = selectedImage?.id == item?.id
                                                return (
                                                    selected &&

                                                    <div className="easyzoom easyzoom--overlay easyzoom--with-thumbnails boximg-shadot box-h-w mar-l-94" key={index}>
                                                        <a href={item?.path}>
                                                            <img src={item?.path}
                                                                alt=""
                                                                className="img-w-100" />
                                                        </a>
                                                    </div>
                                                )
                                            })

                                            :
                                            jewelryDetail?.video?.map((item, index) => {
                                                return (
                                                    <div className="boximg-shadot box-h-w mar-l-94" key={index}>

                                                        <iframe style={{ width: "100%", minHeight: "350px" }} allow="autoplay"
                                                            src={item?.path}></iframe>
                                                    </div>
                                                )
                                            })}

                                        <ul className="ul-start thumbnails add-active set-thumb" >
                                            {jewelryDetail?.thumb?.map((item, index) => {
                                                return (
                                                    <li key={index} className={selectedImage?.id == item?.id ? "active-bor-z" : "boximg-shado"}
                                                        onClick={() => selectionFun(item, index)}>
                                                        <a className='img-link' data-standard={item.path}>
                                                            <img src={item?.path} alt="" />
                                                        </a>
                                                    </li>
                                                )
                                            })}
                                            {jewelryDetail?.video?.map((item, index) => {
                                                return (
                                                    <li key={index} className={selectedImage?.id == item?.id ? "active-bor-z" : "boximg-shado"} >
                                                        <a href={item?.path} className="iframe-video-thumb"
                                                            data-standard={item.path} onClick={() => selectionFun(item, index)}>
                                                            <img src="https://cdn.shopify.com/s/files/1/0057/0736/6467/files/prod-video.png?v=1611210220"
                                                                className=""
                                                                alt="https://cdn.shopify.com/s/files/1/0057/0736/6467/files/prod-video.png?v=1611210220" />
                                                        </a>
                                                    </li>
                                                )
                                            })}
                                        </ul>
                                    </div>
                                </div>
                                <div className="col-lg-6 pl-5 mob-pl-15 mob-mt-30">
                                    <div className="">
                                        <h4 className="lsp1 Hypatia-bold tit-color mb-3 pr-5">
                                            {jewelryDetail?.title}
                                            <span className="hand details-heart-fixed" onClick={() => token == null || token == "" || token == undefined ? window.location.pathname = BASENAME + "Login" : validation()}>
                                                <svg width="24" height="21" viewBox="0 0 24 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M6.5 1C3.4629 1 1 3.36095 1 6.27377C1 8.62513 1.9625 14.2057 11.4368 19.8471C11.6065 19.9471 11.8013 20 12 20C12.1987 20 12.3935 19.9471 12.5632 19.8471C22.0375 14.2057 23 8.62513 23 6.27377C23 3.36095 20.5371 1 17.5 1C14.4629 1 12 4.19623 12 4.19623C12 4.19623 9.5371 1 6.5 1Z" stroke="#AB7C94" strokeOpacity="0.65" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
                                                </svg>
                                            </span>
                                        </h4>
                                        <h6 className="lists-h5 mb-3">
                                            <span className="t-color">SKU :</span> {jewelryDetail?.itemcode}
                                        </h6>
                                        {FromSetting?.map((tag, i) => {
                                            return (
                                                tag?.diamondData != '' ?
                                                    <div class="mt-4 mb-3 selected-boxdiv" key={i}><h5><b>Your Diamond</b></h5>
                                                        <div class="row mt-3 mb-3" style={{ alignItems: "center" }}>
                                                            <div class="col-xl-2 col-lg-2 col-sm-1 col-2" style={{ paddingRight: "5px" }}>
                                                                {/* <img class="img-responsive product-image" src="https://bellamy.blob.core.windows.net/bellamy/M00245/M00245_0002.png" width="100%" alt=" 14K Rose Gold Comfort Fit Engagement Ring" /> */}
                                                                <img className='img-responsive product-image' style={{ background: 'rgba(76, 175, 80, 0.1)' }} src={tag?.diamondData?.image} alt="setting" width="100%" />

                                                            </div>
                                                            <div class="col-xl-10 col-lg-10 col-sm-11 col-10">
                                                                <h6 class="lsp1 Hypatia-bold mb-2" >{tag?.diamondData?.carat} Carat {tag?.diamondData?.ShapeName} Diamond, {tag?.diamondData?.ColorName}-{tag?.diamondData?.ClarityName}</h6><br />
                                                            </div>
                                                        </div>
                                                        {/* <div class="dflx mb-2 col-bl-600"><h6>Your Diamond : $ {DiamondDetail?.amount}</h6></div>
                                                        <div class="dflx mb-2 col-bl-600"><h6>Your Ring : $ {tag?.jewelryData?.setting_price}</h6></div>
                                                        <div class="dflx"><h6>Total : $ {tag?.jewelryData?.setting_price + DiamondDetail?.amount}</h6></div> */}

                                                        {/* <div class="dflx mb-2"><h6>Your Diamond : $ {tag?.diamondData.amount}</h6></div>
                                                        <div class="dflx mb-2"><h6>Your Ring : $ {tag?.jewelryData?.setting_price}</h6></div>
                                                        <div class="dflx"><h6>Total : $ {tag?.jewelryData?.setting_price + tag?.diamondData.amount}</h6> */}

                                                        <div class="row">
                                                            <div class="column" >
                                                                <h6>Your Diamond </h6>
                                                                <h6>Your Ring </h6>
                                                                <h6>Total </h6>

                                                            </div>
                                                            <div class="column" >
                                                                <h6>: ${tag?.diamondData.amount}</h6>
                                                                <h6>: ${tag?.jewelryData?.setting_price}</h6>
                                                                <h6>: ${tag?.jewelryData?.setting_price + tag?.diamondData.amount}</h6>

                                                            </div>
                                                        </div>
                                                    </div>
                                                    :
                                                    <h3 className="lists-h2-price">
                                                        ${jewelryDetail?.setting_price?.toFixed(2)}
                                                    </h3>
                                            )
                                        })}

                                        <div className="mt-4 mb-4">
                                            <div>
                                                <p className="f-weight-400 mb-2">Metal - <span>{jewelryDetail?.metal_stamp?.paraname} {jewelryDetail?.metal_type?.paraname}</span></p>
                                            </div>
                                            <div style={{ display: 'flex' }}>
                                                {jewelryVariants?.map((item, index) => {
                                                    let selectClass = ''
                                                    if (item.metal_type.paraname == 'Rose Gold') {
                                                        selectClass = 'rosegold-bg'
                                                    }
                                                    if (item.metal_type.paraname == 'Yellow Gold') {
                                                        selectClass = 'yellow-bg'
                                                    }
                                                    if (item.metal_type.paraname == 'White Gold') {
                                                        selectClass = 'gray-bg'
                                                    }
                                                    return (
                                                        <ul className="metal-color-li click-li" key={index}>
                                                            <li data-toggle="tooltip"
                                                                title={jewelryDetail?.metal_stamp?.paraname + ' ' + jewelryDetail?.metal_type?.paraname}
                                                                className={defaultVariant == item?.metal_type?.id ? `${selectClass} activeli` : selectClass}
                                                                onClick={() => selectVariant(item, index)}>
                                                                {item?.metal_stamp?.paraname}
                                                            </li>
                                                        </ul>
                                                    )
                                                })}
                                            </div>
                                        </div>

                                        <div className="">
                                            <div className="text-div">Ring Size </div>
                                            {FromSetting?.map((tag, i) => {
                                                return (

                                                    <select style={{ width: "20%" }} className="form-control" onChange={(e) => handleRingsize(e)}>
                                                        <option disabled={true} selected value={tag?.SelectedringSize == '' ? "" : tag?.SelectedringSize?.value}>
                                                            {tag?.SelectedringSize == '' ? "Choose" : tag?.SelectedringSize?.value}
                                                        </option>
                                                        {ringSize?.map((item, index) => {
                                                            return (
                                                                <option id={item?.id} value={item?.paraname} key={index} >
                                                                    {item?.paraname}
                                                                </option>
                                                            )
                                                        })}
                                                    </select>

                                                )
                                            })}


                                            <p style={{ color: Colors.red, height: 15, padding: 4 }}>
                                                {message == true && "Please Choose Ringsize"}
                                            </p>
                                        </div>

                                        <div className="mt-4" >

                                            {getAllData == "" ?
                                                dataFlow[0] == true ?
                                                    <>
                                                        <div onClick={() => removeStorageData()}>
                                                            <a
                                                                className="start-with-diamonds"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none", marginRight: 10 }}

                                                                href={process.env.PUBLIC_URL + '/DiamondList'}
                                                            >
                                                                Change Your Selection
                                                            </a>
                                                        </div>

                                                        <div style={{ display: 'flex', }}>
                                                            <div onClick={() => token == null || token == "" || token == undefined ? window.location.pathname = BASENAME + "Login" : validation()}>
                                                                <a style={{ marginRight: 10 }} className="start-with-diamonds">
                                                                    Add to Wishlist
                                                                </a>
                                                            </div>

                                                            <div onClick={() => token == null || token == "" || token == undefined ? window.location.pathname = BASENAME + "Login" : Cartvalidation()}
                                                            >
                                                                <a className="start-with-diamonds">
                                                                    Add to Cart
                                                                </a>
                                                            </div>

                                                        </div>
                                                    </>
                                                    :
                                                    FromSetting?.map((tag, i) => {
                                                        let type = ''
                                                        let mincaret = ''
                                                        let maxcaret = ''
                                                        tag?.jewelryData?.jewelry_diamonds.map((item, index) => {

                                                            if (item?.diamondtype == 'Center') {
                                                                type = item?.shape
                                                                mincaret = item?.mincaret
                                                                maxcaret = item?.maxcaret
                                                            }
                                                            else {

                                                                if (item?.diamondtype == 'Side') {
                                                                    type = tag?.jewelryData?.jewelry_diamonds[0]?.shape
                                                                    mincaret =tag?.jewelryData?.jewelry_diamonds[0]?.mincaret
                                                                    maxcaret = tag?.jewelryData?.jewelry_diamonds[0]?.maxcaret
                                                                }
                                                            }
                                                        })
                                                        return (
                                                            <a
                                                                className="start-with-diamonds"
                                                                aria-current="page"
                                                                style={{ textDecoration: "none", marginRight: 10 }}
                                                                // href={process.env.PUBLIC_URL + `/DiamondList/${utf8_to_b64(type)}/${utf8_to_b64(mincaret)}/${utf8_to_b64(maxcaret)}/${tag?.jewelryData?.title}`}
                                                                // onClick={() => localStorage.setItem('Shape', JSON.stringify([type]))}
                                                                onClick={() => ChooseDiamondvalidation(type, mincaret, maxcaret, tag)}
                                                            >
                                                                Choose Your Diamond
                                                            </a>

                                                        )

                                                    })
                                                :
                                                <div style={{ display: 'flex', }}>
                                                    <div onClick={() => token == null || token == "" || token == undefined ? window.location.pathname = BASENAME + "Login" : validation()}>
                                                        <a style={{ marginRight: 10 }} className="start-with-diamonds">
                                                            Add to Wishlist
                                                        </a>
                                                    </div>

                                                    <div onClick={() => token == null || token == "" || token == undefined ? window.location.pathname = BASENAME + "Login" : Cartvalidation()}>
                                                        <a className="start-with-diamonds">
                                                            Add to Cart
                                                        </a>
                                                    </div>

                                                </div>
                                            }

                                        </div>
                                        <div>
                                            <p className="ptag-text">
                                                Whether for an engagement, anniversary, or a new family addition, this stunning Diora Adams will be a part of your moment Diora Adamns. Personalize it with one of our options or purchase the affordable loose diamond individually.
                                            </p>
                                            <p className="ptag-text">
                                                The videos and images used are for presentations purposes only, for more information on this exact stone, please contact us
                                            </p>
                                        </div>
                                        <div className="mt-4">
                                            <table>
                                                <tbody className="details-table">
                                                    <tr>
                                                        <td>
                                                            <span>
                                                                <img
                                                                    width="25"
                                                                    height="25"
                                                                    src={hours} />
                                                            </span>
                                                        </td>
                                                        <td>
                                                            24 / 7 Customer Service
                                                            <span className="accent-delivery-date">Live Chat</span>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <span>
                                                                <img
                                                                    width="25"
                                                                    height="25"
                                                                    src={callimg} />
                                                            </span>
                                                        </td>
                                                        <td>
                                                            <a className="accent-delivery" href="tel:8521478545">Call us at
                                                                <span className="accent-delivery-date">999-745-7458</span> (10am - 5pm PST)
                                                            </a>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <span>
                                                                <img
                                                                    width="25"
                                                                    height="25"
                                                                    src={email}
                                                                    alt="Email@3x" />
                                                            </span>
                                                        </td>
                                                        <td className="learn">
                                                            <a href="#" className="google-rating-static">
                                                                <span className="accent-delivery">Have a question? </span>
                                                                <span className="accent-delivery-date">Send us an email</span>
                                                            </a>
                                                        </td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                {/* <section className="jumbotron" style={{ background: "#F8F8F8" }}>
                        <div className="container container-main">
                            {FromSetting?.map((tag, i) => {
                                return (
                                    tag?.jewelryData != '' && tag?.diamondData != '' ?
                                        <div>
                                            <ul className="tab-ul2">
                                                <li className= "click-tab-li2 activelitab2" data-value="jewelry-id" >
                                                    Jewelry
                                                </li>
                                                <li className="click-tab-li2" data-value="diamond-id" >
                                                    Diamond
                                                </li>
                                            </ul>
                                        </div>
                                        :
                                        tag?.jewelryData == '' ?
                                            <div>
                                                <ul className="tab-ul2">

                                                    <li className="click-tab-li2 activelitab2" data-value="diamond-id" >
                                                        Diamond
                                                    </li>
                                                </ul>
                                            </div>
                                            :
                                            <div>
                                                <ul className="tab-ul2">
                                                    <li className="click-tab-li2" data-value="jewelry-id" >
                                                        Jewelry
                                                    </li>

                                                </ul>
                                            </div>

                                )
                            })}
                            {FromSetting?.map((tag, i) => {
                                return (
                                    tag?.jewelryData != '' && tag?.diamondData != '' ?
                                        <div className="div-tab-bg">
                                           
                                                <div className="main-div2" id="jewelry-id" style="">
                                                    <h4>
                                                        Product Information
                                                    </h4>
                                                    <div className="row">
                                                        <div className="col-lg-4">
                                                            <div>
                                                                <p className="ptag-text">
                                                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                                </p>
                                                            </div>
                                                        </div>

                                                        <div className="col-lg-8">
                                                            <div className="box-news">
                                                                <div>
                                                                    <dl className="order-summary-me-2 pad-10-dd-me">
                                                                        <dd>
                                                                            Shape
                                                                            <strong>Pear</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Carat Size
                                                                            <strong>5 And Above</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Quality
                                                                            <strong>AAA</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Color
                                                                            <strong>Jet Black</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Number Of Diamonds
                                                                            <strong>1 Pcs</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Clarity
                                                                            <strong>OPAQUE</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Certification
                                                                            <strong>If Customer Need</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Diamond Type
                                                                            <strong>Natural</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Diamond Size
                                                                            <strong>18.77*29*9 mm</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Cut
                                                                            <strong>Very Good</strong>
                                                                        </dd>
                                                                    </dl>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div className="main-div2" id="diamond-id" style={{display: "none"}}>
                                                    <div>
                                                        <h4>
                                                            Diamonds Information
                                                        </h4>
                                                        <div className="row">
                                                            <div className="col-lg-4">
                                                                <div>
                                                                    <p className="ptag-text">
                                                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                                    </p>
                                                                </div>
                                                            </div>

                                                            <div className="col-lg-8">
                                                                <div className="box-news">
                                                                    <div>
                                                                        <dl className="order-summary-me-2 pad-10-dd-me">
                                                                            <dd>
                                                                                Ring Size
                                                                                <strong>K 1/2</strong>
                                                                            </dd>
                                                                            <dd>
                                                                                Min # of Diamonds
                                                                                <strong>25</strong>
                                                                            </dd>
                                                                            <dd>
                                                                                Total Carat Weight
                                                                                <strong>0.98</strong>
                                                                            </dd>
                                                                            <dd>
                                                                                Colour
                                                                                <strong>I</strong>
                                                                            </dd>
                                                                            <dd>
                                                                                Number Of Diamonds
                                                                                <strong>1 Pcs</strong>
                                                                            </dd>
                                                                            <dd>
                                                                                Clarity
                                                                                <strong>SI2</strong>
                                                                            </dd>
                                                                            <dd>
                                                                                Size
                                                                                <strong>2.1mm</strong>
                                                                            </dd>
                                                                            <dd>
                                                                                Diamond Type
                                                                                <strong>Natural</strong>
                                                                            </dd>
                                                                            <dd>
                                                                                Shape
                                                                                <strong>Round</strong>
                                                                            </dd>
                                                                            <dd>
                                                                                Cut
                                                                                <strong>Very Good</strong>
                                                                            </dd>
                                                                        </dl>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            
                                        </div>
                                        :
                                        tag?.jewelryData == '' ?
                                            <div>
                                                <ul className="tab-ul2">

                                                    <li className="click-tab-li2 activelitab2" data-value="diamond-id" >
                                                        Diamond
                                                    </li>
                                                </ul>
                                            </div>
                                            :
                                            <div>
                                                <ul className="tab-ul2">
                                                    <li className="click-tab-li2" data-value="jewelry-id" >
                                                        Jewelry
                                                    </li>

                                                </ul>
                                            </div>

                                )
                            })}


                        </div>
                    </section> */}

                {
                    dataFlow[0] == true ?
                        <section className="jumbotron" style={{ backgroundColor: "#F8F8F8" }}>
                            {FromSetting?.map((tag, i) => {
                                return (
                                    <div className="container container-main" key={i}>
                                        <div>

                                            {tag?.jewelryData != '' && tag?.diamondData != '' ?

                                                <ul className="tab-ul2">
                                                    <li className="click-tab-li2 activelitab2" data-value="jewelry-id" >
                                                        Jewelry
                                                    </li>
                                                    {tag?.jewelryData?.jewelry_diamonds?.diamondtype == "Side" &&
                                                        <li className="click-tab-li2" data-value="sidestone-id" >
                                                            Side Stone
                                                        </li>
                                                    }

                                                    <li className="click-tab-li2" data-value="diamond-id" >
                                                        Diamond
                                                    </li>
                                                </ul>

                                                :
                                                tag?.jewelryData == '' ?
                                                    <ul className="tab-ul2">

                                                        <li className="click-tab-li2 activelitab2" data-value="diamond-id" >
                                                            Diamond
                                                        </li>
                                                    </ul>
                                                    :
                                                    <ul className="tab-ul2">
                                                        <li className="click-tab-li2 activelitab2" data-value="jewelry-id" >
                                                            Jewelry
                                                        </li>
                                                        {tag?.jewelryData?.jewelry_diamonds?.diamondtype == "Side" &&
                                                            <li className="click-tab-li2" data-value="sidestone-id" >
                                                                Side Stone
                                                            </li>
                                                        }
                                                    </ul>


                                            }
                                        </div>
                                        <div className="div-tab-bg">
                                            <div className="main-div2" id="jewelry-id" style={{}}>
                                                <h4>
                                                    Product Information
                                                </h4>
                                                <div className="row">
                                                    <div className="col-lg-4">
                                                        {/* <div>
                                                            <p className="ptag-text">
                                                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                            </p>
                                                        </div> */}
                                                    </div>

                                                    <div className="col-lg-8">
                                                        <div className="box-news">
                                                            <div>
                                                                <dl className="order-summary-me-2 pad-10-dd-me">
                                                                    <dd>
                                                                        SKU
                                                                        <strong>{tag?.jewelryData?.itemcode == null ? "-" : tag?.jewelryData?.itemcode}</strong>
                                                                    </dd>
                                                                    <dd>
                                                                        Ring Size
                                                                        <strong>{tag.SelectedringSize == '' ? "-" : tag.SelectedringSize?.value}</strong>
                                                                    </dd>
                                                                    <dd>
                                                                        Metal
                                                                        <strong>{tag?.jewelryData?.metal_stamp?.paraname} {tag?.jewelryData?.metal_type?.paraname}</strong>
                                                                    </dd>
                                                                    <dd>
                                                                        Metal Weight
                                                                        <strong>{tag?.jewelryData?.metalweight == null ? "-" : tag?.jewelryData?.metalweight}</strong>
                                                                    </dd>
                                                                    <dd>
                                                                        Setting Type
                                                                        <strong>{tag?.jewelryData?.setting_type?.paraname == null ? "-" : tag?.jewelryData?.setting_type?.paraname}</strong>
                                                                    </dd>
                                                                </dl>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="main-div2" id="sidestone-id" style={{ display: "none" }}>
                                                <h4>
                                                    Product Information
                                                </h4>
                                                <div className="row">
                                                    <div className="col-lg-4">
                                                        {/* <div>
                                                            <p className="ptag-text">
                                                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                            </p>
                                                        </div> */}
                                                    </div>

                                                    <div className="col-lg-8">
                                                        <div className="box-news">
                                                            <div>
                                                                <dl className="order-summary-me-2 pad-10-dd-me">

                                                                    <dd>
                                                                        Total Diamonds
                                                                        <strong>{tag?.jewelryData?.totaldiamonds == null ? "-" : tag?.jewelryData?.totaldiamonds}</strong>
                                                                    </dd>
                                                                    <dd>
                                                                        Total Weight
                                                                        <strong>{tag?.jewelryData?.totalweight == null ? "-" : tag?.jewelryData?.totalweight}</strong>
                                                                    </dd>
                                                                    <dd>
                                                                        Min Carat
                                                                        <strong>{tag?.jewelryData?.mincaret == null ? "-" : tag?.jewelryData?.mincaret}</strong>
                                                                    </dd>
                                                                    <dd>
                                                                        Max Carat
                                                                        <strong>{tag?.jewelryData?.maxcaret == null ? "-" : tag?.jewelryData?.maxcaret}</strong>
                                                                    </dd>
                                                                    <dd>
                                                                        From Size
                                                                        <strong>{tag?.jewelryData?.fromsize == null ? "-" : tag?.jewelryData?.fromsize}</strong>
                                                                    </dd>
                                                                    <dd>
                                                                        To Size
                                                                        <strong>{tag?.jewelryData?.tosize == null ? "-" : tag?.jewelryData?.tosize}</strong>
                                                                    </dd>

                                                                </dl>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="main-div2" id="diamond-id" style={{ display: "none" }}>
                                                <div>
                                                    <h4>
                                                        Diamonds Information
                                                    </h4>
                                                    <div className="row">
                                                        <div className="col-lg-4">
                                                            <div>
                                                                <p className="ptag-text">
                                                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                                </p>
                                                            </div>
                                                        </div>

                                                        <div className="col-lg-8">
                                                            <div className="box-news">
                                                                <div>
                                                                    <dl className="order-summary-me-2 pad-10-dd-me">
                                                                        <dd>
                                                                            Shape
                                                                            <strong>{tag?.diamondData?.ShapeName == null ? "-" : tag?.diamondData?.ShapeName}</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Carat
                                                                            <strong>{tag?.diamondData?.carat == null ? "-" : tag?.diamondData?.carat}</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Color
                                                                            <strong>{tag?.diamondData?.ColorName == null ? "-" : tag?.diamondData?.ColorName}</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Clarity
                                                                            <strong>{tag?.diamondData?.ClarityName == null ? "-" : tag?.diamondData?.ClarityName}</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Lab
                                                                            <strong>{tag?.diamondData?.LabName == null ? "-" : tag?.diamondData?.LabName}</strong>
                                                                        </dd>
                                                                        <dd>
                                                                            Certificate
                                                                            <strong>{tag?.diamondData?.cert_no == null ? "-" : tag?.diamondData?.cert_no}</strong>
                                                                        </dd>

                                                                    </dl>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                )
                            })}
                        </section>
                        :
                        <section className="jumbotron" style={{ backgroundColor: "#F8F8F8" }}>
                            <div className="container container-main">
                                <div>

                                    <ul className="tab-ul2">
                                        <li className="click-tab-li2 activelitab2" data-value="jewelry-id" >
                                            Jewelry
                                        </li>
                                        {jewelryDetail?.jewelry_diamonds?.diamondtype == "Side" &&
                                            <li className="click-tab-li2" data-value="sidestone-id" >
                                                Side Stone
                                            </li>
                                        }
                                    </ul>
                                </div>
                                <div className="div-tab-bg">
                                    <div className="main-div2" id="jewelry-id" style={{}}>
                                        <h4>
                                            Product Information
                                        </h4>
                                        <div className="row">
                                            <div className="col-lg-4">
                                                {/* <div>
                                                    <p className="ptag-text">
                                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                    </p>
                                                </div> */}
                                            </div>

                                            <div className="col-lg-8">
                                                <div className="box-news">
                                                    <div>
                                                        <dl className="order-summary-me-2 pad-10-dd-me">
                                                            <dd>
                                                                SKU
                                                                <strong>{jewelryDetail?.itemcode == null ? "-" : jewelryDetail?.itemcode}</strong>
                                                            </dd>
                                                            {FromSetting?.map((tag, i) => {
                                                                return (
                                                                    <dd>
                                                                        Ring Size
                                                                        <strong>{tag.SelectedringSize == '' ? "-" : tag.SelectedringSize?.value}</strong>
                                                                    </dd>
                                                                )
                                                            })}
                                                            <dd>
                                                                Metal
                                                                <strong>{jewelryDetail?.metal_stamp?.paraname} {jewelryDetail?.metal_type?.paraname}</strong>
                                                            </dd>
                                                            <dd>
                                                                Metal Weight
                                                                <strong>{jewelryDetail?.metalweight == null ? "-" : jewelryDetail?.metalweight}</strong>
                                                            </dd>
                                                            <dd>
                                                                Setting Type
                                                                <strong>{jewelryDetail?.setting_type?.paraname == null ? "-" : jewelryDetail?.setting_type?.paraname}</strong>
                                                            </dd>
                                                        </dl>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="main-div2" id="sidestone-id" style={{ display: "none" }}>
                                        <h4>
                                            Product Information
                                        </h4>
                                        <div className="row">
                                            <div className="col-lg-4">
                                                {/* <div>
                                                    <p className="ptag-text">
                                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                    </p>
                                                </div> */}
                                            </div>

                                            <div className="col-lg-8">
                                                <div className="box-news">
                                                    <div>
                                                        <dl className="order-summary-me-2 pad-10-dd-me">

                                                            <dd>
                                                                Total Diamonds
                                                                <strong>{jewelryDetail?.jewelry_diamonds?.totaldiamonds == null ? "-" : jewelryDetail?.jewelry_diamonds?.totaldiamonds}</strong>
                                                            </dd>
                                                            <dd>
                                                                Total Weight
                                                                <strong>{jewelryDetail?.jewelry_diamonds?.totalweight}</strong>
                                                            </dd>
                                                            <dd>
                                                                Min Carat
                                                                <strong>{jewelryDetail?.jewelry_diamonds?.mincaret == null ? "-" : jewelryDetail?.jewelry_diamonds?.mincaret}</strong>
                                                            </dd>
                                                            <dd>
                                                                Max Carat
                                                                <strong>{jewelryDetail?.jewelry_diamonds?.maxcaret == null ? "-" : jewelryDetail?.jewelry_diamonds?.maxcaret}</strong>
                                                            </dd>
                                                            <dd>
                                                                From Size
                                                                <strong>{jewelryDetail?.jewelry_diamonds?.fromsize == null ? "-" : jewelryDetail?.jewelry_diamonds?.fromsize}</strong>
                                                            </dd>
                                                            <dd>
                                                                To Size
                                                                <strong>{jewelryDetail?.jewelry_diamonds?.tosize == null ? "-" : jewelryDetail?.jewelry_diamonds?.tosize}</strong>
                                                            </dd>

                                                        </dl>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </section>
                }
                <section className="jumbotron">
                    <div>
                        <div className="collection-div-bg" id="test" style={{ position: "relative" }}>
                            <div className="pad-left-210">
                                <div className="mb-4">
                                    <h4 className="title-1">
                                        Recommended Items
                                    </h4>
                                </div>
                                {
                                    (recommended.length > 0) ?
                                        <OwlCarousel className='explore-slider explore-arrow explore-product'
                                            autoplayHoverPause='true' autoplay='true' margin={6} items={7}>
                                            {
                                                recommended?.map((item, index) => {
                                                    return (

                                                        <div className='item' key={index} >
                                                            <img src={item?.default?.path == null ? noimage : item?.default?.path} />

                                                            <div className="text-center show-viewbtn">
                                                                <h5 className="product-title pt-3 line1-doted-3">
                                                                    {item?.title}
                                                                </h5>
                                                                <p className="product-title-price mb-0">
                                                                    {item?.setting_price.toFixed(2)}
                                                                </p>
                                                                <div className="pt-3 hide-view-btn">
                                                                    <div className='view-details-btn'>
                                                                        <span className="span-link">
                                                                            View Details
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    )
                                                })
                                            }
                                        </OwlCarousel>
                                        : ''
                                }



                            </div>
                        </div>
                    </div>
                </section>
                {/* <ToastContainer /> */}
            </div >

        </div >
    )
}




{/* <div id="arrivals-collection" className="owl-carousel owl-theme rm-arrow-owl explore-arrow">

{recommended?.map((item, index) => {
    return (
        <div className="item" key={index}>

            <div className="">
                <span className="heart-span hand" onClick={() => token == "" || token == undefined ? window.location.pathname = process.env.PUBLIC_URL + "Login" : CallAddtoWishlistApi(item?.id)}>

                    <svg width="24" height="21" viewBox="0 0 24 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M6.5 1C3.4629 1 1 3.36095 1 6.27377C1 8.62513 1.9625 14.2057 11.4368 19.8471C11.6065 19.9471 11.8013 20 12 20C12.1987 20 12.3935 19.9471 12.5632 19.8471C22.0375 14.2057 23 8.62513 23 6.27377C23 3.36095 20.5371 1 17.5 1C14.4629 1 12 4.19623 12 4.19623C12 4.19623 9.5371 1 6.5 1Z" stroke="#AB7C94" strokeOpacity="0.65" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                </span>
            </div>
            <div onClick={() => { addNewKey(item); window.location.pathname = `/JDetails/${utf8_to_b64(item?.id)}/${item?.slug}` }}>


                <img src={item?.default?.path == null ? noimage : item?.default?.path} className="arrivals-img" />


                <div className="text-center show-viewbtn">
                   
                    <p className="line1-doted-2">
                        {item?.title}
                    </p>
                    <label className="price-label mt-3">
                        ${item?.price}
                    </label>
                    <div className="pt-3 hide-view-btn">
                        <div className='view-details-btn'>
                            <span className="span-link">
                                View Details
                            </span>
                            <span>&nbsp;
                                <svg width="8" height="11" viewBox="0 0 8 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 10L6 5.5L1 1" stroke="#23282D" strokeWidth="1.5" strokeLinecap="round" /></svg>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
})}

</div> */}