import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import Cookies from 'universal-cookie';
import { BASE_URL, GetAPIUrl } from '../API/APIUrl';
import { BASENAME, utf8_to_b64 } from '../helpers/Utility';
import LoadingSpinner from '../module/LoadingSpinner';
import { CategorySkeleton, Collection1Skeleton, MainSliderLoading, ShapeSkeleton, SigCollectionSkeleton } from '../module/Skeletons';
import { ShowErrorMessage, ShowMessage } from '../module/Tostify';

const $ = window.$;

const Home = () => {
    const token = useSelector((state) => state?.user?.token)

    useEffect(() => {
        CallBannerListApi()
        CallShapeListApi()
        CallCategoryListApi()
        CallCollectionList1Api()
        CallArrivalListApi()
        CallSignatureListApi()
    }, [])

    // if (!authorized) {
    //     return <Navigate to="/Login" />;                
    // } 

    // const cookies = new Cookies();

    // console.log("email", cookies.get('email'));
    // console.log("password", cookies.get('password'));

    const [mainSliderDetail, setMainSliderDetail] = useState([])
    const [IsmainSliderLoading, setIsmainSliderLoading] = useState(true)

    const [categoryList, setCategoryList] = useState([])
    const [IsCategoryLoading, setIsCategoryLoading] = useState(true)

    const [CollectionList1, setCollectionList1] = useState([])
    const [IsCollectionList1, setIsCollectionList1] = useState(true)

    const [CollectionList2, setCollectionList2] = useState([])
    // const [IsCollectionList2, setIsCollectionList2] = useState(true)

    const [SigCollection, setSigCollection] = useState([])
    const [IsSigCollection, setIsSigCollection] = useState(true)

    const [NewArrival, setNewArrival] = useState([])
    const [IsNewArrival, setIsNewArrival] = useState(true)

    const [Shapes, setShapes] = useState([])
    const [Loading, setLoading] = useState(true)

    const [email, setEmail] = useState('')
    const [subscribeLoad, setSubscribeLoad] = useState(false)

    const CallBannerListApi = async () => {

        await axios.get(BASE_URL + GetAPIUrl.HOME_SLIDER_URL, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        })
            .then(response => {

                if (response.data.success == true) {
                    setMainSliderDetail(response?.data);
                }
            }).catch(error => {
                // ShowErrorMessage(error.message)
            }).finally(() => {
                setIsmainSliderLoading(false)
            })
    }
    const CallCategoryListApi = async () => {


        await axios.get(BASE_URL + GetAPIUrl.HOME_CATEGORY_URL, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
            }
        })
            .then(response => {

                if (response.data.success == true) {
                    setCategoryList(response?.data?.category);
                }
            }).catch(error => {
                // ShowErrorMessage(error.message)
            }).finally(() => {
                setIsCategoryLoading(false)
            })


    }
    const CallShapeListApi = async () => {
        const controller = new AbortController();

        var form = new FormData();
        form.append("type", "diamond");
        form.append("paraname[]", "Shape");

        await axios.post(BASE_URL + GetAPIUrl.PARAMETERS, form)
            .then(response => {
                if (response.data.success == true) {
                    setShapes(response.data.data.Shape)
                }
            }).catch(error => {
                // ShowErrorMessage(error.message)
            }).finally(() => {
                setLoading(false);
            })
        controller.abort()
    }
    const CallCollectionList1Api = async () => {
        const controller = new AbortController();

        var form = new FormData();
        form.append("section_no", "1,2");

        await axios.post(BASE_URL + GetAPIUrl.HOME_COLLECTION_URL, form)
            .then(response => {
                if (response.data.success == true) {
                    setCollectionList1(response.data.collection_section_1)
                    setCollectionList2(response.data.collection_section_2)
                    // CallCollectionList2Api()
                }
            }).catch(error => {
                // ShowErrorMessage(error.message)
            }).finally(() => {
                setIsCollectionList1(false);
            })
        controller.abort()
    }

    const CallEmailApi = async () => {
        setSubscribeLoad(true)
        // event.preventDefault()

        let data = {
            "email": email
        }
        // console.log("for",[...form]);
        await axios.post(BASE_URL + GetAPIUrl.HOME_SUBSCRIBE_URL, data, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            }
        })
            .then(response => {
                if (response.data.success == true) {
                    ShowMessage(response.data.message)
                }
            }).catch(error => {
                // ShowErrorMessage(error.response.data.errors.email[0])
            }).finally(() => {
                setSubscribeLoad(false)
            })

    }
    const CallArrivalListApi = async () => {
        const controller = new AbortController();

        await axios.get(BASE_URL + GetAPIUrl.HOME_ARRIVAL_URL)
            .then(response => {
                if (response.status == 200) {
                    setNewArrival(response.data.data);
                }
            }).catch(error => {
                // ShowErrorMessage(error.message)
            }).finally(() => {
                setIsNewArrival(false)
            })
        controller.abort()
    }
    const CallSignatureListApi = async () => {
        const controller = new AbortController();
        await axios.get(BASE_URL + GetAPIUrl.HOME_SIGNATURE_URL, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        })
            .then(response => {
                if (response.data.success == true) {
                    setSigCollection(response.data.data);
                }
            }).catch(error => {
                // ShowErrorMessage(error.message)
            }).finally(() => {
                setIsSigCollection(false)
            })
        controller.abort()
    }

    const removeStorageData = (item) => {
        localStorage.removeItem('Shape');
        localStorage.removeItem('MetalType')
        localStorage.removeItem('JewelryId')
        localStorage.removeItem('DiamondId')
        localStorage.setItem('All', 'true');
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '', SelectedringSize: '', diamondData: '' }]));
        localStorage.setItem('Category', JSON.stringify({ categoryName: item?.category, categoryId: item?.category_id }));
    }
    const removeShapeStorageData = () => {
        localStorage.removeItem('Shape');
        // localStorage.removeItem('Shape');
        localStorage.removeItem('Category')
        localStorage.removeItem('MetalType')
        localStorage.setItem('Category', JSON.stringify({ categoryName: "All", categoryId: "" }))

        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '', SelectedringSize: '', diamondData: '' }]));
    }
    const removeStartwithStorageData = () => {
        // localStorage.removeItem('Shape');
        // localStorage.removeItem('MetalType')
        // localStorage.removeItem('JewelryId')
        // localStorage.removeItem('DiamondId')
        // localStorage.removeItem('Category')
        // localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '', diamondData: '' }]));
        localStorage.setItem('FromSetting', JSON.stringify([{ jewelryData: '', SelectedringSize: '', diamondData: '' }]));
        localStorage.removeItem('Shape');
        localStorage.removeItem('MetalType')
        localStorage.removeItem('All')
    }
    $(function () {
        $("#explore-slider").owlCarousel({
            nav: true,
            dots: false,
            items: 4,
            margin: 20,
            loop: true,
            navText: [`<img src=${process.env.PUBLIC_URL + '/assets/images/explore-slider/left.svg'} />`, `<img src=${process.env.PUBLIC_URL + '/assets/images/explore-slider/right.svg'} />`],
            responsive: {
                0: {
                    items: 2
                },

                600: {
                    items: 3
                },

                1024: {
                    items: 4
                },
                1200: {
                    items: 4
                },

                1366: {
                    items: 4,
                    stagePadding: 40
                }
            }
        });
    })
    $(function () {
        $(".carousel").swipe({
            swipe: function (event, direction, distance, duration, fingerCount, fingerData) {
                if (direction == 'left') $(this).carousel('next');
                if (direction == 'right') $(this).carousel('prev');
            },
            allowPageScroll: "vertical"
        });
    })

    $(function () {
        $(window).on("load", function () {
            if ($(window).width() > 1800) {
                $("#explore-collection").owlCarousel({
                    nav: true,
                    navText: [
                        "<span><img src='/assets/images/left-arrow-black.png'/></span>",
                        "<span><img src='/assets/images/right-arrow-black.png'/></span>",
                    ],
                    dots: false,
                    items: 3,
                    margin: 33,
                    stagePadding: 30,
                    loop: true,
                    autoplay: true,
                    responsive: {
                        0: {
                            items: 2,
                        },

                        600: {
                            items: 2,
                        },

                        1024: {
                            items: 3,
                        },

                        1366: {
                            items: 5,
                        },
                    },
                });
            }
            if ($(window).width() > 901) {
                $("#explore-collection").owlCarousel({
                    nav: true,
                    navText: [
                        "<span><img src='images/left-arrow-black.png'/></span>",
                        "<span><img src='images/right-arrow-black.png'/></span>",
                    ],
                    dots: false,
                    items: 3,
                    margin: 33,
                    stagePadding: 30,
                    loop: true,
                    autoplay: true,
                    responsive: {
                        0: {
                            items: 2,
                        },

                        600: {
                            items: 2,
                        },

                        1024: {
                            items: 3,
                        },
                        1200: {
                            items: 4,
                        },

                        1366: {
                            items: 4,
                        },
                    },
                });

                $("#arrivals-collection").owlCarousel({
                    nav: false,
                    navText: [
                        "<span><img src='images/left-arrow-black.png'/></span>",
                        "<span><img src='images/right-arrow-black.png'/></span>",
                    ],
                    dots: false,
                    items: 6,
                    margin: 33,
                    stagePadding: 60,
                    loop: true,
                    autoplay: true,
                    autoplayTimeout: 2500,
                    responsive: {
                        0: {
                            items: 1,
                        },

                        600: {
                            items: 2,
                        },

                        1024: {
                            items: 3,
                        },

                        1200: {
                            items: 4,
                        },

                        1366: {
                            items: 5,
                        },
                    },
                });
            }
            if ($(window).width() < 900) {
                $("#explore-collection").owlCarousel({
                    nav: false,
                    navText: [
                        "<span><img src='images/left-arrow-black.png'/></span>",
                        "<span><img src='images/right-arrow-black.png'/></span>",
                    ],
                    dots: false,
                    items: 2,
                    margin: 15,
                    stagePadding: 0,
                    loop: true,
                    autoplay: true,
                    responsive: {
                        0: {
                            items: 2,
                        },

                        600: {
                            items: 3,
                        },
                    },
                });

                $("#arrivals-collection").owlCarousel({
                    nav: false,
                    navText: [
                        "<span><img src='images/left-arrow-black.png'/></span>",
                        "<span><img src='images/right-arrow-black.png'/></span>",
                    ],
                    dots: false,
                    items: 2,
                    margin: 15,
                    stagePadding: 0,
                    loop: true,
                    autoplay: true,
                    autoplayTimeout: 2500,
                    responsive: {
                        0: {
                            items: 2,
                        },

                        600: {
                            items: 3,
                        },
                    },
                });
            }
        });

        $(document).ready(function () {
            $(window).scroll(function () {
                var scroll = $(window).scrollTop();
                if (scroll >= 1) {
                    $(".header-rc").addClass("fixed");
                    $(".bellamy-navgation-mobile").addClass("fixed");
                    $(".bellamy-header").addClass("sticky");
                } else {
                    $(".header-rc").removeClass("fixed");
                    $(".bellamy-header").removeClass("sticky");
                    $(".bellamy-navgation-mobile").removeClass("fixed");
                }
            });

            var headerHeight = $(".bellamy-navgation-mobile").outerHeight();
            $(".open-mobile-menu-list").css("top", headerHeight);

            $(".open-m-menu").click(function () {
                $(".open-mobile-menu").toggleClass("active-menu");
            });

            $(".click-menu").click(function () {
                $(this).next(".mobile-submenu").slideToggle();
                $(this).toggleClass("bor-bot-0");
                $(this).toggleClass("menu-drop-toggle");
            });
        });

        $(".menu-hover").click(function () {
            $(".menuifxed").toggle();
            $(".menu-hover").toggleClass("menu-close");
        });

        $(".menuifxed").mouseleave(function () {
            $(this).hide();
            $(".menu-hover").removeClass("menu-close");
            $(".menuli-click").removeClass("active");
        });

        $(".desktop-menu").mouseleave(function () {
            $(".menuifxed").hide();
        });

        $(".menuli-click").hover(function () {
            $(".menuifxed").show();
            $(".menuli-click").removeClass("active");
            $(this).addClass("active");
            var datact = $(this).data("value");
            $(".main-div-menu").hide();
            $("#" + datact).show();
        });

        $(window).on("load", function () {
            if ($(window).width() < 767) {
                $(".first-afilter a:nth-child(2)").addClass("ataglist-thumb-active");
            }
            if ($(window).width() > 768) {
                $(".first-afilter a:first-child").addClass("ataglist-thumb-active");
            }
        });

        $(".table-list-click").click(function () {
            $(".ataglist-thumb").removeClass("ataglist-thumb-active");
            $(".thumblist-view-data").hide();
            $(".pair-tableview-data").hide();
            $(".table-view-data").show();
            $(this).addClass("ataglist-thumb-active");
        });
        $(".thumblist-list-click").click(function () {
            $(".ataglist-thumb").removeClass("ataglist-thumb-active");
            $(".table-view-data").hide();
            $(".pair-tableview-data").hide();
            $(".thumblist-view-data").show();
            $(this).addClass("ataglist-thumb-active");
        });

        $(".pair-tablelist-click").click(function () {
            $(".ataglist-thumb").removeClass("ataglist-thumb-active");
            $(".table-view-data").hide();
            $(".thumblist-view-data").hide();
            $(".pair-tableview-data").show();
            $(this).addClass("ataglist-thumb-active");
        });

        $(".dia-tabs a").click(function () {
            $(".dia-tabs a").removeClass("active-tab");
            $(this).addClass("active-tab");
            var datactorder = $(this).data("value");
            $(".main-div").hide();
            $("#" + datactorder).show();
        });

        //   $(window).on("load", function () {
        //     if ($(window).width() < 991) {
        //       $(".myHeader").remove();
        //     }
        //     if ($(window).width() > 992) {
        //       $(".mobile-menu").remove();
        //     }
        //   });

        //   $(window).on("load", function () {
        //     if ($(window).width() < 421) {
        //       $(".diamond-click-toggle").click(function () {
        //         $(this).toggleClass("roted-90");
        //         $(this).next().toggle();
        //       });
        //       $(".set-filter-click").click(function () {
        //         $(this).toggleClass("minus-ico");
        //         $(this).next().toggle();
        //       });
        //     }
        //   });

    })
    $(function () {

        $(document).ready(function () {
            $(".menu-hover").click(function () {
                $(".menuifxed").toggle();
                $(".menu-hover").toggleClass("menu-close");
            });

            $(".menuifxed").mouseleave(function () {
                $(this).hide();
                $(".menu-hover").removeClass("menu-close");
            });

            $('.responsive-sld').slick({
                dots: true,
                infinite: true,
                speed: 1000,
                slidesToShow: 1,
                slidesToScroll: 1,
                autoplay: false,
                arrows: false,
                prevArrow: "<button type='button' class='slick-prev pull-left'><i class='fa fa-chevron-left home-slick-arrow' aria-hidden='true'></i></button>",
                nextArrow: "<button type='button' class='slick-next pull-right'><i class='fa fa-chevron-right home-slick-arrow' aria-hidden='true'></i></button>",
            });
        });


        $(document).ready(function () {
            $(window).scroll(function () {
                var scroll = $(window).scrollTop();
                if (scroll >= 1) {
                    $(".header-rc").addClass("fixed");
                    $(".dove-navgation-mobile").addClass("fixed");
                    $(".dove-header").addClass("sticky");
                }
                else {
                    $(".header-rc").removeClass("fixed");
                    $(".dove-header").removeClass("sticky");
                    $(".dove-navgation-mobile").removeClass("fixed");
                }
            });

            var headerHeight = $('.dove-navgation-mobile').outerHeight();
            $('.open-mobile-menu-list').css('top', headerHeight);

            $('.open-m-menu').click(function () {
                $(".open-mobile-menu").toggleClass('active-menu');
                // $(".main-div").toggleClass('open-m-menu');
            });

            $('.click-menu').click(function () {
                $(this).next(".mobile-submenu").slideToggle();
                $(this).toggleClass('bor-bot-0');
                $(this).toggleClass('menu-drop-toggle');
            });

        });

        // $(document).scroll(function () {
        //     $(this).scrollTop() > 500 ? $(".back-to-top").fadeIn() : $(".back-to-top").fadeOut()
        // });
        $(".back-to-top").click(function () {
            return $("html, body").animate({
                scrollTop: 0
            }, 1500), !1
        });


        $(".click-toggle").click(function () {
            $(this).toggleClass('roted-90');
            $(this).next().toggle();
        });


        $(".faq-click-toggle").click(function () {
            $(this).toggleClass('roted-90');
            $(this).parent().toggleClass('active-bg-faq');
            $(this).next().toggle();
        });


        $(".clickselect-li").click(function () {
            $(".clickselect-li").removeClass("active-tab");
            $(this).addClass("active-tab");
            var datact = $(this).data('value');
            $(".main-div").hide();
            $("#" + datact).show();
        });


        $(".menuli-click").hover(function () {
            $(".menuli-click").removeClass("active");
            $(this).addClass("active");
            var datact = $(this).data('value');
            $(".main-div-menu").hide();
            $("#" + datact).show();
        });


        $(".mission-click").click(function () {
            $(".mission-click").removeClass("active-mission");
            $(this).addClass("active-mission");
            var datact = $(this).data('value');
            $(".main-div-mission").hide();
            $("#" + datact).show();
        });



        $(document).ready(function () {
            $(".add-new-address").show();
            $(".coupon_question").click(function () {
                if ($(this).is(":checked")) {
                    $(".add-new-address").show();
                } else {
                    $(".add-new-address").hide();
                }
            });

            $(".add-new-shippingaddress").hide();
            $(".checked-shiping-add").click(function () {
                if ($(this).is(":checked")) {
                    $(".add-new-shippingaddress").hide();
                } else {
                    $(".add-new-shippingaddress").show();
                }
            });
        });

        function PassowrdView(IdCls) {
            if ($('#' + IdCls).attr('type') == 'password') {
                $('#' + IdCls).attr('type', 'text');
                $('.' + IdCls).removeClass('fa-eye');
                $('.' + IdCls).addClass('fa-eye-slash');
            } else {
                $('#' + IdCls).attr('type', 'password');
                $('.' + IdCls).removeClass('fa-eye-slash');
                $('.' + IdCls).addClass('fa-eye');
            }
        }


        $(window).on("load", function () {
            if ($(window).width() < 421) {
                $(".diamond-click-toggle").click(function () {
                    $(this).toggleClass('roted-90');
                    $(this).next().toggle();
                });

                $(".set-filter-click").click(function () {
                    $(this).toggleClass('minus-ico');
                    $(this).next().toggle();
                });
            }
        });

        $(".images-thumb-click-img").click(function () {
            $(".thumb-videos").hide();
            $(".thumb-images").show();
        });

        $(".iframe-video-thumb").click(function () {
            $(".thumb-videos").show();
            $(".thumb-images").hide();
        });


        $(document).ready(function () {
            setTimeout(function () {
                if ($(window).width() > 901) {
                    $("#explore-collection").owlCarousel({
                        nav: false,
                        navText: ["<span>&#8592;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 3,
                        margin: 30,
                        // stagePadding: 210,
                        loop: false,
                        responsive: {
                            0: {
                                items: 2
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 4
                            }
                        }
                    });
                    $("#recommended-items").owlCarousel({
                        nav: true,
                        navText: ["<span>&#10229;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 4,
                        margin: 30,
                        loop: true,
                        responsive: {
                            0: {
                                items: 1
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 4
                            }
                        }
                    });
                    $("#new-arrival").owlCarousel({
                        nav: true,
                        navText: ["<span>&#10229;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 4,
                        margin: 30,
                        loop: true,
                        responsive: {
                            0: {
                                items: 2
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 4
                            }
                        }
                    });
                }
                if ($(window).width() < 900) {
                    $("#explore-collection").owlCarousel({
                        nav: false,
                        navText: ["<span>&#8592;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 3,
                        margin: 15,
                        // stagePadding: 40,
                        loop: false,
                        responsive: {
                            0: {
                                items: 2
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 3
                            }
                        }
                    });

                    $("#recommended-items").owlCarousel({
                        nav: true,
                        navText: ["<span>&#10229;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 4,
                        margin: 15,
                        loop: true,
                        responsive: {
                            0: {
                                items: 2
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 4
                            }
                        }
                    });

                    $("#new-arrival").owlCarousel({
                        nav: true,
                        navText: ["<span>&#10229;</span>", "<span>&#10230;</span>"],
                        dots: false,
                        items: 4,
                        margin: 15,
                        loop: true,
                        responsive: {
                            0: {
                                items: 2
                            },

                            600: {
                                items: 2
                            },

                            1024: {
                                items: 3
                            },

                            1366: {
                                items: 4
                            }
                        }
                    });
                }
            }, 100);
        });








    })
    $(function () {
        $(".fot-title").on("click", function () {
            $(this).next(".ullist").toggle();
            $(this).find(".right-ifoot i").toggleClass("fa-minus");
        });

        $(".tab-title-mob").on("click", function () {
            $(this).next(".mob-hide-tabs").toggle();
            $(this).find(".right-ifoot i").toggleClass("fa-minus");
        });

        $(".dropdown-menu-sel li a").click(function () {
            var selText = $(this).text();
            $(this).parents('.cur-drop').find('.dropdown-toggle1').html(selText + ' <span class="caret"></span>');
        });





        $(".open-search").click(function () {
            $(".search-full").toggleClass("open");
        });

        $(".close-search").click(function () {
            $(".search-full").toggleClass("open");
        });

        $('.carousel').carousel({
            // interval: false,
            interval: false,
        });


        $(".box-filter-desig1").click(function () {
            $(this).toggleClass("selected1-filter");
        });

        $(".toggle-filter-div").on("click", function () {
            $(this).next(".toggle-div").toggle();
            $(this).find(".addright-icon i").toggleClass("fa-plus");
        });


        $(".mob-open-filter").on("click", function () {
            $(".filter-to-left").addClass("active");
        });

        $(".mob-close-filter").on("click", function () {
            $(".filter-to-left").removeClass("active");
        });


        $(document).ready(function () {
            //parallax scroll
            $(window).on("load scroll", function () {
                var parallaxElement = $(".parallax_scroll"),
                    parallaxQuantity = parallaxElement.length;
                window.requestAnimationFrame(function () {
                    for (var i = 0; i < parallaxQuantity; i++) {
                        var currentElement = parallaxElement.eq(i),
                            windowTop = $(window).scrollTop(),
                            elementTop = currentElement.offset().top,
                            elementHeight = currentElement.height(),
                            viewPortHeight = window.innerHeight * 0.7 - elementHeight * 0.1,
                            scrolled = windowTop - elementTop + viewPortHeight;
                        currentElement.css({
                            transform: "translate3d(0," + scrolled * 0.2 + "px, 0)"
                        });
                    }
                });
            });


            $(window).on("load scroll", function () {
                var parallaxElement = $(".parallax_scroll-right"),
                    parallaxQuantity = parallaxElement.length;
                window.requestAnimationFrame(function () {
                    for (var i = 0; i < parallaxQuantity; i++) {
                        var currentElement = parallaxElement.eq(i),
                            windowTop = $(window).scrollTop(),
                            elementTop = currentElement.offset().top,
                            elementHeight = currentElement.height(),
                            viewPortHeight = window.innerHeight * 0.1 - elementHeight * 0.5,
                            scrolled = windowTop - elementTop + viewPortHeight;
                        currentElement.css({
                            // transform: "translate3d(0," + scrolled * -0.19 + "px, 0)"
                            transform: "translate3d(" + scrolled * -0.1 + "px," + scrolled * -0.10 + "px, 0)"

                        });
                    }
                });
            });


            $(window).on("load scroll", function () {
                var parallaxElement = $(".about-parallax_scroll"),
                    parallaxQuantity = parallaxElement.length;
                window.requestAnimationFrame(function () {
                    for (var i = 0; i < parallaxQuantity; i++) {
                        var currentElement = parallaxElement.eq(i),
                            windowTop = $(window).scrollTop(),
                            elementTop = currentElement.offset().top,
                            elementHeight = currentElement.height(),
                            viewPortHeight = window.innerHeight * 0.5 - elementHeight * 0.2,
                            scrolled = windowTop - elementTop + viewPortHeight;
                        currentElement.css({
                            transform: "translate3d(0," + scrolled * 0.2 + "px, 0)"
                        });
                    }
                });
            });


            $(window).on("load scroll", function () {
                var parallaxElement = $(".about-parallax_scrollimg"),
                    parallaxQuantity = parallaxElement.length;
                window.requestAnimationFrame(function () {
                    for (var i = 0; i < parallaxQuantity; i++) {
                        var currentElement = parallaxElement.eq(i),
                            windowTop = $(window).scrollTop(),
                            elementTop = currentElement.offset().top,
                            elementHeight = currentElement.height(),
                            viewPortHeight = window.innerHeight * 0.7 - elementHeight * 0.3,
                            scrolled = windowTop - elementTop + viewPortHeight;
                        currentElement.css({
                            transform: "translate3d(0," + scrolled * 0.4 + "px, 0)"
                        });
                    }
                });
            });

            $(window).on("load scroll", function () {
                var parallaxElement = $(".about-parallax_scrollimg1"),
                    parallaxQuantity = parallaxElement.length;
                window.requestAnimationFrame(function () {
                    for (var i = 0; i < parallaxQuantity; i++) {
                        var currentElement = parallaxElement.eq(i),
                            windowTop = $(window).scrollTop(),
                            elementTop = currentElement.offset().top,
                            elementHeight = currentElement.height(),
                            viewPortHeight = window.innerHeight * 2 - elementHeight * 0.2,
                            scrolled = windowTop - elementTop + viewPortHeight;
                        currentElement.css({
                            transform: "translate3d(" + scrolled * 0.05 + "px," + scrolled * -0.05 + "px, 0)"
                        });
                    }
                });
            });


        });


        // $(document).ready(function() {
        //   const scroller = new LocomotiveScroll({
        //     el: document.querySelector('[data-scroll-container]'),
        //     smooth: true
        //   });
        // });


        // window.addEventListener("DOMMouseScroll", handleScroll);
        // window.addEventListener("mousewheel", handleScroll);

        function wheelDistance(e) {
            // console.log(e);
            if (!e) {
                e = window.event;
            }
            var w = e.wheelDelta,
                d = e.detail;
            if (d) {
                return -d / 3; // Firefox;
            }

            // IE, Safari, Chrome & other browsers
            return w / 120;
        }

        function handleScroll(e) {
            var delta = wheelDistance(e);
            var time = 40;
            var distance = 150;

            $('html, body').stop().animate({
                scrollTop: $(window).scrollTop()
                    - (distance * delta)
            }, time);
        }



        $(document).ready(function () {
            setTimeout(function () {
                $(".loader-test").addClass("in");
            }, 300);
        });




        $('#VideoModallist').on('shown.bs.modal', function () {
            $('#video1')[0].play();
        })
        $('#VideoModallist').on('hidden.bs.modal', function () {
            $('#video1')[0].pause();
        })






        $(".show-td").click(function () {
            $(".div-toggle").toggle();
            $(".show-td .spanp").toggleClass("fa-angle-up");
            $(".show-td .spanp").toggleClass("fa-angle-down");
            $(this).toggleClass("borbotnone");
        });

        $(".show-certi").click(function () {
            $(".div-toggle-certi").toggle();
            $(".show-certi .spanp").toggleClass("fa-angle-up");
            $(this).toggleClass("borbotnone");
        });




        $(".iframe-video-thumb").click(function () {
            $(".thumb-videos").show();
            $(".thumb-images").hide();
        });

        $(".images-thumb-click").click(function () {
            $(".thumb-videos").hide();
            $(".thumb-images").show();
        });


        $(".submenu-edu").hide();
        $(".submenu").hide();

        $(".kml-navgation li").hover(
            function () {
                $(this).addClass("open");
            },
            function () {
                $(this).removeClass("open");
            }
        );




        $(".faq-div").on('click', function () {
            $(".show-div").hide();
            $(".sp").removeClass('fa-minus');
            $(this).next(".show-div").toggle();
            $(this).find(".sp").addClass('fa-plus' ? 'fa-minus' : 'fa-plus');
            // $(this).next().toggleClass('hide-div');
            // alert("hi");
        });


        if ($(window).width() < 900) {
            $(".a-rm").each(function () {
                if ($(this).hasClass("disabled1")) {
                    $(this).removeAttr("href");
                }
            });

            $(".submenu").hide();
            $('.click-menu').click(function () {
                $(this).toggleClass('menu-drop-toggle');
                $(this).next(".submenu").slideToggle();
                $(".submenu-edu").hide();
            });


            $(".submenu-edu").hide();
            $('.click-menu-edu').click(function () {
                $(this).toggleClass('menu-drop-toggle-edu');
                $(this).next(".submenu-edu").slideToggle();
                $(".submenu").hide();
            });

        };
    })

    $(function () {
        $("#shape-slider").owlCarousel({
            nav: false,
            dots: false,
            items: 9,
            margin: 30,
            loop: false,
            responsive: {
                0: {
                    items: 3
                },

                600: {
                    items: 5
                },

                1024: {
                    items: 7
                },
                1200: {
                    items: 9
                },

                1366: {
                    items: 9
                }
            }
        });
    })
    $(function () {
        $("#collection-slider").owlCarousel({
            nav: true,
            dots: false,
            items: 4,
            margin: 20,
            loop: true,
            navText: [`<img src=${process.env.PUBLIC_URL + '/assets/images/explore-slider/left.svg'} />`, `<img src=${process.env.PUBLIC_URL + '/assets/images/explore-slider/right.svg'} />`],
            responsive: {
                0: {
                    items: 2
                },

                600: {
                    items: 2
                },

                1024: {
                    items: 3
                },
                1200: {
                    items: 3
                },

                1366: {
                    items: 3
                }
            }
        });
    })
    $(function () {
        $("#new-arrivals-slider").owlCarousel({
            nav: false,
            dots: false,
            items: 4,
            margin: 20,
            loop: true,
            navText: ["<img src='/assets/images/explore-slider/left.svg'/>", `<img src=${process.env.PUBLIC_URL + '/assets/images/explore-slider/right.svg'}'/>`],
            responsive: {
                0: {
                    items: 2
                },

                600: {
                    items: 3,
                    stagePadding: 30
                },

                1024: {
                    items: 4,
                    stagePadding: 40
                },
                1200: {
                    items: 4,
                    stagePadding: 40
                },

                1366: {
                    items: 4,
                    stagePadding: 60
                }
            }
        });
    })
    return (
        < >
            <div className="">
                {subscribeLoad ?
                    <LoadingSpinner />
                    :
                    <main className="main-div">
                        {IsmainSliderLoading ?
                            <MainSliderLoading />
                            :
                            <div className="topbanner blue-hover">
                                <div id="carouselExampleIndicators" className="carousel slide" data-ride="carousel">
                                    <ol className="carousel-indicators">
                                        <li data-target="#carouselExampleIndicators" data-slide-to={mainSliderDetail?.count} className="active"></li>
                                        {/* <li data-target="#carouselExampleIndicators" data-slide-to="1"></li> */}
                                    </ol>

                                    {mainSliderDetail?.mainSliderDetail?.map((item, index) => {
                                        return (
                                            <div className="carousel-inner" key={index}>

                                                <div className="carousel-item active">
                                                    <img className="d-none d-sm-noe d-md-none d-lg-block d-xl-block w-100" src={item?.image} alt="First slide" width="auto" height="auto" />
                                                    <img className="d-md-block d-lg-none w-100" src={item?.mobile_img} alt="First slide" width="auto" height="auto" />
                                                    <div className="carousel-caption" style={{ left: '5%' }}>
                                                        <div className="f-left slider-div-box-left-left" style={{ maxWidth: "600px" }}>
                                                            <h2 className="matesc" style={{ letterSpacing: "0.5px", color: "#23282D" }}>{item?.title_en}</h2>
                                                            <h6 className="mar-bot-20 f-400wt akkurat" style={{ color: "#4A4A4A", lineHeight: "1.5" }}>
                                                                {item?.description_en}
                                                            </h6>
                                                            {item?.buttontext_en != null &&
                                                                <a href={item?.buttonlink} className="hand explore-now-btn">
                                                                    <span>{item?.buttontext_en}</span>
                                                                </a>
                                                            }
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* <div className="carousel-item">

                                                <img className="d-none d-sm-noe d-md-none d-lg-block d-xl-block w-100" src={item?.image} alt="First slide" width="auto" height="auto" />
                                                <img className="d-md-block d-lg-none w-100" src={item?.mobile_img} alt="First slide" width="auto" height="auto" />
                                                <div className="carousel-caption" style={{ left: '5%' }}>

                                                    <div className="f-left slider-div-box-left-left" style={{ maxWidth: "600px" }}>
                                                        <h2 className="matesc" style={{ letterSpacing: "0.5px", color: "#23282D" }}>The True Embodiment  </h2>
                                                        <h6 className="mar-bot-20 f-400wt akkurat" style={{ color: "#4A4A4A", lineHeight: "1.5" }}>
                                                            {item?.description_en}
                                                        </h6>
                                                        <a href="#" className="hand explore-now-btn">
                                                            <span>{item?.buttontext_en}</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div> */}

                                            </div>
                                        )
                                    })}


                                </div>
                            </div>
                        }
                        {categoryList.length > 0 &&
                            <section className="jumbotron-my" style={{ borderBottom: "1px solid #C7C7C7" }}>
                                <div className="max-explore-div mob-p-lf-15">
                                    <div style={{ position: "relative" }}>
                                        <div className="mb-4">
                                            <h3 className="explore-title mb-1">
                                                Explore category
                                            </h3>
                                            <p>
                                                Brilliant design and unparalleled craftsmanship.
                                            </p>
                                        </div>

                                        {IsCategoryLoading ?
                                            <CategorySkeleton />
                                            :
                                            <div id="explore-slider"
                                                className="owl-carousel owl-theme rm-arrow-owl explore-arrow"
                                                style={{ display: 'flex', whiteSpace: 'pre-wrap' }}

                                            >
                                                {categoryList?.map((item, index) => {
                                                    return (
                                                        <div className="item" key={index} onClick={() => removeStorageData(item)}>
                                                            <a
                                                                className=""
                                                                aria-current="page"
                                                                style={{ textDecoration: "none" }}
                                                                href={process.env.PUBLIC_URL + `/Jewelry/${item?.name}`}
                                                            >
                                                                <div className="">
                                                                    <img src={item?.image} className="mb-3" />
                                                                </div>
                                                                <div className="explore-slider-text">
                                                                    <a>
                                                                        {item?.name}
                                                                    </a>
                                                                    <p className="line1-doted-2">
                                                                        {item?.description}
                                                                    </p>
                                                                </div>
                                                            </a>

                                                        </div>
                                                    )
                                                })
                                                }

                                            </div>
                                        }
                                    </div>
                                </div>
                            </section>
                        }
                        <section className="jumbotron-my">
                            <div className="container">
                                <div className="row" style={{ position: "relative" }}>
                                    <div className="col-lg-6">
                                        <div>
                                            <img src={process.env.PUBLIC_URL + "/assets/images/custom/custom-diamonds.jpg"} width="100%" />
                                        </div>
                                    </div>
                                    <div className="col-lg-6">
                                        <div>
                                            <img src={process.env.PUBLIC_URL + "/assets/images/custom/custom-ring.jpg"} width="100%" />
                                        </div>
                                    </div>
                                    <div className="custom-diamonds-section" style={{ maxWidth: '70%' }}>
                                        <div>
                                            <div className="mb-4">
                                                <h3>
                                                    Create a custom engagement ring
                                                </h3>
                                                <p>
                                                    Select a setting and choose a diamond to create your own Beyond Conflict Free  engagement Free ring.
                                                </p>
                                            </div>
                                            <div>
                                                <a className="start-with-btn" href={process.env.PUBLIC_URL + `/Jewelry/${utf8_to_b64("21")}`} onClick={() => { removeStartwithStorageData(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "21" })) }}>
                                                    Start With A Setting
                                                </a>
                                                <a className="start-with-btn" href={process.env.PUBLIC_URL + `/DiamondList/W==/Natural`} onClick={() => { removeStartwithStorageData(); localStorage.setItem('Category', JSON.stringify({ categoryName: "Setting", categoryId: "21" })) }}>
                                                    Start With A Diamond
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        {Shapes?.length > 0 &&
                            <section className="jumbotron-my pt-3">
                                <div className="container container-main" style={{ maxWidth: "1200px" }}>
                                    <div className="mb-4 text-center shop-shape-title" style={{ maxWidth: "700px", margin: "auto" }}>
                                        <h4 className="title-1 mb-3">
                                            Shop By Shape
                                        </h4>
                                        <p className="title-sm">
                                            A Diamond Is Something That Lasts Forever. It Is Essential To Get The Right Shape That Suits The Jewelry. Shop For The Perfect One From Our Remarkably Vast Range.
                                        </p>
                                    </div>
                                    <div>
                                        <div className="pt-4">
                                            {Loading ?
                                                <ShapeSkeleton />
                                                :
                                                <div id="shape-slider" className="owl-carousel owl-theme"
                                                    style={{ flexDirection: 'row', display: 'flex' }}>
                                                    {Shapes?.map((item, index) => {
                                                        return (
                                                            <div className="item" key={index}>
                                                                {/* <a href="#"> */}
                                                                <a href={process.env.PUBLIC_URL + `/DiamondList/${utf8_to_b64(item?.id)}`} onClick={() => removeShapeStorageData(item)}>
                                                                    <div className="text-center shape-div">
                                                                        <img src={item?.image} className="mb-3" />
                                                                        <label className="lbl-sld-shape">{item?.name}</label>
                                                                    </div>
                                                                </a>
                                                            </div>
                                                        )
                                                    })}
                                                </div>
                                            }
                                        </div>
                                    </div>
                                </div>
                            </section>
                        }
                        {SigCollection?.length > 0 &&
                            <section className="jumbotron-my pt-3">
                                <div className="container">
                                    <div className="row">
                                        <div className="col-lg-4 hide-900">
                                            <div>
                                                <img src={process.env.PUBLIC_URL + "/assets/images/gallery/sign-collection.png"} width="100%" height="auto" />
                                            </div>
                                        </div>
                                        <div className="col-lg-8">

                                            <div className="" style={{ position: "relative" }}>
                                                <div className="mb-4">
                                                    <h3 className="explore-title mb-1">
                                                        Explore Our Signature Collections
                                                    </h3>
                                                    <p>
                                                        Brilliant design and unparalleled craftsmanship.
                                                    </p>
                                                </div>
                                                {IsSigCollection ?
                                                    <SigCollectionSkeleton />
                                                    :

                                                    <div id="collection-slider" className="owl-carousel owl-theme rm-arrow-owl explore-arrow" style={{ cursor: "pointer" }}>
                                                        {SigCollection?.map((item, index) => {
                                                            return (
                                                                <div className="item" key={index}>
                                                                    <div className="">
                                                                        <img src={process.env.PUBLIC_URL + "/assets/images/gallery/pp2.jpg"} className="mb-3" />
                                                                    </div>
                                                                    <div className="explore-slider-text">
                                                                        <a>
                                                                            {item?.collection_name}
                                                                        </a>
                                                                        <p className="line1-doted-2">
                                                                            {item?.title}
                                                                        </p>
                                                                        <label className="price-label mt-3">
                                                                            ${item?.price}
                                                                        </label>
                                                                    </div>
                                                                </div>
                                                            )
                                                        })}

                                                    </div>

                                                }
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </section>}

                        {NewArrival?.length > 0 &&
                            <section className="jumbotron-my">
                                <div className="container">
                                    <div className="mb-4 text-center shop-shape-title" style={{ maxWidth: "700px", margin: "auto" }}>
                                        <h4 className="title-1 mb-3">
                                            Explore our new arrivals
                                        </h4>
                                        <p className="title-sm">
                                            There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour.
                                        </p>
                                        <div className="mt-4">
                                            <a className="start-with-btn max-btn-150">
                                                Shop Now
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div className="mt-5 mob-p-lf-15" style={{ marginLeft: '7%', marginRight: '7%' }}>
                                    {IsNewArrival ?
                                        <CategorySkeleton />
                                        :
                                        <div id="new-arrivals-slider" className="owl-carousel owl-theme rm-arrow-owl">

                                            {NewArrival?.map((item, index) => {
                                                return (
                                                    <div className="item" key={index}>
                                                        <div className="">
                                                            <img src={item.get_default_img === '' ? process.env.PUBLIC_URL + "/assets/images/gallery/pp2.jpg" : item?.get_default_img?.path} className="mb-3" />
                                                        </div>
                                                        <div className="explore-slider-text">
                                                            <a>
                                                                ${item?.price}
                                                            </a>
                                                            <p className="line1-doted-2">
                                                                {item?.title}
                                                            </p>
                                                        </div>
                                                    </div>
                                                )
                                            })}
                                        </div>
                                    }
                                </div>

                            </section>
                        }
                        <section className="jumbotron-my" style={{ borderTop: "1px solid #C7C7C7", marginLeft: '7%', marginRight: '7%' }}>
                            <div className="container">
                                <div className="mb-4 text-center shop-shape-title" style={{ maxWidth: "700px", margin: "auto" }}>
                                    <h4 className="title-1 mb-3">
                                        For your peace of mind
                                    </h4>
                                    <p className="title-sm">
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's.
                                    </p>
                                </div>
                            </div>
                            <div className="pt-5 pb-5" style={{ background: "#FAF7F8" }}>
                                <div className="container">
                                    <div className="row" style={{ justifyContent: "center", maxWidth: "1300px", margin: "auto" }}>
                                        <div className="col-lg-2 col-6">
                                            <div className="peace-div text-center">
                                                <img src={process.env.PUBLIC_URL + "/assets/images/icons/peace1.png"} width="40" />
                                                <label>
                                                    Ethical Sourcing
                                                </label>
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-6">
                                            <div className="peace-div text-center">
                                                <img src={process.env.PUBLIC_URL + "/assets/images/icons/peace2.png"} width="40" />
                                                <label>
                                                    GIA Certified Diamonds
                                                </label>
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-6">
                                            <div className="peace-div text-center">
                                                <img src={process.env.PUBLIC_URL + "/assets/images/icons/peace3.png"} width="40" />
                                                <label>
                                                    Lifetime Warranty
                                                </label>
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-6">
                                            <div className="peace-div text-center">
                                                <img src={process.env.PUBLIC_URL + "/assets/images/icons/peace4.png"} width="40" />
                                                <label>
                                                    Lifetime Free Resizing
                                                </label>
                                            </div>
                                        </div>
                                        <div className="col-lg-2 col-6">
                                            <div className="peace-div text-center">
                                                <img src={process.env.PUBLIC_URL + "/assets/images/icons/peace5.png"} width="40" />
                                                <label>
                                                    40 Days Returns
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                        {CollectionList1?.length > 0 &&
                            <section className="jumbotron-my pt-5 pb-2">
                                <div className="container">
                                    <div className="">
                                        <div className="css-1xi4blx">
                                            <div className="css-1984zml">

                                                {IsCollectionList1 ?
                                                    <Collection1Skeleton />
                                                    :
                                                    CollectionList1?.map((item, index) => {
                                                        return (
                                                            <div className="css-4tyedf" key={index}>
                                                                <div className="css-1dqogan">
                                                                    <div className="css-1oi3a6q">
                                                                        <div className="css-qsx0m4">
                                                                            <div className="css-1glzdui zap-fonts">{item?.collection}</div>
                                                                            <h2 className="css-q3hfqt zap-fonts">{item?.name}</h2>
                                                                            <div className="css-1xb0htl">{item?.description}</div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="css-1mzs0a5"></div>
                                                                    <div className="css-1dyfciy">
                                                                        <div className="css-11oyddp">
                                                                            <div className="image css-1qcefhn">
                                                                                <div className="css-43j6zp">
                                                                                    <picture className="css-bqhx0s"> <img src={item?.images[0]} alt="ring" width="100%" /> </picture>
                                                                                </div>
                                                                                <div className="titleInside css-1bz39lf">
                                                                                    <h3 className="css-1vk18nx">sentimental styles</h3></div>
                                                                            </div>
                                                                            <div className="content css-teriou">
                                                                                <h3 className="css-6jy47c">sentimental styles</h3></div>
                                                                            <div className="css-16yku65">
                                                                                <div className="focus-indicator css-7hqtpb"></div>
                                                                            </div>
                                                                        </div>
                                                                        <div className="css-1mzs0a5"></div>
                                                                        <div className="css-11oyddp">
                                                                            <div className="image css-1qcefhn">
                                                                                <div className="css-43j6zp">
                                                                                    <picture className="css-bqhx0s"> <img src={item?.images[1]} alt="ring" width="100%" /> </picture>
                                                                                </div>
                                                                                <div className="titleInside css-1bz39lf">
                                                                                    <h3 className="css-1vk18nx">Extraordinary Gifts</h3></div>
                                                                            </div>
                                                                            <div className="content css-teriou">
                                                                                <h3 className="css-6jy47c">Extraordinary Gifts</h3></div>
                                                                            <div className="css-16yku65">
                                                                                <div className="focus-indicator css-7hqtpb"></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="css-1mzs0a5"></div>
                                                                <div className="css-11oyddp">
                                                                    <div className="image css-1hsqls8">
                                                                        <div className="css-3ghw3q">
                                                                            <picture className="css-bqhx0s"> <img src={item?.images[2]} alt="ring" width="100%" /> </picture>
                                                                        </div>
                                                                        <div className="titleInside css-1bz39lf">
                                                                            <h3 className="css-g1eabd">Classics for mom</h3></div>
                                                                    </div>
                                                                    <div className="content css-teriou">
                                                                        <h3 className="css-6jy47c">Classics for mom</h3> </div>
                                                                    <div className="css-16yku65">
                                                                        <div className="focus-indicator css-7hqtpb"></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        )
                                                    })}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        }

                        {CollectionList2?.length > 0 &&
                            <section className="jumbotron-my pb-0">
                                <div className="container">
                                    {IsCollectionList1 ?
                                        <Collection1Skeleton />
                                        :

                                        <div className="row" style={{ paddingLeft: "15px", paddingRight: "15px" }}>

                                            <div className="col-lg-6 p-0 mob-bot-20">
                                                <div>
                                                    <div className="pmd-card-media">
                                                        <img src={CollectionList2[1]?.images[0]} width="100%" height="auto" />
                                                    </div>
                                                    <div className="custom-jewl-div">
                                                        <h4>
                                                            {CollectionList2[0]?.name}
                                                        </h4>
                                                        <p>
                                                            {CollectionList2[0]?.description}
                                                        </p>
                                                        <div>
                                                            <a href={process.env.PUBLIC_URL + `/CustomDesign`} className="start-with-btn">
                                                                Explore
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <div className="col-lg-6 p-0">
                                                <div>
                                                    <div className="custom-jewl-div pmd-card-media pmd-card-media-down">
                                                        <h4>
                                                            {CollectionList2[1]?.name}
                                                        </h4>
                                                        <p style={{ maxWidth: "350px", marginLeft: "auto", marginRight: "auto" }}>
                                                            {CollectionList2[1]?.description}
                                                        </p>
                                                        <div>
                                                            <Link
                                                                className="start-with-btn"
                                                                aria-current="page"
                                                                to={BASENAME +'/ContactUs'}
                                                            >
                                                                Get in touch with us
                                                            </Link>
                                                            {/* <a href={process.env.PUBLIC_URL + `/Appointment`} className="start-with-btn">
                                                                Get in touch with us
                                                            </a> */}
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <img src={CollectionList2[0]?.images[0]} width="100%" height="auto" />
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    }
                                </div>
                            </section>
                        }


                        <section className="jumbotron-my pb-5 pt-5" style={{ maxWidth: "1100px", margin: "auto" }}>
                            <div className="container">
                                <div className="row">
                                    <div className="col-lg-6 news-rightbor">
                                        <div className="touch-div">
                                            <h3 className="">
                                                Let's Keep In Touch
                                            </h3>
                                            <p className="akkurat">
                                                Join our community of jewellery lovers, and receive once a week special offers, news and product launches straight to your inbox.
                                            </p>
                                        </div>
                                    </div>
                                    <div className="col-lg-6 news-leftbor">
                                        <div>
                                            <div>
                                                <div className="input-group mb-3 sign-up-home" >
                                                    <input
                                                        type="text"
                                                        className="form-control signplace"
                                                        placeholder="Your Email Address"
                                                        value={email}
                                                        onChange={(e) => setEmail(e.target.value)}
                                                    />
                                                    {/* <div className="input-group-append sign-up-home-btn" onClick={() => CallEmailApi()}> */}
                                                    <button className="btn Hypatia col-fff" type="button" >
                                                        <svg width="22" height="14" viewBox="0 0 22 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M13.5 1L21 6.99977M21 6.99977L13.5 13M21 6.99977L5.24516e-07 6.99977" stroke="#23282D" />
                                                        </svg>
                                                    </button>
                                                    {/* </div> */}
                                                </div>
                                            </div>
                                            <div>
                                                <p className="p-tag">
                                                    By submitting your details, you consent to receive marketing emails from dioraadams. You can unsubscribe anytime from this.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                    </main>
                }


            </div>
        </>
    );
};
export default Home;